/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\


Voici les fichiers qui accompagnent l'aticle a titre d'exemple :

 - RF.COM  --> Le prg etudier, on le chargera en memoire pour les test.
 - RF.LST  --> Le code dessemble du .com
 - DESAC_RF.COM  --> Prg qui desactive le resident RF.
 - DESAC_RF.ASM  -->  et son code source en asm.
 - ACTIV_RF.COM  --> Prg qui reactive le resident RF.
 - ACTIV_RF.ASM  -->  et son code source en asm.
 - CERTIF.COM  -->  Prg qui certifie 1 disquette. 
 - CERTIF.ASM  -->   et son code source en asm.
 - TESTRF.COM  -->  Prg qui test si RF est present en memoire.
 - TESTRF.ASM  -->   et son code source en asm.
 - KSILLY.COM  -->  Prg qui reunit les 3 fonction de crack (exemple...)

     Bon crk a tous ;)

                                                        PiXel4

\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/

