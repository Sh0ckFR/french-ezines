/******************************************************************************
 *                        rtcscan.h by S/ash [RtC]                            *
 *                        RtC Scan : a network mapper                         *
 *                          contain many includes                             *
 *              This is a part of the RtC Neset Project - RtC Tech            *
 ******************************************************************************/

#ifndef __RTCSCAN_RTCSCAN_H__
#define __RTCSCAN_RTCSCAN_H__

/* Using BSD Network source */
#define _BSD_SOURCE

/* Includes */
/* Standard includes */
#include <stdio.h>
#include <stdlib.h>
#include <pwd.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include <sys/time.h>
#include <sys/types.h>

/* Network includes */
#include <netdb.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <netinet/ip_icmp.h>
#include <arpa/inet.h>

/* Own includes */
#include "constant.h"                /* Constant : edit it to change default values                 */
#include "str." RTCSCAN_LANG ".h"    /* Interface strings : translate strings to translate the soft */
#include "structures.h"
#include "prototypes.h"

#endif
