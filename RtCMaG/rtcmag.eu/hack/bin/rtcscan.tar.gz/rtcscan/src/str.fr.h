/******************************************************************************
 *                          str.fr.h by S/ash [RtC]                           *
 *                        RtC Scan : a network mapper                         *
 *             Contient les chaines d'interface (version fran�aise)           *
 *              This is a part of the RtC Neset Project - RtC Tech            *
 ******************************************************************************/

#ifndef __RTCSCAN_STR_H__
#define __RTCSCAN_STR_H__


/* chaines d'erreur */
#define PORTLIST_ERROR              "erreur : la liste des ports a un format incorrect.\n"
#define IPLIST_ERROR                "erreur : la liste des ip a un format incorrect\n"
#define OPENPORTFILE_ERROR          "erreur � l'ouverture du fichier liste de ports %s.\n"
#define OPENIPFILE_ERROR            "erreur � l'ouverture du fichier liste d'ip %s.\n"
#define OPENOFILE_ERROR             "erreur � l'ouverture du fichier de sortie %s.\n"
#define IPSTR_INVALID               "erreur : cha�ne ip invalide\n"
#define INADDR_ERROR                "Probl�me de connection � l'h�te %s.\n"
#define ICMPRAW_SOCK_ERROR          "erreur : ne peut cr�er de raw socket ICMP\n"\
                                    "         n�cessaire pour tester si l'h�te est connect�\n"
#define TCPRAW_SOCK_ERROR           "erreur : ne peut cr�er de raw socket TCP\n"\
                                    "         n�cessaire aux scannings SYN et Stealth\n"
#define TCPSTREAM_SOCK_ERR          "erreur : ne peut cr�er de socket TCP en mode flux\n"\
                                    "         n�cessaire aux scannings Complete-TCP et FTP Bounce\n"
#define UDPRAW_SOCK_ERROR           "erreur : ne peut cr�er de raw socket UDP\n"\
                                    "         n�cessaire au scanning UDP\n"
#define UDPDGRAM_SOCK_ERR           "erreur : ne peut cr�er de socket datagram UDP\n"\
                                    "         n�cessaire au scanning UDP (lame)\n"
#define IPRAW_SOCK_ERROR            "erreur : ne peut cr�er de raw socket\n"\
                                    "         n�cessaire aux scannings SYN et Stealth\n"
#define CANTFINDLOCALHOST           "erreur : localhost introuvable.\n"
#define CANTWRITEIPHDR              "erreur : Impossible d'�crire les en-t�tes IP.\n"
#define PACKETSIZE_INCORRECT        "erreur : la taille du paquet doit �tre entre " MIN_PACKETSIZESTR " et " MAX_PACKETSIZESTR "\n"
#define FTP_CONNECTREFUSED_ERROR    "\nerreur : l'h�te FTP a refus� la connexion\n"
#define FTP_CONNECTERROR_ERROR      "\nerreur : probl�mes de connection au FTP\n"
#define FTP_USERREFUSED_ERROR       "\nerror : login/pass FTP refus�s\n"
#define FTP_UNKNOWANSWER_ERROR      "\nerreur : r�ponse inconnue venant du FTP (�tes-vous s�r qu'il s'agit d'un FTP ?)\n"
#define FTP_PORTREFUSED_ERROR       "\nerreur : la commande PORT a �t� refus�e\n"\
                                      "         cet h�te FTP ne doit pas accepter les commandes PORT trafiqu�es\n"


/* interface strings */
#define COMMENT_LINE       "# "

#define FTP_HOSTNAME       "Recherche du nom d'h�te FTP %s "
#define FTP_HOSTIP         "(%s)\n"
#define FTP_CONNEXION      "Connexion au FTP... "
#define FTP_CONNECTED      "ok\n"

#define BEGIN_SCANNING     "\nBalayage de l'h�te %s"
#define HOST_COMMENT       " (%s)"
#define HOST_IP            "Adresse IP : %s... "
#define HOST_UPSTR         "Up...\n"
#define HOST_DOWNSTR       "il semble etre down...\n"

#define UDP_SCAN_MSG       "Balayage des ports UDP "
#define TCP_SCAN_MSG       "Balayage des ports TCP "
#define ECHO_SCAN_MSG      "Balayage des h�tes connect�s\n"
#define UDP_LAME_SCAN_MSG  "(lame)\n"
#define UDP_FAST_SCAN_MSG  "(classique)\n"
#define TCP_COMP_SCAN_MSG  "(connexion complete)\n"
#define TCP_SYN_SCAN_MSG   "(SYN)\n"
#define TCP_FIN_SCAN_MSG   "(Furtif : FIN)\n"
#define TCP_ACK_SCAN_MSG   "(Furtif : ACK)\n"
#define TCP_FTP_SCAN_MSG   "(FTP bounce attack)\n"
#define LOCALHOST_SCAN_MSG "localhost : %s\n"

#define SCAN_HEAD_LINE     " Port        Etat               Service\n"
#define PORT_OPEN           "%5ld        ouvert             %s\n"
#define PORT_CLOSED         "%5ld        ferm�              %s\n"
#define PORT_TIMEDOUT       "%5ld        time out           %s\n"
#define PORT_ERROR          "%5ld        r�ponse inconnue   %s\n"

#define ECHO_HOST_UP       "connect�\n"
#define ECHO_HOST_TIMEDOUT "a d�pass� les d�lais d'attente\n"
#define ECHO_HOST_UNREACH  "ne peut �tre atteint\n"

#define PROMPT_NEXTHOST    "Appuyez sur entr� pour passer � l'h�te suivant..."
#define SCAN_COMPLETED     "\nScan termin� (%d h�te(s)) en %d ms...\n"

#define INFOSTR            "RtC Scan " VER_STR " : a network mapper\n"\
                           "  A RtC Tech Software, part of the RtC Neset Project\n"\
                           "  RtC    : http://www.rtc.fr.st  -  rtc@fr.st\n"\
                           "  Auteur : S/ash <slash-rtc@fr.st>\n\n"

#define INFOSTRFILE        "# RtC Scan " VER_STR " : a network mapper\n"\
                           "#   A RtC Tech Software, part of the RtC Neset Project\n"\
                           "#   RtC    : http://www.rtc.fr.st  -  rtc@fr.st\n"\
                           "#   Auteur : S/ash <slash-rtc@fr.st>\n\n"

#define SHORTSYNTAXSTR     "syntaxe : %s [options] {-l iplist | ip}\n"\
                           "          ip     : ip � scanner (y compris les masques ip comme 12.3.2-7.*)\n"\
                           "          iplist : fichier contenant la liste des ip � scanner\n"\
                           "tapez %s -? pour plus d'information\n"
                          
#define SYNTAXSTR          "syntaxe : %s [options] {-l iplist | ip}\n"\
                           "          ip     : ip � scanner (y compris les masques ip comme 12.3.[2-7].*)\n"\
                           "          iplist : fichier contenant la liste des ip � scanner\n"\
                           "les options sont :\n"\
                           "  -s : choix de la m�thode de scan. Les m�thodes disponibles sont :\n"\
                           "     -sS : scanning � demi-ouverture de port (SYN)\n"\
                           "     -sT : scanning TCP � connexion compl�te : par d�faut\n"\
                           "     -sF : scan furtif (FIN)                   -sA : scan furtif (ACK)\n"\
                           "     -sB host : FTP Bounce scan utilisant host -sE : ICMP Echo scanning\n"\
                           "     -sU : UDP scanning (classique)            -su : UDP scanning (lame)\n"\
                           "  -f : scan lents (pour les methodes S, F, A, E, U)\n"\
                           "  -d d�lai : �tablit le d�lai entre chaque connexion (def : " DEFDELAY_STR " ms)\n"\
                           "  -i ip : donne votre IP pour les scans SYN, furtifs et UDP (classique)\n"\
                           "  -u : d�sactive le test de l'h�te avant de faire le scan\n"\
                           "  -t timeout : �tablit le time out (def : " DEFTIMEOUT_STR " ms)\n"\
                           "  -r scan_port : �tablit le num�ro de port � utiliser (def : " DEFSTCP_PORT_STR ")\n"\
                           "  -H A-B : num�ro de port � utiliser choisi au hasard entre A et B\n"\
                           "  -m A-B : test tout les ports compris entre A et B\n"\
                           "  -p file : test les ports contenu dans le fichier file (def : /etc/services)\n"\
                           "  -T tries : r�gle le nombre d'essai pour les m�thodes E et B (def : " DEFAULT_TRIESSTR ")\n"\
                           "  -S packetsize : r�gle la taille d'un paquet (m�thode E) (def : " DEFAULT_PACKETSIZESTR ")\n"\
                           "  -o file : loggue les r�sultats dans le fichier file\n"\
                           "  -h user pass : donne les param�tres de connexion pour la m�thode B (def : " DEFFTP_LOGIN "/" DEFFTP_PASS ")\n"\
                           "  -R port : donne le port FTP � utiliser (def : " DEFSFTP_PORT_STR ")\n"\
                           "  -a : montre tout les r�sultats (m�me pour les ports ferm� ou les h�te down)\n"\
                           "  -e : n'affiche pas les r�sultats sur stdout\n"\
                           "  -n : attend avant le scan de chaque nouvel h�te\n"\
                           "  -? : affiche cet �cran d'aide\n"\
                           "Les options -p et -m sont incompatibles.\n"


#endif
