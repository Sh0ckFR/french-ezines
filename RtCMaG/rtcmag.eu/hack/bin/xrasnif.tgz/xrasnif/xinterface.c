/* xRaSnif by RaPass <rapass@gmx.net>*/
 #include "xRaSnif.h"
#include <semaphore.h>

extern sem_t my_sem;

void FinProg(GtkWidget *Fenetre) {
  int i;
  

  pthread_cancel(th1);
  if (unset_promisc(hehe, sock_for_sniffe) < 0)
    fprintf(stderr, "Impossible d'enlever le mode promiscuous !!\n");
  
  if (sock_for_sniffe) {
    if (close(sock_for_sniffe) != 0) 
      perror("fermeture socket de sniffing");    
  }

  if (sock_for_send) {
    if (close(sock_for_send) != 0)
      perror("fermeture socket qui envoie");
  }

  for (i=0 ; connections[0] != NULL ; i++)
    enleve_connection(0, NULL, NbrLignes);
  
  free(connections);
  gtk_exit(0);
}


void xinterface(int argc, char *argv[], GtkWidget **widgets) {
  GtkWidget *Fenetre;
  GtkWidget *Notebook;
  GtkWidget *Label;
  GtkWidget *ScrICMP;
  GtkWidget *ScrTCP;
  gchar *Tcolonnes_TCP[] = {
    "Date/heure premier paquet recu",
    "Source(adresse ip:port)", 
    "Destination(adresse ip:port)"};

  gchar *Tcolonnes_ICMP[] = {
    "Source(adresse ip)",
    "Destination(adresse ip)",
    "type  ",
    "code  ",
    "Taille donnees(en octets)"};

  gtk_init(&argc, &argv);
  /* --- Cretaion Fenetre --- */
  Fenetre = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title(GTK_WINDOW(Fenetre), "xRaSnif by RaPass <rapass@gmx.net>");
  gtk_signal_connect(GTK_OBJECT(Fenetre), "destroy", 
		     (GtkSignalFunc)FinProg, NULL);
  /* --- Creation Notebook -- */
  Notebook = gtk_notebook_new();
  gtk_container_add(GTK_CONTAINER(Fenetre), Notebook);
  /* --- Creation Clists --- */
  widgets[0] = gtk_clist_new_with_titles(3, Tcolonnes_TCP);
  gtk_signal_connect(GTK_OBJECT(widgets[0]),"select_row",(GtkSignalFunc)AfficheOption, NULL);
  ScrTCP = gtk_scrolled_window_new(NULL, NULL);
  gtk_widget_set_usize(ScrTCP, 700, 200);
  gtk_container_add(GTK_CONTAINER(ScrTCP), widgets[0]);
  Label = gtk_label_new("TCP");
  gtk_notebook_append_page_menu(GTK_NOTEBOOK(Notebook), ScrTCP, 
				Label, Label);

  widgets[1] = gtk_clist_new_with_titles(5, Tcolonnes_ICMP);
  ScrICMP = gtk_scrolled_window_new(NULL, NULL);
  gtk_widget_set_usize(ScrICMP, 700, 200);
  gtk_container_add(GTK_CONTAINER(ScrICMP), widgets[1]);
  Label = gtk_label_new("ICMP");
  gtk_notebook_append_page_menu(GTK_NOTEBOOK(Notebook), ScrICMP, 
				Label, Label);
  
  /* --- Affichage de tout ce que l'on a creer ---*/
  gtk_widget_show_all(Fenetre);
  sem_post(&my_sem); 
  gtk_main();
}
