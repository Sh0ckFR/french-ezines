/* xRaSnif by RaPass <rapass@gmx.net>*/
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>           
#include <gtk/gtk.h>
#include <sys/types.h> 
#include <sys/socket.h> 
#include <netinet/in.h> 
#include <netdb.h> 
#include <linux/if.h>  
#include <arpa/inet.h> 
#include <linux/socket.h> 
#include <linux/ip.h> 
#include <linux/tcp.h>
#include <linux/icmp.h>
#include <linux/if_ether.h>
#include <string.h> 
#include <sys/ioctl.h> 
#include <sys/stat.h> 
#include <pthread.h>
#include <fcntl.h>
#include <time.h>


#define NBR_CONNECT_MAX  200

#define TAILLE_TRAME  ENTETE_ETH + ENTETE_IP + ENTETE_TCP 
#define ENTETE_ETH    sizeof(struct ethhdr)
#define ENTETE_IP     sizeof(struct iphdr)
#define ENTETE_TCP    sizeof(struct tcphdr)
#define ENTETE_ICMP   sizeof(struct icmphdr)

#define SIZE_WID      sizeof(struct widg)

#define	TH_FIN	0x01
#define	TH_SYN	0x02
#define	TH_RST	0x04
#define	TH_PUSH	0x08
#define	TH_ACK	0x10
#define	TH_URG	0x20

struct pseudohdr {
  unsigned long saddr;
  unsigned long daddr;
  unsigned char nada;
  unsigned char protocol;
  unsigned short length;
};	

struct widg {
  FILE *fptr;
  char *filename;
  GtkWidget *fenetre_entete;
  GtkWidget *fenetre_sniffe;
  GtkWidget *texte_sniffe; 
  GtkWidget *fenetre_hijack; 
};  

extern int set_promisc(char *device, int fd);

int unset_promisc(char *device, int fd);

extern void filter(GtkWidget **widgets);

extern void sniffe_ICMP(struct iphdr *ip, 
			struct icmphdr *icmp, 
			GtkWidget *Liste);

extern int sniffe_TCP(char *trame, GtkWidget *Clist, int NbrLignes);

int enleve_connection(int connect_a_enlever, 
		      GtkWidget *Liste, 
		      int nbr_connections);

int cherche_connection(struct iphdr *ip1, struct tcphdr *tcp1, 
		       int nbr_connections, int mode);

extern void xinterface(int argc, char *argv[], GtkWidget **widgets);

extern gboolean AfficheOption(GtkCList *liste, gint Ligne, 
			      gint colonne, GdkEvent *event);
extern gboolean aff_snifdata();

extern gboolean Aff_entete();

extern gboolean killeRST();

extern gboolean killeFIN();

extern gboolean hijackTCP(GtkWidget *Bouton, GtkWidget **widgets);

void FinProg(GtkWidget *Fenetre);

extern void envoie_tcp(unsigned long saddr,
               unsigned long daddr,
               unsigned sport,
               unsigned dport,
               unsigned char flags,
               unsigned long seq,
               unsigned long ack,
               unsigned tcp_win,
               char     *donnees,
		int      taille_donnees);

extern unsigned short in_cksum(u_short *addr, int len);
extern char *hehe; 
extern int sock_for_sniffe;
extern int sock_for_send;
extern pthread_t th1;
extern pthread_mutex_t my_mutex;
extern char **connections;
extern int NbrLignes; 

extern GtkWidget *FenetreOptionsTCP;
extern int ligne_select; 



