/* xRaSnif by RaPass <rapass@gmx.net>*/

#include "xRaSnif.h"

void sniffe_ICMP(struct iphdr *ip, struct icmphdr *icmp, GtkWidget *Liste) {
  unsigned char *so, *dest;
  gchar *insert[5];
 
  so = (unsigned char *)&(ip->saddr);
  dest = (unsigned char *)&(ip->daddr);

  insert[0] = g_strdup_printf("%u.%u.%u.%u",so[0],so[1],so[2],so[3]);
  insert[1] = g_strdup_printf("%u.%u.%u.%u",dest[0],dest[1],dest[2],dest[3]);
  insert[2] = g_strdup_printf("%d", icmp->type);
  insert[3] = g_strdup_printf("%d", icmp->code);
  insert[4] = g_strdup_printf("%d", ntohs(ip->tot_len)-sizeof(struct iphdr));
  gtk_clist_append(GTK_CLIST(Liste), insert);
}
