/* xRaSnif by RaPass <rapass@gmx.net> */
#include "xRaSnif.h"

int NbrLignes=0;

#ifndef IP_OFFMASK         /* Ripped de hunt... */
#define IP_OFFMASK 0x1fff  /* pour reperer les */
#endif                     /* paquets fragmenter */
#ifndef IP_MF              /*   '        '   '   */
#define IP_MF	   0x2000  /*   '       '     '  */
#endif                           

void filter(GtkWidget **widgets) {
  int  octets_recus, i;

  char trame[2000];
   
  struct ethhdr *eth;
  struct iphdr *ip;
  struct icmphdr *icmp;

  eth = (struct ethhdr *)trame;
  ip = (struct iphdr *) (trame + ENTETE_ETH);
  icmp = (struct icmphdr *)(trame + ENTETE_ETH + ENTETE_IP);

 
  connections = malloc(NBR_CONNECT_MAX * sizeof(char *));
  for (i = 0 ; i < NBR_CONNECT_MAX ; i++)
    connections[i] = NULL;

  while(1) {
    octets_recus = read(sock_for_sniffe, (char *)trame, 
			sizeof(trame));
    if (octets_recus > 34) {
      if (ntohs(eth->h_proto) == ETH_P_IP) {
	if ((ntohs(ip->frag_off) & IP_OFFMASK) != 0 || /* Ce test de fragmentation */
	    (ntohs(ip->frag_off) & IP_MF))             /* provient de hunt */
	  break;
	
	switch(ip->protocol) {  
	case (IPPROTO_TCP):	    
	  pthread_mutex_lock(&my_mutex);
	  NbrLignes = sniffe_TCP(trame, widgets[0], NbrLignes);
	  pthread_mutex_unlock(&my_mutex);
	  break;
	case(IPPROTO_ICMP):
	  sniffe_ICMP(ip, icmp, widgets[1]);
	  
	}
      }
    }
  }
}

