/* xRaSnif by RaPass <rapass@gmx.net>*/
#include "xRaSnif.h"

GtkWidget *FenetreOptionsTCP = NULL;
int ligne_select;

gboolean FinFenetre(GtkWidget *Fenetre, GtkWidget **widgets) {

  FenetreOptionsTCP = NULL;
  g_free(widgets);
  return TRUE;
}

gboolean AfficheOption(GtkCList *liste, gint Ligne, 
		       gint colonne, GdkEvent *event) {
  GtkWidget *Bouton; 
  GtkWidget *Label;
  GtkWidget **widgets;
  GtkWidget *Table;
  gchar *titre;
  
  ligne_select = Ligne;
  if (FenetreOptionsTCP) {
    titre = g_strdup_printf("Connection numero : %d", ligne_select);
    gtk_window_set_title(GTK_WINDOW(FenetreOptionsTCP), titre);
    g_free(titre);
    gdk_window_raise(FenetreOptionsTCP->window);
  } else {
    
    FenetreOptionsTCP = gtk_dialog_new();
    widgets = g_malloc(2 * sizeof(GtkWidget *));
    gtk_signal_connect(GTK_OBJECT(FenetreOptionsTCP), "destroy", 
		       (GtkSignalFunc)FinFenetre, (gpointer)widgets);


    titre = g_strdup_printf("Connection numero : %d", ligne_select);
    gtk_window_set_title(GTK_WINDOW(FenetreOptionsTCP), titre);
    g_free(titre);
    
    Table = gtk_table_new(11, 5, TRUE);
    gtk_box_pack_start_defaults(GTK_BOX(GTK_DIALOG(FenetreOptionsTCP)->vbox), Table);

    Label = gtk_label_new("-==| Sniffer |==-");
    gtk_table_attach_defaults(GTK_TABLE(Table), Label, 0, 5, 0, 1);
    
    Bouton = gtk_button_new_with_label("Entetes IP et TCP du dernier paquet recu");
    gtk_table_attach_defaults(GTK_TABLE(Table), Bouton, 0, 5, 1, 2);
    gtk_signal_connect(GTK_OBJECT(Bouton),"clicked", (GtkSignalFunc)Aff_entete, NULL);

      
    Bouton = gtk_button_new_with_label("Sniffer les donnees(dans 1 sens)");
    gtk_table_attach_defaults(GTK_TABLE(Table), Bouton, 0, 5, 2, 3);
    gtk_signal_connect(GTK_OBJECT(Bouton),"clicked", (GtkSignalFunc)aff_snifdata, NULL);
 
    Label = gtk_label_new("-==| Killer |==-");
    gtk_table_attach_defaults(GTK_TABLE(Table), Label, 0, 5, 3, 4);

    Bouton = gtk_button_new_with_label("Flags RST");
    gtk_table_attach_defaults(GTK_TABLE(Table), Bouton, 0, 5, 4, 5);
    gtk_signal_connect(GTK_OBJECT(Bouton),"clicked", (GtkSignalFunc)killeRST, NULL);
    
    Bouton = gtk_button_new_with_label("Flags FIN");
    gtk_table_attach_defaults(GTK_TABLE(Table), Bouton, 0, 5, 5, 6);
    gtk_signal_connect(GTK_OBJECT(Bouton),"clicked", (GtkSignalFunc)killeFIN, NULL);
    

    Label = gtk_label_new("-==| Hijacker |==-");
    gtk_table_attach_defaults(GTK_TABLE(Table), Label, 0, 5, 6, 7);

    widgets[0] = gtk_entry_new();
    gtk_table_attach_defaults(GTK_TABLE(Table), widgets[0], 0, 5, 7, 8);

    widgets[1] = gtk_check_button_new_with_label("Ajouter un octet 13 apres la chaine");
    gtk_table_attach_defaults(GTK_TABLE(Table), widgets[1], 0, 5, 8, 9);
    

    Bouton = gtk_button_new_with_label("hijacker la connexion");
    gtk_table_attach_defaults(GTK_TABLE(Table), Bouton, 0, 5, 9, 10);

    gtk_signal_connect(GTK_OBJECT(Bouton),"clicked", (GtkSignalFunc)hijackTCP, 
		       (gpointer)widgets);

    Bouton = gtk_button_new_with_label("Fermer");
    gtk_box_pack_start(GTK_BOX(GTK_DIALOG(FenetreOptionsTCP)->action_area), 
		       Bouton, TRUE, TRUE, 0);
    gtk_signal_connect_object(GTK_OBJECT(Bouton), "clicked", 
			      (GtkSignalFunc)gtk_widget_destroy,
			      GTK_OBJECT(FenetreOptionsTCP));
        
    gtk_widget_show_all(FenetreOptionsTCP);
  }
  return TRUE;
}
