

#include <windows.h>   // Le include de base de tout programme Windows
#include "resource.h"  // Le fichier ressource que Visual C a cr�e pour nous
#include <stdio.h>

HINSTANCE  hInst   = NULL;   // Variable pour contenir l'instance de notre programme
HWND	   hwnd    = NULL;

LRESULT CALLBACK DlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

int patch()
{
	return 0;
}
	
// Le gestionnaire d'�v�nements pour notre bo�te de dialogue
LRESULT CALLBACK DlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)  
{
	switch(msg)
	{
	case WM_COMMAND: 
		{                                                       
			switch(LOWORD(wParam))
			{
				case IDC_PATCH:
					{
						int counter;
						FILE *filename;

						long int offset[11] = {143321,143322,143323,143324,143325,143326,68885,68886,68887,69083,69084};
						unsigned char data[11] = {144,144,144,144,144,144,233,189,0,235,32};

						SetDlgItemText(hwnd,IDC_TEXTE,"OUVERTURE DU FICHIER");                                       
						if ((filename = fopen("ftp95pro.exe", "r+")) != NULL)
						{
							SetDlgItemText(hwnd,IDC_TEXTE,"CRACK DU FICHIER");
							for (counter=1;counter<12;counter++)
							{
								fseek(filename,offset[counter-1],SEEK_SET);
								fprintf(filename,"%c",data[counter-1]);
							}
							SetDlgItemText(hwnd,IDC_TEXTE,"PATCH REUSSI ! MERCI QUI ! :-)");
						}
						else
						{
							SetDlgItemText(hwnd,IDC_TEXTE,"FICHIER NON TROUVE :-(");
						}
						break;
					}
					
				case WM_DESTROY:
					{
				EndDialog(hwnd,FALSE);
				break;
					}

			}
			break;
		}
		 
		default: 	
		return FALSE;
     }
     return TRUE; 
}


int WINAPI WinMain(			
     HINSTANCE hInstance,	// handle sur l'instance pr�sente
     HINSTANCE hPrevInst,	// handle sur l'instance pr�c�dente (Win 3.1, obsol�te)
     LPSTR lpCmdLine,		// ptr sur la ligne de commande (ie: argv[], argc)
     int nCmdShow)			// l'�tat de la fen�tre

{

	hInst = hInstance; 
	// Activer la bo�te de dialogue
    DialogBox(hInst, MAKEINTRESOURCE(IDD_PATCH), NULL, ( DLGPROC ) DlgProc);
  
    return (0);
}
