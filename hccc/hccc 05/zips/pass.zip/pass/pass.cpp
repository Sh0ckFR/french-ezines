/*
----------------------------------------------------
Cod� par TiPiaX - Hccc
hccc@caramail.com
compiled with : Borland C++
----------------------------------------------------
*/

#include <stdio.h>
#include <string.h>

char pass[]="rulez";
char motdepasse[30];

char denied[]  = "                        ACCESS DENIED\n";
char granted[] = "                        ACCESS AUTHORIZED\n";

char hello[]=
"\n\n\n\n"
"          ###    ###   #########    #########     #########\n"
"          ###    ###  ###########  ###########   ###########\n"
"          ###    ###  ###          ###           ###\n"
"          ##########  ###          ###           ###\n"
"          ##########  ###          ###           ###\n"
"          ###    ###  ###          ###           ###\n"
"          ###    ###  ###########  ###########   ###########\n"
"          ###    ###   #########    #########     #########\n"
"\n\n"
"                            Hccc SHIELD\n\n"
"                    - TiPiaX LoGiN : ";

void main()
{
	printf(hello);
	scanf("%30s",&motdepasse);

	if (strcmp(motdepasse,pass)!=0)
	{
		printf(denied);
		boucle:
		goto boucle;
	}

	else
	{
		printf(granted);
	}
}
