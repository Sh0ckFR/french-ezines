05/2002 : Vous trouverez dans cette archive des captures d'�cran
illustrant mon aritcle sur nfs ; �a fait d�ja un bon bout de temps 
qu'elles n'�taient plus disponnibles, mais je viens de les retrouvert 
par hasard sur mon disque. Bonne lecture !

                                         neofox