/*
 * DMP fuck 7350 :p                                                 August 2002
 * Yet another stupid tool using ptrace()
 * Burneye is just a fuckin' stupid program :p
 * engine.c : make the unencryption 
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/mman.h>
#include "rc4.h"
#include "pt.h"
#include "engine.h"
#include "unburn.h"

// 20 premiers octet de l'header ELF pour une archi IA32
#define ELF_HEADER "\x7f\x45\x4c\x46\x01\x01\x01\0\0\0\0\0\0\0\0\0\x02\0\x03\0"

// dumps de burneye
unsigned char magic[20];
void (*burnhash)(unsigned char*, unsigned int, unsigned char*);



inline void HEXDUMP(int size, void *data)
{
  int i;
  for(i=0; i<size; i++)
  {
    if(!(i%20)) printf("\n");
    printf("%02x", ((unsigned char*)data)[i]);
  }
  printf("\n");
}

// xorise buf avec le magic
void do_magic(unsigned char *buf)
{
  int i;
  for(i=0; i<20; i++)
    buf[i] ^= magic[i];
}

// appel le hash de burneye et do_magic correctement
unsigned char* get_key(char *pass)
{
  unsigned char *buf = (unsigned char*)malloc(20);
  if(!buf)
  {
    perror("malloc");
    exit(-1);
  }
  burnhash(pass, strlen(pass), buf);
  do_magic(buf);
  burnhash(buf, 20, buf);
  return buf;
}

void *map_segment(void *segment)
{
  int i;
  FILE *f = fopen(TEMP_FILE, "w");

  if(!f)
  {
    perror("fopen");
    exit(-1);
  }

  for(i=0; i<BURNEYE_OFFSET; i++)
    fputc(((char*)segment)[i], f);
  fclose(f);
  
  i = open(TEMP_FILE, 0);
  if(i<0)
  {
    perror("open");
    exit(-1);
  }
  if(!mmap((void*)BURNEYE_SEGMENT, BURNEYE_OFFSET, 
           PROT_EXEC | PROT_READ | PROT_WRITE,
           MAP_FIXED | MAP_PRIVATE, i, 0))
  {
    perror("mmap");
    exit(-1);
  }
  close(i);
  unlink(TEMP_FILE);
}

int is_header(char *h)
{
  return !strncmp(h, "\x7f" "ELF", 4);
}

struct seg_map pass1(char *progname, int getmagic, int verbose)
{
  struct seg_map result;
  unsigned int    offset;
  
  pid_t pid = run_target(progname);
  wait_sigtrap(pid);
  pt_cont(pid);
  wait_sigtrap(pid);

  if(verbose) printf(VERB1_STR);
  result = get_seg(pid, BURNEYE_SEGMENT);
  if(!result.size) return result;
  
  offset = ((unsigned int*)result.memory)[BURNEYE_OFFSET >> 2];
  if(verbose) printf(VERB2_STR, offset+BURNEYE_OFFSET);
  
  if(getmagic)
  {
    if(verbose) printf(VERB3_STR);
    map_segment(result.memory);
    burnhash = (void*)BURNEYE_HASH;
    memcpy(magic, (char*)result.memory + BURNEYE_MAGIC + offset, 20);
    if(verbose)
    {
      printf(VERB7_STR, BURNEYE_MAGIC + offset);
      printf(VERB4_STR);
      HEXDUMP(20, magic);
    }
  }
  
  offset += BURNEYE_OFFSET;
  result.size -= offset;
  memmove(result.memory, (char*)result.memory + offset, result.size);
  if(!getmagic)
  {
    if(!is_header(result.memory))
    {
      free(result.memory);
      result.size = 0;
    }
  }
  return result;
}

void pass2(char *passwd, struct seg_map *map, int verbose)
{
  rc4_key rkey;
  unsigned char *digest = get_key(passwd);
  if(verbose)
  {
    printf(VERB6_STR);
    HEXDUMP(20, digest);
  }
  prepare_key(digest, 20, &rkey);
  rc4(map->memory, map->size, &rkey);
  free(digest);
  if(!is_header(map->memory))
  {
    free(map->memory);
    map->size = 0;
  }
}

// effectue une passe du brute force
int do_brute2(char *passwd, struct seg_map *map, int verbose)
{
  int result;
  rc4_key rkey;
  rc4_key skey;
  unsigned char *digest = get_key(passwd);

  prepare_key(digest, 20, &rkey);
  memcpy(&skey, &rkey, sizeof(rc4_key));
  rc4(map->memory, 20, &rkey); // seulement les 20 premiers octets pour le test
  result = !memcmp(map->memory, ELF_HEADER, 20);
  memcpy(&rkey, &skey, sizeof(rc4_key));
  rc4(map->memory, 20, &rkey);
  
  if(result)
  { // d�cryptage
    if(verbose)
    {
      printf(VERB5_STR, passwd);
      printf(VERB6_STR);
      HEXDUMP(20, digest);
    }
    rc4(map->memory, map->size, &skey);
  }
  free(digest);
  return result;
}

void brute2(char *dict, struct seg_map *map, int verbose)
{
  FILE *f;
  char buf[1024];
  if(map->size < 20)
  {
    map->size = 0;
    return;
  }
  f = fopen(dict, "r");
  if(!f)
  {
    perror("fopen");
    exit(-1);
  }
  while(!feof(f))
  {
    fgets(buf, 1024, f);
    buf[1023] = 0;
    if(buf[strlen(buf)-1] == '\n') buf[strlen(buf)-1] = 0;
    if(do_brute2(buf, map, verbose)) 
    {
      fclose(f);
      return;
    }
  }
  fclose(f);
  map->size = 0;
  free(map->memory);
}

void save_buffer(char *fn, struct seg_map m)
{
  long i;
  FILE *f = fopen(fn, "w");

  if(!f)
  {
    perror("fopen");
    exit(-1);
  }

  for(i=0; i<m.size; i++)
    fputc(((char*)m.memory)[i], f);

  fclose(f);

  if(chmod(fn, S_IRUSR | S_IWUSR | S_IXUSR))
  {
    perror("chmod");
    exit(-1);
  }
  free(m.memory);
}
