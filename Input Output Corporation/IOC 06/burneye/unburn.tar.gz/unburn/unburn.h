/*
 * Digital Mutants Party fuck 7350 :p                                August 2002
 * Yet another stupid tool using ptrace()
 * Burneye is just a fuckin' stupid program :p
 * unburn.h : main file for burneye cracking
 */

#ifndef __UNBURN_H__
#define __UNBURN_H__

#define BURNEYE_SEGMENT    0x05370000
#define BURNEYE_HASH       0x53741c4
#define BURNEYE_OFFSET     0x5a00
#define BURNEYE_MAGIC      0x59Dc
#define TEMP_FILE          "/tmp/unburn.temp"
#define DEFAULT_OUTPUT     "a.out"

#define HEADER_STR "unburn - August 2002\n"\
                   "Coded at the Digital Mutants Party\n\n"

#define USAGE_STR  "syntax : %s [{-p passwd|-b file}] [-o output] program\n"\
                   "    program is the execution path to the burneyed binarie\n"\
                   "options are :\n"\
                   "    -o output : give the output name (default is a.out)\n"\
                   "    -p passwd : give the password for the second layer\n"\
                   "    -b file   : brute force the second layer using dictionnary 'file'\n"\
                   "    -v        : be verbose\n"\
                   " -p and -b are incompatible.\n\n"


#define NORM_TXT   "\033[0m"
#define RED_TXT    "\033[31m"
#define GREEN_TXT  "\033[32m"
#define UNBURN_STR "Unburneying '%s'...\n"
#define PASS1_STR  " * pass 1... "
#define OK_STR     GREEN_TXT "OK\n" NORM_TXT
#define FAILED_STR RED_TXT "FAILED !\n" NORM_TXT
#define PASS2_STR  " * pass 2 with password '%s'... "
#define BFORCE_STR " * pass 2 for brute force with dictionnary '%s'... "
#define DUMP_STR   " * reconstructing binary file... "
#define END_STR    "%s unburneyed in %s !\n"

#define VERB1_STR  "\nDumping segment 0x05370000\n"
#define VERB2_STR  "\nOffset is 0x%x\n"
#define VERB3_STR  "\nMapping hash at 0x53741c4\n"
#define VERB4_STR  "\nMagic is :"
#define VERB5_STR  "\nPassword is '%s'\n"
#define VERB6_STR  "\nKey is :"
#define VERB7_STR  "\nMagic offset is 0x%x"

#endif
