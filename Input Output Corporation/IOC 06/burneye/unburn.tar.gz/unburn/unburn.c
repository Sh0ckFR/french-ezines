/*
 * DMP fuck 7350 :p                                                 August 2002
 * Yet another stupid tool using ptrace()
 * Burneye is just a fuckin' stupid program :p
 * unburn.c : main function 
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "engine.h"
#include "unburn.h"

struct unburn_options {
  char *prog;
  char *passwd;
  char *output;
  char *dictionary;
  int  verbosity;
};

void                  usage(char*);
void                  header();
struct unburn_options parse_options(int, char**);
void                  run(struct unburn_options);

int main(int argc, char **argv)
{
  struct unburn_options o;
  header();
  run(parse_options(argc, argv));
  return 0;
}

void usage(char *progname)
{
  fprintf(stderr, USAGE_STR, progname);
  exit(-1);
}

void header()
{
  printf(HEADER_STR);
}

struct unburn_options parse_options(int argc, char **argv)
{
  int i,j,k;
  struct unburn_options o;
  o.prog       = NULL;
  o.passwd     = NULL;
  o.output     = DEFAULT_OUTPUT;
  o.dictionary = NULL;
  o.verbosity  = 0;
  for(i=1; i<argc; i++)
  {
    if(argv[i][0] == '-')
    {
      k = i;
      for(j=1; j<strlen(argv[i]); j++)
      {
        if(argv[i][j] != 'v') 
	  if((++k) >= argc) usage(argv[0]);
        switch(argv[i][j])
        {
          case 'o': o.output = argv[k]; break;
          case 'p': o.passwd = argv[k]; break;
          case 'b': o.dictionary = argv[k]; break;
          case 'v': o.verbosity++; break;
          default:  usage(argv[0]);
	}
      }
      i = k;
    }
    else
    {
      if(!o.prog)
        o.prog = argv[i];
      else usage(argv[0]);
    }
  }
  if(!o.prog || (o.dictionary && o.passwd)) usage(argv[0]);
  return o;
}

void run(struct unburn_options o)
{
  struct seg_map dump;
  printf(UNBURN_STR, o.prog);
  printf(PASS1_STR);
  fflush(stdout);
  dump = pass1(o.prog, o.passwd || o.dictionary, o.verbosity);
  if(!dump.size)
  {
    printf(FAILED_STR);
    exit(-1);
  }
  printf(OK_STR);
  if(o.passwd)
  {
    printf(PASS2_STR, o.passwd);
    fflush(stdout);
    pass2(o.passwd, &dump, o.verbosity);
    if(!dump.size)
    {
      printf(FAILED_STR);
      exit(-1);
    }
    printf(OK_STR);
  }
  else if(o.dictionary)
  {
    printf(BFORCE_STR, o.dictionary);
    fflush(stdout);
    brute2(o.dictionary, &dump, o.verbosity);
    if(!dump.size)
    {
      printf(FAILED_STR);
      exit(-1);
    }
    printf(OK_STR);
  }
  printf(DUMP_STR);
  fflush(stdout);
  save_buffer(o.output, dump);
  printf(OK_STR);
  printf(END_STR, o.prog, o.output);
}

