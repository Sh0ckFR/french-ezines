/*
 * DMP fuck 7350 :p                                                 August 2002
 * Yet another stupid tool using ptrace()
 * Burneye is just a fuckin' stupid program :p
 * engine.h : make the unencryption 
 */
#ifndef __ENGINE_H__
#define __ENGINE_H__

#include "pt.h"

void           do_magic(unsigned char*);
unsigned char *get_key(char*);
void          *map_segment(void *);
int            is_header(char*);
struct seg_map pass1(char*, int, int);
void           pass2(char*, struct seg_map*, int);
int            do_brute2(char*, struct seg_map*, int);
void           brute2(char*, struct seg_map*, int);
void           save_buffer(char*, struct seg_map);

#endif
