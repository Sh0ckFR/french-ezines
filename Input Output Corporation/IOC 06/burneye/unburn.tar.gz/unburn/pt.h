/*
 * Digital Mutants Party fuck 7350 :p                                August 2002
 * Yet another stupid tool using ptrace()
 * Burneye is just a fuckin' stupid program :p
 * pt.h : contain ptrace functions
 */

#ifndef __PT_H__
#define __PT_H__

struct seg_map
{
  unsigned long size;
  void*         memory;
};

void            pt_traceme();
long int        pt_peek(pid_t, unsigned long);
void            pt_cont(pid_t);
void            pt_kill(pid_t);
pid_t           run_target(char*);
void            wait_sigtrap(pid_t);
struct seg_map  get_seg(pid_t, unsigned long);
unsigned long   get_seg_size(pid_t, unsigned long);

#endif
