/*
 * Digital Mutants Party fuck 7350 :p                                August 2002
 * Yet another stupid tool using ptrace()
 * Burneye is just a fuckin' stupid program :p
 * pt.c : contain ptrace functions
 */
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/ptrace.h>
#include <sys/wait.h>
#include "pt.h"

void pt_traceme()
{ 
  if(ptrace(PTRACE_TRACEME, 0, NULL, NULL))
  { 
    perror("pt_traceme");
    exit(-1);
  }
}

long int pt_peek(pid_t pid, unsigned long addr)
{ 
  long int result;
  if((result = ptrace(PTRACE_PEEKTEXT, pid, (void*)addr, NULL)) == -1)
    if(errno)
    {
      perror("pt_peek");
      exit(-1);
    }
  return result;
}

void pt_cont(pid_t pid)
{
  if(ptrace(PTRACE_CONT, pid, NULL, NULL))
  {
    perror("pt_cont");
    exit(-1);
  }
}

void pt_kill(pid_t pid)
{
  if(ptrace(PTRACE_KILL, pid, NULL, NULL))
  {
    perror("pt_kill");
    exit(-1);
  }
}

pid_t run_target(char *target)
{
  int   status;
  pid_t pid = fork();
  if(pid<0)
  {
    perror("fork");
    exit(-1);
  }
  else if(!pid)               /* il s'agit du fils � tracer */
  {
    /* lancer le tracage */
    pt_traceme();
    /* lancer le programme a dumper */
    execl(target, target, NULL);
    perror("execl");
    exit(-1);
  }
  // ici le p�re trace le process fils
  return pid;
}

void wait_sigtrap(pid_t pid)
{
  int status = 0;
  do                           /* on attend le SIGTRAP */
  {
    if(status && WIFSTOPPED(status) && (WSTOPSIG(status) != SIGTRAP))
      pt_cont(pid);

    if(waitpid(pid, &status, WUNTRACED)<0)
    {
      perror("waitpid");
      exit(-1);
    }
  } while(!WIFEXITED(status) &&
    !(WIFSTOPPED(status) && (WSTOPSIG(status) == SIGTRAP)));

  if(WIFEXITED(status))       /* arghhhh, pas de SIGTRAP ?? */
  {
    fprintf(stderr, "error : pid %d has exited without SIGTRAP !!\n", pid);
    exit(-1);
  }
}

/* get_seg_size : trouve la taille d'un segment (0 : segment non trouv�e) */
unsigned long get_seg_size(pid_t pid, unsigned long addr)
{
  char buf[1024];
  unsigned long a,b;
  int r;
  FILE *f;

  // ouverture du fichier maps
  snprintf(buf, 1024, "/proc/%d/maps", pid);
  if(!(f = fopen(buf, "r")))
  {
    perror("fopen");
    exit(-1);
  }
  
  // recherche du segment
  a = 0;
  while(a != addr)
  {
    r = fscanf(f, "%x-%x", &a, &b);

    if(r==EOF)
      return 0;
    else if((r!=2) || (a > b))
    { 
      fprintf(stderr, "maps file has not the correct format !\n");
      exit(-1);
    } 
    else fgets(buf, 1024, f);
  }
  return (b-a);
}

/* get_seg : r�cup�re un segment donn�
 * (res.size = 0 si le segment n'existe pas)
 */
struct seg_map get_seg(pid_t pid, unsigned long segaddr)
{
  unsigned long addr, i;
  struct seg_map res;
  res.size   = get_seg_size(pid, segaddr);
  res.memory = NULL;
  if(!res.size) return res;
  
  if(!(res.memory = malloc(res.size)))
  {
    perror("malloc");
    exit(-1);
  }

  // dump du segment
  i = 0;
  for(addr = segaddr; addr < (segaddr+res.size); addr += sizeof(int))
  {
    *(unsigned int*)(res.memory+i) = pt_peek(pid, addr);
    i += sizeof(int);
  }

  return res;
}
