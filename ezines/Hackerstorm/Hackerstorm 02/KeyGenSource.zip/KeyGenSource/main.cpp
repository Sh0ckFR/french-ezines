
//---------------------------------------------------------------------
// La Keygen du KeygenMe #1
//---------------------------------------------------------------------


#include <windows.h>   // Le include de base de tout programme Windows
#include <stdio.h>
#include "resource.h"  // Le fichier ressource que Visual C a cr�e pour nous


HINSTANCE  hInst   = NULL;   // Variable pour contenir l'instance de notre programme

char nom[50];

int serial;
int nombre;
int total;
int i;

LRESULT CALLBACK DlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK DlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)  
{
	switch(msg)
	{
	case WM_COMMAND: 
		{                                                       
			switch(LOWORD(wParam))
			{
				case IDC_KEYGEN:
					{
						nombre = 0;
						total = 0;
						i = 0;

						GetDlgItemText(hwnd,IDC_NOM,nom,50);
						if (nom[0] == 0) //pas de nom !!
						{
							MessageBox(hwnd,"Vous devez entrer un nom","KeyGeN",MB_OK);
							break;
						}

						for (i=0; nom[i] != 0; i++)
						{
							nombre = (char) nom[i];
							total = total + nombre;
						}

						total = total * 33;
						SetDlgItemInt(hwnd,IDC_SERIAL,total,NULL);

						break;
					}


				case WM_DESTROY:
					{
						ExitProcess(0);
						break;
					}

			}
			break;
		}

		default: 	
		return FALSE;
     }
     return TRUE; 
}


int WINAPI WinMain(			
     HINSTANCE hInstance,	// handle sur l'instance pr�sente
     HINSTANCE hPrevInst,	// handle sur l'instance pr�c�dente (Win 3.1, obsol�te)
     LPSTR lpCmdLine,		// ptr sur la ligne de commande (ie: argv[], argc)
     int nCmdShow)			// l'�tat de la fen�tre

{

	hInst = hInstance; 
	// Activer la bo�te de dialogue
    DialogBox(hInst, MAKEINTRESOURCE(IDD_DIALOG), NULL, ( DLGPROC ) DlgProc);
  
    return (0);
}
