	--   --        ^        ------ --   --   -----  -----
	| |  | |      / \      |  ---- | | / /  |  --- | --  \
	| |  | |     /   \     | |     |    /   | |    | --  /
	|  --  |    /  ^  \    | |     |    \   |  --- |    \
	|  --  |   /  ---  \   | |     | | \ \  | |    | | \ \
	| |  | |  / /     \ \  |  ---- | |  \ \ |  --- | |  \ \
	--   --   --       --   ------  --   --  ----- --    --

			            ----- ------  -----   -----   --    --
			           | ---- --  -- | --- | | --  \  | \  / |
			           | |      | |  | | | | | --  /  |  \/  |
			   -----   |  --    | |  | | | | |    \   | |  | |
			   -----   ---- |   | |  | | | | | | \ \  | |  | |
			           ---  |   | |  | --- | | |  \ \ | |  | |
			           -----    --    -----  --    -- --   --



Installation :

	Ces images sont � mettre dans un sous-r�pertoire de "skins" de Winamp.
	- Lancez winzip ou un programme du m�me genre.
	- S�l�ctionnez tous les fichiers
	- Faites Extraire
	- S�l�ctionnez votre r�pertoire Winamp
	  (par default lors de l'installation:c:\program files\winamp)
	- Faites extraire
	Les fichiers images devraient �tre copi� dans
	le r�pertoire "\Skins\WinAmpSkin - HackerStorm".


Configuration :

	Pour pouvoir mettre ce skin dans Winamp, il vous suffit de faire Alt+S
	lorsque vous avez lanc� Winamp et de s�l�ctionner le nom du sous-r�pertoire.

A propos:

	Ce skin a �t� cr�� par KoP pour le groupe HackerStorm.
	e-mail: KoP@HackerStorm.Com
	page web: Http://www.HackerStorm.Fr.St



				HackerStorm Team.All Right Reserved