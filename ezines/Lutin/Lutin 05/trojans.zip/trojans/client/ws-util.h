/***********************************************************************
 ws-util.h - Declarations for the Winsock utility functions module.
***********************************************************************/

#if !defined(WS_UTIL_H)
#define WS_UTIL_H

extern const char* WSAGetLastErrorMessage(const char* pcMessagePrefix);
extern bool ShutdownConnection(SOCKET sd);

#endif // !defined (WS_UTIL_H)

