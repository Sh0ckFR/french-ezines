/* SubSeven Daemon test pour ouinouin 
 inspir� par netbusd.c sur www.rootshell.org

(SyntaxError, syntax3rror@usa.net)
 */

#include <stdio.h>
#include <iostream.h>
#include <winsock2.h>

#define longtime 3000
#define waitport 27374
#define MAXLEN 524
#define MAXBUF 500

char line[MAXLEN];    
char command[100];
char *addy;
char *data;
int sockfd;
int sz;

char *longaddy(unsigned long ip);
int init_serv();
int send_to_idiot(char *format, ...);
int readln();
int writeln(char *buffer);
int datawatch(void);
int processline(void);


char *longaddy(unsigned long ip)
{
        unsigned long addr=ip;
        unsigned char *p;
        struct hostent *hp;
        static char h[139];   
        static char i[15];
       
        p=(unsigned char *)&ip;
        sprintf(i,"%u.%u.%u.%u",p[0],p[1],p[2],p[3]);
        hp=gethostbyaddr((char *)&addr,sizeof(addr),AF_INET);
        if (hp==NULL)
                return i;
        strcpy(h,hp->h_name);
        return h;
}

int init_serv()
{  
  int Sckt, NewSckt;
  int reuse_addr = 1;
  int sinlen;
  unsigned long iptemp;
  struct sockaddr_in saddr;
  Sckt = socket(AF_INET, SOCK_STREAM, 0);
  setsockopt(Sckt, SOL_SOCKET, SO_REUSEADDR,&reuse_addr,sizeof(reuse_addr));
  memset(&saddr, 0, sizeof(struct sockaddr_in));
  saddr.sin_family = AF_INET;
  saddr.sin_addr.s_addr = inet_addr("127.0.0.1");   //INADDR_ANY;
  saddr.sin_port = htons(waitport);
  sinlen = sizeof(saddr);
  if(bind(Sckt, (struct sockaddr *)&saddr, sizeof(struct sockaddr_in)) == SOCKET_ERROR)
        {
                exit(0);
        }
  listen(Sckt, 1);
  NewSckt = accept(Sckt, (struct sockaddr *) &saddr, &sinlen);
  iptemp=saddr.sin_addr.s_addr;
  addy=longaddy(iptemp);
  printf("Connect from [%s]\n",addy);
  closesocket(Sckt);
  sockfd=NewSckt;
  return 0;
}
 
int send_to_idiot(char *format, ...)
{
   va_list arglist;
   char buffer[MAXBUF];
   buffer[0]='\0';
   va_start(arglist, format);
   vsprintf(buffer, format, arglist);
   va_end(arglist);
   return(writeln(buffer));
}
                       

int readarg()
{
   int i = 3;

   if((sz = recv(sockfd, command, i, 0)) < 1)
   {
        printf("Connection lost to [%s]\n",addy);
        closesocket(sockfd);
        init_serv();
        datawatch();
		}
                

   command[i] = '\0';
   printf("Read:  %s\n", command);
   return 0;
}

int readln()
{
	int sz;
	   if((sz = recv(sockfd, command, 100, 0)) < 1)
	   {
	        printf("Connection lost to [%s]\n",addy);
	        closesocket(sockfd);
	        init_serv();
	        datawatch();
			}

   command[sz++] = '\0';
   printf("Read:  %s\n", command);
   return 0;
}

int writeln(char *buffer)
{
   if(send(sockfd, buffer, strlen(buffer), 0) < 0) return(0);
   printf("Sent: %s\n", buffer);
   return(-1);
}


int datawatch()
{
 readln();
 processline();
 datawatch();
 return(0);
}

int processline()
{

 if (strstr(command, "TTS") != NULL)
 {
        send_to_idiot("Sub7 v2.1");
        printf("[%s] Text2Speech\n",addy);
        return 0;
 }
 if (strstr(command, "DAK") != NULL)
 {
	         send_to_idiot("Sub7 v2.1");
 printf("[%s] Keyboard off\n",addy);
 return 0;
 }
 if(strstr(command, "TKSoff") != NULL)
 {
        send_to_idiot("Sub7 v2.1");
        printf("[%s] Keys/messages manager [off]\n",addy);
        return 0;
 }
 else if(strstr(command, "TKSon") != NULL)
 {
        send_to_idiot("Sub7 v2.1");
        printf("[%s] Keys/messages manager [on]\n",addy);
        return 0;
 }
 send_to_idiot("Sub7 v2.1");

  return 0;
}

int main(int argc, char **argv)
{



   // Start Winsock up
   WSADATA wsaData;
   if (WSAStartup(MAKEWORD(1, 1), &wsaData) != 0) {
      return 255;
   }

  printf("SubSeven Daemon 0.1 by SyntaxError running\n");
// if(fork()) exit(0);
 init_serv();
 send_to_idiot("connected. time/date: 01:15.56 - decembre 28, 1999, mardi, version: 2.1");
 datawatch();
 WSACleanup();
 return 0;
}