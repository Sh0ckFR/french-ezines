//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by res.rc
//
#define IDD_DIALOGA                     101
#define IDD_DIALOG                      101
#define IDI_ICON1                       102
#define IDD_DIALOG2                     103
#define IDD_DIALOG3                     104
#define IDD_DIALOG4                     105
#define IDD_DIALOGi                     109
#define IDC_CONNECT                     1000
#define IDC_IP                          1001
#define IDC_REBOOT                      1002
#define IDC_STATUS                      1003
#define IDC_OPEN                        1004
#define IDC_CLOSE                       1005
#define IDC_BEEP                        1006
#define IDC_CHAT                        1007
#define IDC_TITRE                       1008
#define IDC_TEXTE                       1009
#define IDC_SEND                        1013
#define IDC_FILE                        1014
#define IDC_BUTTON1                     1016
#define IDC_PROG                        1016
#define IDC_ENVOYER                     1016
#define IDC_ENV                         1016
#define IDC_BUTTON2                     1017
#define IDC_URL                         1017
#define IDC_BUTTON3                     1018
#define IDC_PARLE                       1018
#define IDC_BUTTON4                     1019
#define IDC_ABOUT                       1019
#define IDC_BOT                         1022
#define IDC_NAME                        1023
#define IDC_NOM                         1023
#define IDC_CHAN                        1024
#define IDC_CREATEBOT                   1025
#define IDC_URLTXT                      1026
#define IDC_PROGTXT                     1027
#define IDC_PORT                        1028
#define IDC_BUTTON5                     1029
#define IDC_GEN                         1029
#define IDC_TAB1                        1032
#define IDC_BUTTON6                     1036

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1038
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
