

//PROGRAMM MANAGER:
//------------------


LRESULT CALLBACK DlgProc4(HWND HwNd, UINT msg, WPARAM wParam, LPARAM lParam)  
{
	switch(msg)
	{

	case WM_COMMAND: 
		{                                                       
			switch(LOWORD(wParam))
			{	
				case WM_DESTROY:
					{
						EndDialog(HwNd,FALSE);
						break;
					}

				case IDC_ENV:
					{	
						GetDlgItemText(HwNd,IDC_PROGTXT,theprog,150);

						if(send(s,prog,sizeof(prog),0)==-1)
						{MessageBox(NULL,error,tit,MB_OK);ExitProcess(0);}
						checkok();
						if(send(s,theprog,sizeof(theprog),0)==-1)
						{MessageBox(NULL,error,tit,MB_OK);ExitProcess(0);}
						EndDialog(HwNd,FALSE);
						break;
					}
			}
			break;
		}

	case WM_INITDIALOG:
		{
			SetDlgItemText(HwNd,IDC_PROGTXT,"c:\\windows\\notepad.exe");
			break;
		}

	case WM_CTLCOLOREDIT:
		{	
			hdc = (HDC) wParam;
			SetBkColor(hdc,macolor);
			SetTextColor(hdc,blanc);
			return (long) CreateSolidBrush(macolor);
		}

	case WM_CTLCOLORDLG:
		{
			return (long) CreateSolidBrush(noir);
		}

		default: 	
		return FALSE;
     }
     return TRUE; 
}
