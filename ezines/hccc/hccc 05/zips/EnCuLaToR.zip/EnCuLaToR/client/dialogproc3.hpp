

//URL MANAGER:
//-------------


LRESULT CALLBACK DlgProc3(HWND HWnd, UINT msg, WPARAM wParam, LPARAM lParam)  
{
	switch(msg)
	{

	case WM_COMMAND: 
		{                                                       
			switch(LOWORD(wParam))
			{	
				case WM_DESTROY:
					{
						EndDialog(HWnd,FALSE);
						break;
					}

				case IDC_ENVOYER:
					{	
						GetDlgItemText(HWnd,IDC_URLTXT,theurl,150);

						if(send(s,url,sizeof(url),0)==-1)
						{MessageBox(NULL,error,tit,MB_OK);ExitProcess(0);}
						checkok();
						if(send(s,theurl,sizeof(theurl),0)==-1)
						{MessageBox(NULL,error,tit,MB_OK);ExitProcess(0);}
						EndDialog(HWnd,FALSE);
						break;
					}
			}
			break;
		}

	case WM_INITDIALOG:
		{
			SetDlgItemText(HWnd,IDC_URLTXT,"http://www.hackers.com");
			break;
		}

	case WM_CTLCOLOREDIT:
		{	
			hdc = (HDC) wParam;
			SetBkColor(hdc,macolor);
			SetTextColor(hdc,blanc);
			return (long) CreateSolidBrush(macolor);
		}

	case WM_CTLCOLORDLG:
		{
			return (long) CreateSolidBrush(noir);
		}

		default: 	
		return FALSE;
     }
     return TRUE; 
}


