



//----------------------------------------------------------------------
//
// TiP-TroYaN v0.1 par TiPiaX - Hccc
//
//----------------------------------------------------------------------



#include <windows.h>   // Le include de base de tout programme Windows
#include <Commctrl.h>
#include <stdio.h>

#include "resource.h"
#include "data.h"          //les variables
#include "fonctions.hpp"   //les prototypes et les fonctions basiques
#include "dialogproc.hpp"  //les fonctions g�rant les boites de dialogue
#include "dialogproc2.hpp"
#include "dialogproc3.hpp"
#include "dialogproc4.hpp"





int WINAPI WinMain(			
     HINSTANCE hInstance,	// handle sur l'instance pr�sente
     HINSTANCE hPrevInst,	// handle sur l'instance pr�c�dente (Win 3.1, obsol�te)
     LPSTR lpCmdLine,		// ptr sur la ligne de commande (ie: argv[], argc)
     int nCmdShow)			// l'�tat de la fen�tre

{

	hInst = hInstance;
    DialogBox(hInst, MAKEINTRESOURCE(IDD_DIALOG), NULL, ( DLGPROC ) DlgProc);
  
    return (0);
}
