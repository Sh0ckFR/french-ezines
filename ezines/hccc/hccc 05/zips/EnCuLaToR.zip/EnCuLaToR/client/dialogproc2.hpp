


//LE MANAGER DE BOITE DE DIALOGUES:
//-----------------------------------


LRESULT CALLBACK DlgProc2(HWND Hwnd, UINT msg, WPARAM wParam, LPARAM lParam)  
{
	switch(msg)
	{
	case WM_COMMAND: 
		{                                                       
			switch(LOWORD(wParam))
			{
				case IDC_SEND:
					{	
						GetDlgItemText(Hwnd,IDC_TITRE,titre,100);
						GetDlgItemText(Hwnd,IDC_TEXTE,parole,100);

						if(send(s,chat,sizeof(chat),0)==-1)
						{MessageBox(NULL,error,tit,MB_OK);ExitProcess(0);}

						checkok();
						if(send(s,titre,sizeof(titre),0)==-1)
						{MessageBox(NULL,error,tit,MB_OK);ExitProcess(0);}
						
						checkok();
						if(send(s,parole,sizeof(parole),0)==-1)
						{MessageBox(NULL,error,tit,MB_OK);ExitProcess(0);}

						EndDialog(Hwnd,FALSE);

						break;
					}
					
				case WM_DESTROY:
					{
						EndDialog(Hwnd,FALSE);
						break;
					}
			}
			break;
		}

	case WM_INITDIALOG:
		{
			SetDlgItemText(Hwnd,IDC_TITRE,"Salut");
			SetDlgItemText(Hwnd,IDC_TEXTE,"T'as le bonjour de TiPiaX");
			break;
		}

	case WM_CTLCOLOREDIT:
		{	
			hdc = (HDC) wParam;
			SetBkColor(hdc,macolor);
			SetTextColor(hdc,blanc);
			return (long) CreateSolidBrush(macolor);
		}

	case WM_CTLCOLORDLG:
		{
			return (long) CreateSolidBrush(noir);
		}
	case WM_CTLCOLORSTATIC:
		{
			hdc = (HDC) wParam;
			SetTextColor(hdc,macolor4);
			SetBkColor(hdc,noir);
			return (long) CreateSolidBrush(noir);
		}

		default: 	
		return FALSE;
     }
     return TRUE; 
}

