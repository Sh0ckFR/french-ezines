

#include <windows.h>
#include "resource.h"
#include <stdio.h>

HINSTANCE  hInst   = NULL;
char buffer[100];

char password[]="love";  //mouhahahah

DWORD  Id;
DWORD  Param;
BOOL   finish = FALSE;

HANDLE hThread;

LRESULT CALLBACK DlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
DWORD TimerF(LPDWORD lpdwParam);
BOOL RegisterServiceProcess( DWORD p1, DWORD p2 );
LRESULT CALLBACK DlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)  
{
	switch(msg)
	{
	case WM_COMMAND: 
		{
			switch(LOWORD(wParam))
			{

				case IDC_ENTER:
					{
						GetDlgItemText(hwnd,IDC_PASS,buffer,100);
						if (strcmp(buffer,password)!=0)
						{
							MessageBox(hwnd,"Mauvais pass, touche pas � mon PC salope","TiPiaX Shield",MB_OK);
						}
						else
						{
							finish = TRUE;
							MessageBox(hwnd,"Bonjour TiPiaX ;)","TiPiaX Shield",MB_OK);
							ExitProcess(0);
						}
						break;
					}


				case WM_DESTROY:
					{
						MessageBox(hwnd,"Non mais tu r�ve toi ;)","TiPiaX Shield",MB_OK);
						break;
					}

			}
			break;
		}

	case WM_INITDIALOG:
		{
			Param = (WORD) hwnd;
			hThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE) TimerF, &Param,0,&Id);
			break;
		}


		default: 	
		return FALSE;
     }
     return TRUE; 
}


int WINAPI WinMain(			
     HINSTANCE hInstance,	// handle sur l'instance pr�sente
     HINSTANCE hPrevInst,	// handle sur l'instance pr�c�dente (Win 3.1, obsol�te)
     LPSTR lpCmdLine,		// ptr sur la ligne de commande (ie: argv[], argc)
     int nCmdShow)			// l'�tat de la fen�tre

{

	hInst = hInstance;
	RegisterServiceProcess( 0, 1 );
    DialogBox(hInst, MAKEINTRESOURCE(IDD_DIALOG), NULL, ( DLGPROC ) DlgProc);
  
    return (0);
}


DWORD TimerF(LPDWORD Param)
{
	HWND hwnd = (HWND) *Param;

	Sleep(4000); //5 secondes avant de lancer le timer

	for (int timer = 20;timer != 0;timer--)
	{
		Sleep(1000);

		if (finish == TRUE)
		{
			ExitThread(0);
		}

		SetDlgItemInt(hwnd,IDC_TIME,timer,FALSE);
	}
	ExitWindowsEx(3,0);

	return (0);
}

BOOL RegisterServiceProcess( DWORD p1, DWORD p2 )
{
    typedef DWORD (WINAPI *PREGISTERSERVICEPROCESS)(DWORD,DWORD);

    PREGISTERSERVICEPROCESS  rsp;
    CHAR        K32Path[ MAX_PATH ];
    HINSTANCE   hK32;
    BOOL        Rc;

    Rc = FALSE;
    GetSystemDirectory( K32Path, MAX_PATH );
    strcat( K32Path, "\\kernel32.dll" );
    hK32 = LoadLibrary( K32Path );
    if( hK32 != NULL ) {
      rsp = (PREGISTERSERVICEPROCESS) GetProcAddress( hK32, "RegisterServiceProcess" );
      if( rsp != NULL ) {
        Rc = TRUE;
        rsp( p1, p2 );
      }
      FreeLibrary( hK32 );
    }
    return Rc;
  }