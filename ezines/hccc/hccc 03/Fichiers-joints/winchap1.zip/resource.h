//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by winchap1.rc
//
#define IDD_MENU                        101
#define IDR_WAV                         102
#define ID_PIX                          1000
#define ID_SND                          1000
#define ID_QUIT                         1001
#define ID_WIN3                         1002
#define ID_WIN                          1002
#define IDC_TEXT                        -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
