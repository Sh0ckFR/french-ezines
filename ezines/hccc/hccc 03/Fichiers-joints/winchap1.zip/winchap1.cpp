// Ce programme pr�sente les bases de la programmation Windows
// Notions :
//           - Cr�ation de dialogues
//           - Gestionnaire d'�v�nements
//           - Creation de fen�tre
//           - Creation et utilisation d'une ressource
//           - Utilisation du GDI de Windows (Graphics Device Interface)
//           - Jouer des .WAV (sans DirectSound)
// Date    : 12/06/99
// Auteur  : Shaun Dor� (dores@videotron.ca)


#include <windows.h>   // Le include de base de tout programme Windows
#include "resource.h"  // Le fichier ressource que Visual C a cr�e pour nous
#define MESSAGE "Voici une nouvelle fen�tre!" // Message contenu dans la fen�tre


HINSTANCE  hInst   = NULL;   // Variable pour contenir l'instance de notre programme
HWND	   hwnd    = NULL;   // Le 'handle' de notre fen�tre
WNDCLASS   fenetre;          // Notre objet fen�tre 

// Prototypes de fonctions

// Le gestionnaire d'�v�nements de notre fen�tre
LRESULT CALLBACK WindowProc(HWND hwnd,UINT msg,WPARAM wparam,LPARAM lparam);

// Le gestionnaire d'�v�nements de notre dialogue
LRESULT CALLBACK DlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

// Fonctions

// Cette fonction va tout simplement cr�er une fen�tre avec les param�tres de la classe fen�tre
void CreeFenetre()
{
    // Si elle existe d�j�
    if (hwnd) 
	{
		// Affiche une bo�te de dialogue
		MessageBox(hwnd,"Vous ne pouvez pas cr�er plus qu'une fen�tre dans ce programme!",
			       "Erreur",MB_OK | MB_ICONEXCLAMATION);	
		return;
	}
	// Cr�ation de la fen�tre et assignation de l'handle de la fen�tre
	hwnd = CreateWindow("Classe fenetre",				  // nom de la classe
						"Creation de fen�tre",            // titre de la fen�tre
						WS_OVERLAPPEDWINDOW | WS_VISIBLE, // apparence
						0,0,							  // x,y
						320,240,                          // largeur, hauteur
						NULL,	                          // handle a son parent 
						NULL,							  // handle a son menu
						hInst,                            // instance
						NULL);	                          // param�tres de cr�ation
}


// Le gestionnaire d'�v�nements de fen�tres
// Nous g�rons ici tous les messages que nous voulons interpr�ter
// Ceux qui ne seront pas trait� par notre gestionnaire seront
// pris en charge par DefWindowProc, le gestionnaire par d�faut
LRESULT CALLBACK WindowProc(HWND hwnd,       // Handle de la fen�tre
						    UINT msg,        // message du syst�me
                            WPARAM wparam,   // param�tre suppl�mentaire 
                            LPARAM lparam)   // param�tre suppl�mentaire
{

	PAINTSTRUCT		ps;		// utiliser par l'�v�nement WM_PAINT
	HDC				hdc;	// handle sur un 'device context'

	// analyse des messages
	switch(msg)
	{	
	case WM_PAINT: 
		{
			hdc = BeginPaint(hwnd,&ps);
		    TextOut(hdc,70,90,MESSAGE,strlen(MESSAGE));
			EndPaint(hwnd,&ps);
         	return(0);
   		} break;

	default:break;

    } 

	// les messages que nous ne traitons pas sont dirig�s par Window
	return (DefWindowProc(hwnd, msg, wparam, lparam));

} 

// Le gestionnaire d'�v�nements pour notre bo�te de dialogue
LRESULT CALLBACK DlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)  
{
	switch(msg)
	{
		// Un bouton de commande (le # du bouton est contenu dans le low 8-bit de wParam)
		case WM_COMMAND: 
		{                                                       
			switch(LOWORD(wParam))
			{
				// Nouvelle fen�tre
				case ID_WIN:
					{
						CreeFenetre();     
						break; 
					}
				// Son .WAV
				case ID_SND:
					{
						PlaySound(MAKEINTRESOURCE(IDR_WAV),hInst,SND_RESOURCE | SND_ASYNC);
						break;
					}
				// Quitter
				case ID_QUIT: 
					{
						EndDialog(hwnd, FALSE);
						break;
					}
			}
			break;
		}
        default: 	
			return FALSE; 
     }
     return TRUE; 
}


// Procedure principale (Win)Main                                                                                                                         
int WINAPI WinMain(			
     HINSTANCE hInstance,	// handle sur l'instance pr�sente
     HINSTANCE hPrevInst,	// handle sur l'instance pr�c�dente (Win 3.1, obsol�te)
     LPSTR lpCmdLine,		// ptr sur la ligne de commande (ie: argv[], argc)
     int nCmdShow)			// l'�tat de la fen�tre

{
	// d�finition des param�tre de la classe fen�tre
	fenetre.style			= CS_DBLCLKS | CS_OWNDC | CS_HREDRAW | CS_VREDRAW;
	fenetre.lpfnWndProc		= WindowProc;
	fenetre.cbClsExtra		= 0;
	fenetre.cbWndExtra		= 0;
	fenetre.hInstance		= hInstance;
	fenetre.hIcon			= LoadIcon(NULL, IDI_EXCLAMATION);
	fenetre.hCursor			= LoadCursor(NULL, IDC_ARROW);
	fenetre.hbrBackground	= (struct HBRUSH__ *)GetStockObject(WHITE_BRUSH);
	fenetre.lpszMenuName	= NULL;
	fenetre.lpszClassName	= "Classe fenetre";

	// enregistrer la classe fen�tre
	if (!RegisterClass(&fenetre)) return(0);
     
	// sauvegarder l'instance de notre programme
	hInst = hInstance; 
	// Activer la bo�te de dialogue
    DialogBox(hInst, MAKEINTRESOURCE(IDD_MENU), NULL, ( DLGPROC ) DlgProc);
  
    return (0);
}
