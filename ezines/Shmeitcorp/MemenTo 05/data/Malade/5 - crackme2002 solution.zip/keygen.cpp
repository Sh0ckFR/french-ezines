// keygen.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "resource.h"
#include <string.h>
#include <stdlib.h>

char name1[20];
char name2[20];
char name[50];
char serie[21];



BOOL CALLBACK DialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);


int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
 	// TODO: Place code here.
DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, DialogProc, NULL);
return 0;
}

BOOL CALLBACK DialogProc(
  HWND hwndDlg,  // handle to dialog box
  UINT uMsg,     // message
  WPARAM wParam, // first message parameter
  LPARAM lParam  // second message parameter
)
{

switch (uMsg)
	{
	case WM_CLOSE :
	EndDialog(hwndDlg, NULL);
	break;

	case WM_COMMAND :

	switch(LOWORD(wParam))
		{
		case IDOK :
			int nbr1, nbr2, nbr, serial;

			nbr1=GetDlgItemText(hwndDlg, IDC_EDIT1, name1, 21);
			nbr2=GetDlgItemText(hwndDlg, IDC_EDIT2, name2, 21);
			nbr = nbr1 + nbr2 + 5;

			strcpy (name, name1);
			strcat (name, "n-gen");
			strcat (name, name2);

			__asm
				{

				mov ebx, 0FFh
				mov ecx, nbr
				mov edx, 1

				boucle1:
				lea eax, name
				movzx eax, [eax+edx-1]
				imul eax, eax, 15B3h
				add ebx, eax
				imul eax, edx, 15B3h
				add ebx, eax
				mov eax, ebx
				inc edx
				dec ecx
				jnz boucle1


				mov ecx, nbr
				mov edx, 1

				boucle2:
				lea eax, name
				movzx eax, [eax+edx-1]
				imul eax, eax, 8AEh
				add ebx, eax
				imul eax, edx, 8AEh
				add ebx, eax
				mov eax, ebx
				inc edx
				dec ecx
				jnz boucle2


				mov ecx, nbr
				mov edx, 1

				boucle3:
				lea eax, name
				movzx eax, [eax+edx-1]
				imul eax, eax, 22B8h
				add ebx, eax
				imul eax, edx, 22B8h
				add ebx, eax
				mov eax, ebx
				inc edx
				dec ecx
				jnz boucle3

				mov serial, ebx


				}

		_itoa (serial, serie, 10);
		SetDlgItemText (hwndDlg, IDC_EDIT3, serie);

		break;

		case IDCANCEL :
			SendMessage(hwndDlg, WM_CLOSE, NULL, NULL);
		break;

		case IDC_BUTTON1:
		int nbr3, i;
		unsigned long nbrCopie;
		HANDLE fic;
		char contenu[100];

		nbr3=GetDlgItemText(hwndDlg, IDC_EDIT4, name, 21);

		for (i=0;i<lstrlen(name);i++)
			{
			serie[i]=name[i]+(i+1+(2*(i+1)));
			}

		serie[i]='\0';

		SetDlgItemText (hwndDlg, IDC_EDIT6, serie);

		strcpy (contenu, name);
		strcat (contenu, serie);


		fic=CreateFile ("n-gen.key", GENERIC_WRITE | GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, CREATE_ALWAYS, NULL, NULL);
		WriteFile (fic, contenu, 2*nbr3, &nbrCopie, NULL);
		CloseHandle (fic);

		MessageBox (hwndDlg, "Fichier keyfile cr�� !", "Keyfile", MB_OK);

		break;


		case IDC_BUTTON2:
		int nbr4;
		HKEY hkey;
		DWORD result;

		nbr4=GetDlgItemText(hwndDlg, IDC_EDIT5, name, 21);
		serial=0;


		__asm{

			mov ebx, nbr4
			mov eax, 1

			boucle4:
			lea edx, name
			movzx edx, [edx+eax-1]
			imul edx, edx, 0D05h
			add edx, serial
			add edx, 0Ah
			mov serial, edx
			inc eax
			dec ebx
			jnz boucle4


			}

		_itoa (serial, serie, 10);
		SetDlgItemText (hwndDlg, IDC_EDIT7, serie);

		RegCreateKeyEx (HKEY_LOCAL_MACHINE, "Software\\Microsoft\\Windows\\RegCrkme", 0, NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &hkey, &result);
		RegSetValueEx (hkey, "key", 0, REG_SZ, (CONST BYTE *) serie, strlen(serie));
		RegSetValueEx (hkey, "nom", 0, REG_SZ, (CONST BYTE *) name, strlen(name));
		RegCloseKey (hkey);

		MessageBox (hwndDlg, "Registre Windows mis � jour !", "Registre Windows", MB_OK);


		break;

		}

	break;

	}
return FALSE;
}

