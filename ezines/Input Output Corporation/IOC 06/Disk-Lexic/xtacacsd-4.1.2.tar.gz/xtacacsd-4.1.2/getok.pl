#! /usr/local/bin/perl
# A starting point for a getok script in perl.
# Beware: due to the way getok is called, its standard input/output
# are not available for 'live' debugging. Hence the mail command below
# to extract parameters from a real tacacs session and test the script 
# interactively by replaying these parameters later.

$user=$ARGV[0];    # username from Access Server
$gid=$ARGV[1];     # GID from password file or QI
$host=$ARGV[2];    # Access Server hostname
$line=$ARGV[3];    # Access Server line number
$type=$ARGV[4];    # Tacacs request type
$options=$ARGV[5]; # Tacacs request options flags
$gecos=$ARGV[6];   # GECOS field from password file or QI

if ($user eq "test") {
   system "echo U=$user G=$gid H=$host L=$line T=$type O=$options F=$gecos | mail -s TACACS root";
}

exit 1;

