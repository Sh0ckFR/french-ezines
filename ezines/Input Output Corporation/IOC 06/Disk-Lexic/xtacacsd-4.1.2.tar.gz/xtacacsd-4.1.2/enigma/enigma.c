#define FALSE 0
#define TRUE 1

#define DEBUG1

#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <sys/file.h>

#include <netinet/in.h>

#include <stdio.h>
#include <errno.h>
#include <pwd.h>
#include <netdb.h>
#include <sys/syslog.h>
#include <utmp.h>

#ifdef SYSV
#include <fcntl.h>
#define index strchr
#endif



/*
 * main function begins here. Handle differences in the way we
 * are invoked; We can be called from inetd or via the rc scripts.
 * Parse arguments and act appropiately.
 */

main(argc, argv)
int argc;
char **argv;
{
	
	if (argc != 3) {
		fprintf(stderr,"Usage %s username password\n", argv[0]);
		exit(0);
	}

	if(SafeWordPassed(argv[1], argv[2])) {
#ifdef DEBUG
		fprintf(stderr,"%s: Passwed Authentication code = 1\n", argv[0]);
#endif
		exit(1);
	} else {
#ifdef DEBUG
		fprintf(stderr,"%s: Failed Authentication code = 0\n", argv[0]);
#endif
		exit(0);
	}
}



int
SafeWordPassed(name, passwd )
char 	*name, *passwd;
{
	char DynamicPassWord[18];
	char DynamicPassWordIndex = 0;
	char FixedPW[18];
	char FixedPWIndex = 0;
	char NewFixedPassword[18];
	char RptNewFixed[18];
	char pwIndex = 0;
	char NewPwIndex =0;
	char RptNewPWIndex=0;
	char CommaFound = FALSE;
	char SecondCommaFound = FALSE;
	char ThirdCommaFound = FALSE;


	FixedPW[FixedPWIndex]=0;
	DynamicPassWord[DynamicPassWordIndex]=0;
	NewFixedPassword[NewPwIndex]=0;
	RptNewFixed[RptNewPWIndex]=0;
#ifdef DEBUG
	fprintf(stderr,"DEBUG: userid (%s) passwd_dyn(%s) ", name,
		 passwd);
	fprintf(stderr,"passwd_fixed (%s) new_fixed (%s), repeat (%s)\n",
			FixedPW, NewFixedPassword, RptNewFixed);
#endif

	if(DoId1(name,passwd,FixedPW,NewFixedPassword,RptNewFixed)) {
		return(1);
	} else {
		return(0);
	}
}
