/* $Header */

/*
 * This header file just replaces alternate structures in the taclast.h
 * file so that we can store accounting records (tacacct.c)
 */

struct acctstats {			/* 0 = WKDAY, 1 = WKEND, 2 = HOLIDAY */
  time_t	totsecs[8][3];		/* assume max 8 ranges in day */
  time_t	errsecs[8][3];
};

/* Following structure is used to gather time information */
typedef struct arg {
  char		*name;				/* argument */
  char		*groupid;			/* For USEr type's */
  time_t	errsecs;			/* inaccurate seconds */
  time_t  	totsecs;			/* total seconds NOTE */
  time_t	maxsecs;			/* largest online time */
  int		count;				/* total number of entries */
#define	HOST_TYPE	-2
#define	TTY_TYPE	-3
#define	USER_TYPE	-4
  struct acctstats	*ac;			/* ptr to accounting struct */
  struct arg		*next;			/* linked list pointer */
} ARG;

