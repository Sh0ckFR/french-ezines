int ldap_verify();
