/*
 * pt_sh : pt_box.h
 */

#ifndef __PT_BOX_H__
#define __PT_BOX_H__

int childrunning();
void restart(char *argv[]);
void get_addr(unsigned long addr);
void set_addr(unsigned long addr, long int value);
void hexdump(unsigned long addr, long size, int byteprec);
void print_map();
void dumpfile(unsigned long addr, long size, char *outfile);
void get_regs(char *reglist[]);
void set_reg(char *sreg, unsigned long value);
void send_sig(int sig);
void step();
void mgoto(unsigned long addr);
void cont();
void next();
void end();
void break_syscall(int syscall);
void break_signal(int sig);

#endif
