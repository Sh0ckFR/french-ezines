/*
 * pt_sh : pt_symbol.h
 */

#ifndef __PT_SYMBOL_H__
#define __PT_SYMNOL_H__

int get_syscall(char*);
int get_signum(char*);
char *get_syscallname(int);
char *get_signalname(int);

#endif
