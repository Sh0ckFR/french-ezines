/*
 * pt_sh : pt_lib.h
 */

#ifndef __PT_LIB_H__
#define __PT_LIB_H__

void                     pt_traceme();
long int                 pt_peek(pid_t, unsigned long);
void                     pt_poke(pid_t, unsigned long, long int);
struct user_regs_struct* pt_getregs(pid_t);
void                     pt_setregs(pid_t, struct user_regs_struct*);
struct user_fxsr_struct* pt_getfpregs(pid_t);
void                     pt_setfpregs(pid_t, struct user_fxsr_struct*);
void                     pt_cont(pid_t);
unsigned int             pt_syscall(pid_t);
void                     pt_step(pid_t);
void                     pt_goto(pid_t, unsigned long);
void                     pt_kill(pid_t);
void                     pt_detach(pid_t);
pid_t                    run_target(char**);
int                      wait_signal(pid_t);
int                      next_signal(pid_t, int);

#endif
