<html>
<body>
<center>
<h1>Liste des comptes disponibles</h1><br>
<table border=1>
<tr><td><b>Login</b></td><td><b>Password</b></td></tr>
<?php
require_once("config.php");
$db = mysql_connect($host,$user,$pass);
mysql_select_db($database,$db);
$query="SELECT * FROM membres";
$req=mysql_query($query);
while($q=mysql_fetch_row($req))
  echo "<tr><td>".htmlspecialchars($q[1],ENT_QUOTES)."</td><td>".htmlspecialchars($q[2],ENT_QUOTES)."</td></tr>\n";
?>
</table>
<br>
<a href="index.htm">Revenir &agrave; l'index</a>
</center>
</body>
</html>