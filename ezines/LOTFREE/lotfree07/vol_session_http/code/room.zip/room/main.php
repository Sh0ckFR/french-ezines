<html>
<body>
<?php
session_start();
if(!isset($_SESSION['login']))
{
	header("Location: index.htm");
	exit;
}
echo "<center>Bienvenue ".htmlspecialchars($_SESSION['login'],ENT_QUOTES)."</center><br><br>\n";
echo "<a href=\"account.php\">Modifier mes infos</a><br>\n";
echo "<a href=\"post.php\">Envoyer un msg &agrave; un membre</a><br>\n";
echo "<a href=\"msg.php\">Lire mes messages</a><br>\n";
echo "<a href=\"logout.php\">Se d&eacute;connecter</a><br>\n";
?>
</body>
</html>