<html>
<body>
<?php
session_start();
if(!isset($_SESSION['login']))
{
	header("Location: index.htm");
	exit;
}

if(isset($_POST['login']) && isset($_POST['msg']) && $_POST['login']!="" && $_POST['msg']!="")
{
	require_once("config.php");
	$login=$_POST['login'];
	$msg=addslashes($_POST['msg']);
	$db = mysql_connect($host,$user,$pass);
	mysql_select_db($database,$db);
	$query="SELECT * from membres WHERE login='".addslashes($login)."'";
	$req=mysql_query($query);
	if(!$req)exit;
	$data=mysql_fetch_object($req);
	$id=$data->id;
	mysql_query("INSERT INTO msg (msg, id) values ('$msg', $id)");
	mysql_close($db);
}
else
{
	echo "<form action=\"post.php\" method=\"POST\">\n";
	echo "Destinataire : <input type=\"text\" name=\"login\"><br>\n";
	echo "Message :<br><textarea name=\"msg\" cols=\"100\" rows=\"3\"></textarea><br>\n";
	echo "<input type=submit value=\"Envoyer\">\n";
	echo "</form>\n";
}
	
echo "<a href=\"account.php\">Modifier mes infos</a><br>\n";
echo "<a href=\"post.php\">Envoyer un msg &agrave; un membre</a><br>\n";
echo "<a href=\"msg.php\">Lire mes messages</a><br>\n";
echo "<a href=\"logout.php\">Se d&eacute;connecter</a><br>\n";
?>
</body>
</html>