<html>
<body>
<?php
session_start();
if(!isset($_SESSION['login']))
{
	header("Location: index.htm");
	exit;
}
$login=$_SESSION['login'];

require_once("config.php");
$db = mysql_connect($host,$user,$pass);
mysql_select_db($database,$db);
$query="SELECT * from membres WHERE login='".addslashes($login)."'";
$req=mysql_query($query);
$data=mysql_fetch_object($req);
$id=$data->id;

$query="SELECT idmsg, msg FROM msg WHERE id=".addslashes($id)."";
$req=mysql_query($query);
while($q=mysql_fetch_row($req))
  echo "---<br>\n".$q[1]."<br>\n<a href=\"suppr.php?idmsg=".$q[0]."\">Supprimer</a><br>\n---<br>\n";
mysql_close($db);
  
echo "<a href=\"account.php\">Modifier mes infos</a><br>\n";
echo "<a href=\"post.php\">Envoyer un msg &agrave; un membre</a><br>\n";
echo "<a href=\"msg.php\">Lire mes messages</a><br>\n";
echo "<a href=\"logout.php\">Se d&eacute;connecter</a><br>\n";
?>
</body>
</html>