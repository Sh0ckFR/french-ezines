<?
session_start();
$login=$_POST['login'];

$password=$_POST['password'];

require_once("config.php");
$db = mysql_connect($host,$user,$pass);
mysql_select_db($database,$db);
$req = mysql_query("SELECT passwd FROM membres WHERE login='".addslashes($login)."'") or die("Erreur � la connexion");


$data=mysql_fetch_object($req);
mysql_close($db);

if($data->passwd != $password)
{
	header("Location: index.htm");
	exit;
}
else
{
	$_SESSION['login']=$login;
	header("Location: main.php");
	exit;
}

?>