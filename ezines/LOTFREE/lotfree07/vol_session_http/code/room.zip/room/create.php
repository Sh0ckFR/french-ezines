<?php
require_once("config.php");
$db = mysql_connect($host,$user,$pass);
mysql_select_db($database,$db);

mysql_query("DROP TABLE IF EXISTS `membres`;");

$query ="CREATE TABLE `membres` (";
$query.="  `id` tinyint(3) unsigned NOT NULL default '0',";
$query.="  `login` varchar(20) NOT NULL default '',";
$query.="  `passwd` varchar(20) NOT NULL default '',";
$query.="  PRIMARY KEY  (`id`)";
$query.=") TYPE=MyISAM;";
mysql_query($query);

mysql_query("INSERT INTO `membres` VALUES (0, 'root', 'root');");
mysql_query("INSERT INTO `membres` VALUES (1, 'toto', 'toto');");

mysql_query("DROP TABLE IF EXISTS `msg`;");

$query ="CREATE TABLE `msg` (";
$query.="  `idmsg` tinyint(3) unsigned NOT NULL auto_increment,";
$query.="  `msg` mediumtext NOT NULL,";
$query.="  `id` tinyint(3) unsigned NOT NULL default '0',";
$query.="  PRIMARY KEY  (`idmsg`)";
$query.=") TYPE=MyISAM AUTO_INCREMENT=19 ;";

mysql_query($query);

mysql_query("INSERT INTO `msg` VALUES (0, 'salut <i>toto</i>', 1);");
?>