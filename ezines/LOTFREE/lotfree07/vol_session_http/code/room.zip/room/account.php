<html>
<body>
<center>
<?
require_once("config.php");
session_start();
if(!isset($_SESSION['login']))
{
	header("Location: index.htm");
	exit;
}

$login=$_SESSION['login'];

$db = mysql_connect($host,$user,$pass);
mysql_select_db($database,$db);

if(isset($_POST['log']) && isset($_POST['passe']) && $_POST['log']!="" && $_POST['passe']!="")
{
	$query="SELECT * from membres WHERE login='".addslashes($login)."'";
	$req=mysql_query($query);
	$data=mysql_fetch_object($req);
	$id=$data->id;
	echo "id=$id<br>\n";
	$query ="UPDATE membres ";
	$query.="SET login='".addslashes($_POST['log'])."', passwd='".addslashes($_POST['passe'])."' ";
	$query.="WHERE id=".addslashes($id).";";
	echo htmlspecialchars($query,ENT_QUOTES)."<br>\n";
	$req = mysql_query($query) or die("Erreur � la connexion");
	$_SESSION['login']=$_POST['log'];
	mysql_query("commit");
}
else
{
	$query="SELECT * from membres WHERE login='".addslashes($login)."'";
	$req=mysql_query($query);
	$data=mysql_fetch_object($req);
	echo "<form action=\"account.php\" method=\"POST\">\n";
	echo "Login : <input type=\"text\" name=\"log\" value=\"";
	echo htmlspecialchars($data->login,ENT_QUOTES);
	echo "\"><br>\n";
	echo "Password : <input type=\"password\" name=\"passe\" value=\"";
	echo htmlspecialchars($data->passwd,ENT_QUOTES);
	echo "\"><br>\n";
	echo "<input type=\"submit\" value=\"Mettre a jour\"><br>\n";
	echo "</form>\n";
}

mysql_close($db);
echo "<br><br><a href=\"account.php\">Modifier mes infos</a><br>\n";
echo "<a href=\"post.php\">Envoyer un msg &agrave; un membre</a><br>\n";
echo "<a href=\"msg.php\">Lire mes messages</a><br>\n";
echo "<a href=\"logout.php\">Se d&eacute;connecter</a><br>\n";
?>
</center>
</body>
</html>