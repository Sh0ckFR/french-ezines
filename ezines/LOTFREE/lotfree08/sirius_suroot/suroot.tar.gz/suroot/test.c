#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>

int main(int argc,char *argv[])
{
  int dn;

  printf("You must use this program first to know if suroot will work.\n");
  printf("* you get a 'Password:' prompt -> it's good !\n");
  printf("* you get 'su : must be run from a terminal' -> won't work !\n");
  printf("--------------- press a key to continue ---------------\n");
  getchar();
  dn=open("/dev/null",O_RDWR);
  close(0);
  close(1);
  dup2(dn,0);
  dup2(dn,1);
  execl("/bin/su","/bin/su",(char *)0);
  close(dn);
  return 0;
}
