#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>

#define PASSLOG "/tmp/.sb"

int main(int argc,char *argv[])
{
  FILE *fd;
  int c;
  
  if(argc>1)
  {
    if((fd=fopen(argv[1],"rb"))==NULL)
    {
      perror("fopen");
      exit(1);
    }
  }
  else
  {
    if((fd=fopen(PASSLOG,"rb"))==NULL)
    {
      perror("fopen");
      exit(1);
    }
  }
  while((c=fgetc(fd))!=EOF)
    putchar(c^0xFF);
  putchar(10);
  return 0;
}
   
