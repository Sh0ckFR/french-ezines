unsigned short in_cksum(u_short *addr, int len);
void gettcppkt(int s, char *buf, int size);
void sendtcppkt(int sock,u_long src,u_long dst,u_short sprt,u_short dprt,
                u_long seq,u_long ack,unsigned char flagz,char *data,int dlen);
