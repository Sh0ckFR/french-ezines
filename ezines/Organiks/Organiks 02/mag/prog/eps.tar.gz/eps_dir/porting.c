#include "phreax.h"

#ifdef linux
void clrscr(void)
{
	printf("\e[2J");
	printf("\e[H");
}

int getch(void)
{
    int ch, ret;

    /*cooked_term();*/
    
    while (0 == SLang_input_pending(1000))
        continue;
    ch = SLang_getkey();

    if (ch == 033) {
        if (0 == SLang_input_pending(0))
            return(033);
    }
    SLang_ungetkey(ch);
    ret=SLkp_getkey();
    /*raw_term();*/
    return(ret);
}

#endif	/* linux */


void cooked_term(void)
{
#ifdef linux
	SLtt_get_terminfo();
	if (-1 == SLkp_init()) {
		SLang_doerror("SLkp_init failed.");
		exit(1);
    }
	if (-1 == SLang_init_tty(-1, 0, 1)) {
		SLang_doerror("SLang_init_tty failed.");
		exit(1);
	}
#endif	/* linux */
}


void raw_term(void)
{
#ifdef linux
    SLang_reset_tty();
#endif	/* linux */
}


void init_cr(void)
{
#ifndef linux
	cr[0] = 0x0d;
	cr[1] = 0x0a;
#endif	/* ! linux */

#ifdef linux
	cr[0] = 0x0a;
	cr[1] = 0;
#endif	/* linux */
}
