#include <stdio.h>
#include <stdlib.h>

#ifndef linux
	#include <conio.h>
#endif	/* ! linux */

#ifdef linux
	#include <slang/slang.h>
#endif	/* linux */

#ifdef linux
	extern void clrscr(void);
	extern int getch(void);
#endif

/* slang fcts */
extern void cooked_term(void);
extern void raw_term(void);
extern void init_cr(void);

extern void bad_cmd_line(void);
extern void wait(int);

char cr[2];
char numero[20];

FILE *chat, *numbers_file, *outfile, *resume_file, *config_file;
