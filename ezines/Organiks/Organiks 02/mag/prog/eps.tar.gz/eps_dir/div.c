#include "phreax.h"

void wait(int s)
{
    sleep(s);
}
