#include "phreax.h"

void print_title()
{
    printf("\n\t\t    Easy PPP Scaner 0.9.2 - By Jacko\n");
}

void bad_cmd_line()
{
    printf("\nUsage : ./pppscan <numbers_file> <options>\n\n");
    printf("Options : -o               : you have to coment each call\n");
    printf("          -g               : generate <numbers_file> from argv[1]\n");
    printf("          -t <timeout>     : (default = 13)\n");
    printf("          -p <prefix>      : (default = 3651)\n");
    printf("          -s <sufix>       : (default = )\n");
    printf("          -r               : resumming\n");
    printf("          -d               : debug mode\n");
    printf("          -htm             : output in html\n\n");
    
    exit(0);
}

void scan_help()
{
    printf("\nHelp to scan :\n");
    printf("	n : non attribue\n");
    printf("	x : non accessible\n");
    printf("	r : a rapeler\n");
    printf("	o : occupe\n");
    printf("	s : sonne\n");
    printf("	g : repond\n");    
    printf("	f : fax\n");
    printf("	m : modem\n");    
    printf("	e : repondeur\n\n");
    printf("	a : commentaire\n\n");
}

void scan_cmd_help()
{
    printf("\nCommands :\n");
    printf("	rec           : call last number scanned\n");
    printf("	to:<timeout>  : change timeout\n");
    printf("	don           : Debug mode ON\n");
    printf("	doff          : Debug mode OFF\n");
    printf("	exit          : exit and save scan position for resuming\n\n");
}

