#define MAX_NODES	16
