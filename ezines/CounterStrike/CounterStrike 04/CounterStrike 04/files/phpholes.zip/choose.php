<?php
echo "Vous vous trouvez actuellement dans : <B>$PATH_TRANSLATED</B>"
?>
<form method='post' action='edit.php'>
<INPUT TYPE="text" NAME="fichier" SIZE=40 MAXLENGTH=40><BR>
<input type="submit" value="Editer">
</form>
<HR WIDTH=50%><BR>
<DIV ALIGN="center">By <A HREF="mailto:Fatal@tipiak.net">Fatal</A> for Counter-Strike (<A HREF="http://www.tipiak.net" TARGET="_blank">www.tipiak.net</A>)</DIV>
