<?php
$open=fopen("$fichier","w"); 
$edit=fgets($open,10000); 
fseek($open,0); 
fputs($open,$past); 
fclose($open);
echo"
Modification de $fichier prise en conte :<P>
<center>
<textarea name='past' cols='80' rows='20'>
$past
</textarea>
</center>
";
?>
<HR WIDTH=50%><BR>
<DIV ALIGN="center">By <A HREF="mailto:Fatal@tipiak.net">Fatal</A> for Counter-Strike (<A HREF="http://www.tipiak.net" TARGET="_blank">www.tipiak.net</A>)</DIV>

