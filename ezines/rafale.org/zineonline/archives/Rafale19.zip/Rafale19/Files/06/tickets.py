import PIL
from PIL import ImageFont
from PIL import Image
from PIL import ImageDraw
import random

class Code128C:
	def __init__(self, data, height=60, width=101, module=1):
		if len(data) == 0 or len(data) % 2 != 0:
			raise ValueError('data must be a multiple of 2 and be greater than 0.')
		if height <= 0:
			raise ValueError('height must be greater than 0.')
		if module <= 0:
			raise ValueError('module must be greater than 0.')
		self.m_data    = data
		self.m_width   = width
		self.m_height  = height
		self.m_module  = module
		self.m_pattern = self.getPattern()
	
	def getImage(self):
		image = Image.new('RGBA', (self.getImageWidth(), self.m_height), 'white')
		img   = image.load()
		black = True
		_x     = 0
		for c in self.m_pattern:
			size = int(c) * self.m_module
			if black:
				for x in range(_x, _x+size):
					for y in range(self.m_height):
						img[x, y] = (0, 0, 0, 255)
			_x   += size
			black = not black
		return image
	
	def getPattern(self):
		pattern = self.getSymbolPattern('STARTC')
		key = self.getSymbolValue('STARTC')
		offset = 1
		for i in range(0, len(self.m_data), 2):
			pattern += self.getSymbolPattern(self.m_data[i:i+2])
			key    += offset * self.getSymbolValue(self.m_data[i:i+2])
			offset += 1
		key     %= 103
		pattern += self.getPatternFromValue(key)
		pattern += self.getSymbolPattern('STOP')
		return pattern
	
	def getSymbolPattern(self, symbol):
		for k, v in self.CODE_128.items():
			if symbol == v[0]:
				return v[1]
		return None
	
	def getSymbolValue(self, symbol):
		for k, v in self.CODE_128.items():
			if symbol == v[0]:
				return k
		return None
	
	def getPatternFromValue(self, value):
		return self.CODE_128[value][1]
	
	def getImageWidth(self):
		width = 0
		for c in self.m_pattern:
			width += int(c)
		return width * self.m_module
	
	CODE_128 = {
		  0 : [ '00',     '212222'  ],
		  1 : [ '01',     '222122'  ],
		  2 : [ '02',     '222221'  ],
		  3 : [ '03',     '121223'  ],
		  4 : [ '04',     '121322'  ],
		  5 : [ '05',     '131222'  ],
		  6 : [ '06',     '122213'  ],
		  7 : [ '07',     '122312'  ],
		  8 : [ '08',     '132212'  ],
		  9 : [ '09',     '221213'  ],
		 10 : [ '10',     '221312'  ],
		 11 : [ '11',     '231212'  ],
		 12 : [ '12',     '112232'  ],
		 13 : [ '13',     '122132'  ],
		 14 : [ '14',     '122231'  ],
		 15 : [ '15',     '113222'  ],
		 16 : [ '16',     '123122'  ],
		 17 : [ '17',     '123221'  ],
		 18 : [ '18',     '223211'  ],
		 19 : [ '19',     '221132'  ],
		 20 : [ '20',     '221231'  ],
		 21 : [ '21',     '213212'  ],
		 22 : [ '22',     '223112'  ],
		 23 : [ '23',     '312131'  ],
		 24 : [ '24',     '311222'  ],
		 25 : [ '25',     '321122'  ],
		 26 : [ '26',     '321221'  ],
		 27 : [ '27',     '312212'  ],
		 28 : [ '28',     '322112'  ],
		 29 : [ '29',     '322211'  ],
		 30 : [ '30',     '212123'  ],
		 31 : [ '31',     '212321'  ],
		 32 : [ '32',     '232121'  ],
		 33 : [ '33',     '111323'  ],
		 34 : [ '34',     '131123'  ],
		 35 : [ '35',     '131321'  ],
		 36 : [ '36',     '112313'  ],
		 37 : [ '37',     '132113'  ],
		 38 : [ '38',     '132311'  ],
		 39 : [ '39',     '211313'  ],
		 40 : [ '40',     '231113'  ],
		 41 : [ '41',     '231311'  ],
		 42 : [ '42',     '112133'  ],
		 43 : [ '43',     '112331'  ],
		 44 : [ '44',     '132131'  ],
		 45 : [ '45',     '113123'  ],
		 46 : [ '46',     '113321'  ],
		 47 : [ '47',     '133121'  ],
		 48 : [ '48',     '313121'  ],
		 49 : [ '49',     '211331'  ],
		 50 : [ '50',     '231131'  ],
		 51 : [ '51',     '213113'  ],
		 52 : [ '52',     '213311'  ],
		 53 : [ '53',     '213131'  ],
		 54 : [ '54',     '311123'  ],
		 55 : [ '55',     '311321'  ],
		 56 : [ '56',     '331121'  ],
		 57 : [ '57',     '312113'  ],
		 58 : [ '58',     '312311'  ],
		 59 : [ '59',     '332111'  ],
		 60 : [ '60',     '314111'  ],
		 61 : [ '61',     '221411'  ],
		 62 : [ '62',     '431111'  ],
		 63 : [ '63',     '111224'  ],
		 64 : [ '64',     '111422'  ],
		 65 : [ '65',     '121124'  ],
		 66 : [ '66',     '121421'  ],
		 67 : [ '67',     '141122'  ],
		 68 : [ '68',     '141221'  ],
		 69 : [ '69',     '112214'  ],
		 70 : [ '70',     '112412'  ],
		 71 : [ '71',     '122114'  ],
		 72 : [ '72',     '122411'  ],
		 73 : [ '73',     '142112'  ],
		 74 : [ '74',     '142211'  ],
		 75 : [ '75',     '241211'  ],
		 76 : [ '76',     '221114'  ],
		 77 : [ '77',     '413111'  ],
		 78 : [ '78',     '241112'  ],
		 79 : [ '79',     '134111'  ],
		 80 : [ '80',     '111242'  ],
		 81 : [ '81',     '121142'  ],
		 82 : [ '82',     '121241'  ],
		 83 : [ '83',     '114212'  ],
		 84 : [ '84',     '124112'  ],
		 85 : [ '85',     '124211'  ],
		 86 : [ '86',     '411212'  ],
		 87 : [ '87',     '421112'  ],
		 88 : [ '88',     '421211'  ],
		 89 : [ '89',     '212141'  ],
		 90 : [ '90',     '214121'  ],
		 91 : [ '91',     '412121'  ],
		 92 : [ '92',     '111143'  ],
		 93 : [ '93',     '111341'  ],
		 94 : [ '94',     '131141'  ],
		 95 : [ '95',     '114113'  ],
		 96 : [ '96',     '114311'  ],
		 97 : [ '97',     '411113'  ],
		 98 : [ '98',     '411311'  ],
		 99 : [ '99',     '113141'  ],
		100 : [ 'CODEB',  '114131'  ],
		101 : [ 'CODEA',  '311141'  ],
		102 : [ 'FNC1',   '411131'  ],
		103 : [ 'STARTA', '211412'  ],
		104 : [ 'STARTB', '211214'  ],
		105 : [ 'STARTC', '211232'  ],
		106 : [ 'STOP',   '2331112' ]
	}

class Tickets:
	def __init__(self):
		self.load()
	
	def create(self):
		for ticket in self.m_tickets:
			self.createTicket(ticket)
			print 'Ticket', ticket, 'saved!'
	
	def createTicket(self, ticket):
		offset_barcode1 = (913, 438)
		offset_barcode2 = (68, 319)
		barcode         = Code128C(ticket, 60, 101, 2).getImage()
		barcode1        = self.getBarcode1(barcode)
		barcode2        = self.getBarcode2(barcode)
		infos           = self.getInformations(ticket)
		r, g, b, a      = infos.split()
		infos           = Image.merge('RGB', (r, g, b))
		mask            = Image.merge('L', (a,))
		final           = Image.open('ticket.png')
		final.paste(barcode1, offset_barcode1)
		final.paste(barcode2, offset_barcode2)
		final.paste(infos, (0, 0), mask)
		final.save('tickets/' + ticket + '.png')
	
	def load(self):
		f              = open('tickets.txt', 'r')
		self.m_tickets = f.read().split('\n')
		f.close()
	
	def getInformations(self, ticket):
		black = (0, 0, 0)
		trans = (0, 0, 0, 0)
		ref   = 'B15' + ticket[2:8] + str(random.randint(0, 9))
		date  = '20150' + str(random.randint(1, 3)) + str(random.randint(0, 2)) + str(random.randint(1, 8))
		code  = 'S' + str(random.randint(10, 99))
		code2 = 'GSE' + str(random.randint(1000000000000, 9999999999999))
		font  = ImageFont.truetype('lucon.ttf', 32)
		infos = Image.new('RGBA', (1653, 719), trans)
		draw  = ImageDraw.Draw(infos)
		draw.text(( 912, 516), ticket, black, font=font)		# ticket down
		draw.text((1170, 552), ref,    black, font=font)		# reference down
		draw.text(( 912, 552), date,   black, font=font)		# date down
		draw.text((1088, 552), code,   black, font=font)		# code? down
		draw.text(( 166, 552), code2,  black, font=font)		# code2? left
		rotate = Image.new('RGBA', (719, 615), trans)
		draw   = ImageDraw.Draw(rotate)
		draw.text((144, 495), ref,  black, font=font)			# reference left
		draw.text((144, 530), code, black, font=font)			# code? left
		draw.text((219, 530), date, black, font=font)			# date left
		rotate = rotate.rotate(90)
		r, g, b, a = rotate.split()
		rotate     = Image.merge('RGB', (r, g, b))
		mask       = Image.merge('L', (a,))
		infos.paste(rotate, (0, 0), mask)
		return infos
	
	def getBarcode1(self, image):
		return image.resize((331, 60), Image.ANTIALIAS)
	
	def getBarcode2(self, image):
		return image.resize((222, 60), Image.ANTIALIAS).rotate(90)

tickets = Tickets()
tickets.create()
