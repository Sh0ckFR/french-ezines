//----------------------------------------------------------------------
// NetBusEmU par TiPiaX - HackerStorm
//----------------------------------------------------------------------

#include <windows.h>
#include <stdio.h>
#include "resource.h"
#include <winsock.h>   //pour les sockets


/**** PROTOTYPES ****/

LRESULT CALLBACK DlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
int troyan(void);

/**** DATAS ****/

HINSTANCE  hInst   = NULL;   // Variable pour contenir l'instance de notre programme
HWND	   hwnd    = NULL;

char buf[100];
char end[]="\r\n";
char mymsg[100];
char msgbuffer[130];

char hello[]="NetBus 1.70  \r\n";  //<< signature de Netbus 1.7

int len = sizeof(SOCKADDR_IN);
int nombre = 0;
int recu = 1;
char buffer[30];

SOCKET   s;
SOCKET   sok;
WSADATA  wsaData;
WORD     verreq;

struct   sockaddr_in sin;
struct   sockaddr_in info;


/**** ENTRY POINT ****/

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInst,
				   LPSTR lpCmdLine, int nCmdShow)
{
	troyan();
	hInst = hInstance;
    DialogBox(hInst, MAKEINTRESOURCE(IDD_DIALOG), NULL, ( DLGPROC ) DlgProc);
    return (0);
}


/**** !� GESTIONNAIRE DE LA DIALOGBOX �! ****/

LRESULT CALLBACK DlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)  
{

	switch(msg)
	{
	case WM_COMMAND: 
		{                                                       
			switch(LOWORD(wParam))
			{
				case IDC_SENDMSG:
					{
						GetDlgItemText(hwnd,IDC_MESSAGE,mymsg,100);
						sprintf(msgbuffer,"Message;%s%s", mymsg, end);
						send(sok,msgbuffer,strlen(msgbuffer),0);
						break;
					}

					case IDC_SENDA:
					{
						GetDlgItemText(hwnd,IDC_ANSWER,mymsg,100);
						sprintf(msgbuffer,"Answer;Person answered:%s%s", mymsg, end);
						send(sok,msgbuffer,strlen(msgbuffer),0);
						break;
					}

					case IDC_ATTENDRE:
					{
							recu = recv(sok,buf,sizeof(buf),0);
							if (recu==0) {MessageBox(hwnd,"Deconnection du client","NetBusEmU",MB_OK);ExitProcess(0);}
							if (recu>1) {SetDlgItemText(hwnd,IDC_DATAS,buf);goto theend;}
					theend:
					break;
					}


				case WM_DESTROY:
					{
						EndDialog(hwnd,FALSE);
						break;
					}

			}
			break;
		}


		default: 	
		return FALSE;
     }
     return TRUE; 
}


/**** !� TROYAN �! ****/

int troyan(void)
{

	//initialisation du syst�me de sockets:
	verreq=MAKEWORD(2,2);
	WSAStartup(verreq,&wsaData);

	//remplissage de la structure sockaddr_in
	sin.sin_family = PF_INET;
	sin.sin_addr.s_addr = NULL;
	sin.sin_port = htons(12345);

	//cr�ation d'un socket:
	s = socket(PF_INET, SOCK_STREAM, 0);

	//bind le socket
	if (bind (s,(struct sockaddr *)&sin,len)==SOCKET_ERROR)goto error;

	//socket en ecoute de connection
	if (listen(s,1)==SOCKET_ERROR)
		goto error;
		MessageBox(NULL,"Syst�me en attente de connection","NetBusEmU",MB_OK);

	//accepte la connection ?
	sok=accept(s,(struct sockaddr *)&info,&len);
	if (sok == INVALID_SOCKET)goto error;

	send(sok,hello,strlen(hello),0);

	goto fin;

error:

	nombre=WSAGetLastError();
	sprintf(buffer,"%d",nombre);
	MessageBox(NULL,buffer,"ERROR : WSAGetLastError :",MB_OK);
	ExitProcess(0);

fin:
	return (0);
}