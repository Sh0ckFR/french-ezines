/*

t-userfile.c

Author: Timo J. Rinne <tri@ssh.fi>

Copyright (c) 1996 SSH Communications Security, Finland
                   All rights reserved

Created: Wed Jul  1 15:47:51 1998 tri

*/

/*
 * $Id: t-userfile.c,v 1.1 1998/07/01 13:23:40 tri Exp $
 * $Log: t-userfile.c,v $
 * $EndLog$
 */

#include "sshincludes.h"
#include "userfile.h"

int main()
{
  return 0;
}

/* eof (t-userfile.c) */
