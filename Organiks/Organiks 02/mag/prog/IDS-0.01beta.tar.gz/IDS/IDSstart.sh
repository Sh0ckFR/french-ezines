#!/bin/sh
. ./IDS.conf
$PROGDIR/$SNORTDIR/snort -Ds -l /var/log/snort -c $SNORTLIB >> $INSTALLLOG 2>>$ERRORLOG
$PROGDIR/$TAILBEEPDIR/tailbeep -f /var/log/secure -t $TTY -s snort &
tail -f /var/log/secure | $PROGDIR/$LOGCOLORISEDIR/logcolorise.pl