#!/bin/sh
killall -9 snort 2>/dev/null
killall -9 tailbeep 2>/dev/null
killall -9 logcolorise 2>/dev/null